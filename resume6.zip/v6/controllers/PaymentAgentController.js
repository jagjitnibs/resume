	var express 			=	require('express')
	var router 				=	express.Router();
	var passport 			=	require('passport');
	//var Strategy			= 	require('passport-http-bearer').Strategy;
	var async      			= 	require('async');
	var nodeDateTime 		= 	require('node-datetime');
	//var unixTime			=	require('unix-time');
	
	
	var PaymentAgentModel	=	require('./../models/PaymentAgentModel');
	var ContractModel		=	require('./../models/ContractModel');
	var TaleModel 			=	require('../models/TaleModel');
	
	/*
	Function to get earning history of an agent by user id.
	*/
	/*
	router.get('/rewards', passport.authenticate('bearer', { session: false }), function (req, res) {
	
		if(req.user) {
				
			var user_id 								=	req.user[0].user.id;
			var payment_expire_time 					= 	req.user[0].user.payment_expire_time;				
			var contractor_placed 						= 	null;
			var earning_total							=	null;
			var earning_history							= 	null;
			var earning_withdrawal_amount_available		= 	null;
			
			//console.log('offset = '+offset);
			//var return_data 							= 	{};
			var return_data 							= 	[];

			async.parallel([
			
				function(parallel_done) {
					
					ContractModel.getContractorPlacedByUserId(user_id, function(error, results) { 						
											
						if (error) {    
							return parallel_done(error);
						} else {  
							//console.log(results);
							if(results) {
								return_data.contractor_placed	=	results;
							} 		
							parallel_done();	
						}  
					});					
				},
				function(parallel_done) {				   
					
					PaymentAgentModel.getEarningTotalByUserId(user_id, function(error, results) {
						
						if (error) {    
							return parallel_done(error);
						} else {  
							if(results) {
								return_data.earning_total	=	results;
							} 	
							parallel_done();							
						}  
					});
			   },
			   function(parallel_done) {				   
					
					PaymentAgentModel.getEarningHistoryByUserId(user_id, function(error, results) { 
						
						if (error) {    
							return parallel_done(error);
						} else {  
							if(results) {
								return_data.earning_history	=	results;
							} 	
							parallel_done();							
						}  
					});
			   },
			   function(parallel_done) {				   
					
					PaymentAgentModel.getEarningWithdrawalAmountAvailableByUserId(user_id, function(error, results) {
						
						if (error) {    
							return parallel_done(error);
						} else {  
							if(results) {
								return_data.earning_withdrawal_amount_available	=	results;
							} 	
							parallel_done();							
						}  
					});
			   }
			], function(error) {
				
				if (error) {    
					throw error;
				} else { 
					//dbConnection.end();						
					res.json({
						"isSuccessful" : true,  
						"status" : res.statusCode,
						"code" : 1,
						"message" : "Earning history has been found successfully.", 
						"data" : {
									"payment_expire_time": payment_expire_time,
									"contractor_placed": return_data.contractor_placed,											
									"earning_total": return_data.earning_total,											
									"earning_history": return_data.earning_history,											
									"earning_withdrawal_amount_available": return_data.earning_withdrawal_amount_available,											
								}
					});	
				}			
			});
		}
	});
	*/
	
	
	/*
	Function to get earning history of an agent by user id.
	*/
	//router.get('/rewards', passport.authenticate('bearer', { session: false }), function (req, res) {
	router.get('/rewards/:year/:month', passport.authenticate('bearer', { session: false }), function (req, res) {
		
		//console.log('API :: /rewards/:year?');
	
		if(req.user) {
				
			var user_id 								=	req.user[0].user.id;
			var payment_expire_time 					= 	req.user[0].user.payment_expire_time;				
			var contractor_placed 						= 	null;
			var earning_total							=	null;			
			var earning_withdrawal_amount_available		= 	null;
			var earning_history_actual					= 	null;
			var earning_history_forecast				= 	null;
			
			var year 									= 	parseInt(req.params.year);
			var month 									= 	parseInt(req.params.month);
			
			var dateTime 								=	nodeDateTime.create();
			var currentYear								=	dateTime.format('Y');
			var currentMonth							=	dateTime.format('m');
					
			if (typeof year === 'undefined' || year === null || isNaN(year)  || year <= 0) {
				year = currentYear;
			}
			if (typeof month === 'undefined' || month === null || isNaN(month)  || month <= 0 || month > 12) {
				month = parseInt(currentMonth);
			}
			
			//console.log('user_id = '+user_id);
			//console.log('year = '+year);
			//console.log('month = '+month);
			//console.log('currentYear = '+currentYear);
			//console.log('currentMonth = '+currentMonth);
			
			/* 
			var year_timestamp_start	=	unixTimestamp.fromDate(year+'-01-01');
			var year_timestamp_end		=	unixTimestamp.fromDate(year+'-12-31');
			console.log('year_timestamp_start = '+year_timestamp_start);
			console.log('year_timestamp_end = '+year_timestamp_end);
			*/
			
			//var return_data 							= 	{};
			var return_data 							= 	[];

			var earning_history_forecast	=	[
													{
														"commission_amount_total_history": 0,
														"commission_amount": 0,
														"timesheet_year": 2017,
														"timesheet_month": 1,
														"commission_amount_total": 0
													},
													{
														"commission_amount_total_history": 0,
														"commission_amount": 0,
														"timesheet_year": 2017,
														"timesheet_month": 2,
														"commission_amount_total": 50
													},
													{
														"commission_amount_total_history": 0,
														"commission_amount": 0,
														"timesheet_year": 2017,
														"timesheet_month": 3,
														"commission_amount_total": 90
													},
													{
														"commission_amount_total_history": 0,
														"commission_amount": 0,
														"timesheet_year": 2017,
														"timesheet_month": 4,
														"commission_amount_total": 140
													},
													{
														"commission_amount_total_history": 0,
														"commission_amount": 0,
														"timesheet_year": 2017,
														"timesheet_month": 5,
														"commission_amount_total": 170
													},
													{
														"commission_amount_total_history": 0,
														"commission_amount": 0,
														"timesheet_year": 2017,
														"timesheet_month": 6,
														"commission_amount_total": 200
													}
												];
			
			async.parallel([
			
				function(parallel_done) {
					
					ContractModel.getContractorPlacedByUserId(function(error, results) { 						
											
						if (error) {    
							return parallel_done(error);
						} else {  
							//console.log(results);
							if(results) {
								return_data.contractor_placed	=	results;
							} 		
							parallel_done();	
						}  
					});					
				},
				function(parallel_done) {				   
					
					PaymentAgentModel.getEarningTotalByUserId(function(error, results) {
						
						if (error) {    
							return parallel_done(error);
						} else {  
							if(results) {
								return_data.earning_total	=	results;
							} 	
							parallel_done();							
						}  
					});
			   },
			   function(parallel_done) {				   
					
					PaymentAgentModel.getEarningWithdrawalAmountAvailableByUserId(function(error, results) {
						
						if (error) {    
							return parallel_done(error);
						} else {  
							if(results) {
								return_data.earning_withdrawal_amount_available	=	results;
							} 	
							parallel_done();							
						}  
					});
			   },
			   function(parallel_done) {				   
					
					PaymentAgentModel.getEarningHistoryByUserId(year, month, function(error, results) { 
						
						if (error) {    
							return parallel_done(error);
						} else {  
							if(results) {
								return_data.earning_history_actual	=	results;
							} 	
							parallel_done();							
						}  
					});
			   },
			   function(parallel_done) {				   
					
					PaymentAgentModel.getEarningForecastByUserId(year, month, function(error, results) { 
						
						if (error) {    
							return parallel_done(error);
						} else {  
							if(results) {
								return_data.earning_history_forecast	=	results;
							} 	
							parallel_done();							
						}  
					});
			   },
			   /* function(parallel_done) {				   
					
					PaymentAgentModel.getEarningHistoryForecastByUserId(year, month, function(error, results) { 
						
						if (error) {    
							return parallel_done(error);
						} else {  
							if(results) {
								return_data.earning_history_forecast	=	results;
							} 	
							parallel_done();							
						}  
					});
			   }, */
			   
			], function(error) {
				
				if (error) {    
					throw error;
				} else { 
					//dbConnection.end();						
					res.json({
						"isSuccessful" : true,  
						"status" : res.statusCode,
						"code" : 1,
						"message" : "Earning history has been found successfully.", 
						"data" : {
									"year": year,
									"payment_expire_time": payment_expire_time,
									"contractor_placed": return_data.contractor_placed,											
									"earning_total": return_data.earning_total,											
									"earning_withdrawal_amount_available": return_data.earning_withdrawal_amount_available,
									"earning_history_actual": return_data.earning_history_actual,								
									"earning_history_forecast": return_data.earning_history_forecast,								
									//"earning_history_forecast": null,								
									//"earning_history_forecast": return_data.earning_history_actual,							
									//"earning_history_forecast": earning_history_forecast,							
								}
					});	
				}			
			});
		}
	});
	
	
	
	/*
	Function to get earning history of an agent by user id.
	*/
	router.get('/transaction-history', passport.authenticate('bearer', { session: false }), function (req, res) {
	
		if(req.user) {
				
			var user_id 								=	req.user[0].user.id;
			var payment_expire_time 					= 	req.user[0].user.payment_expire_time;				
			var contractor_placed 						= 	null;
			var earning_total							=	null;
			var earning_history							= 	null;
			var earning_withdrawal_amount_available		= 	null;
			var transaction_history						= 	null;
			
			//console.log('offset = '+offset);
			//var return_data 							= 	{};
			var return_data 							= 	[];

			async.parallel([
			
				function(parallel_done) {				   
					
					PaymentAgentModel.getTransactionHistoryByUserId(function(error, results) {
						
						if (error) {    
							return parallel_done(error);
						} else {  
							if(results) {
								//console.log(results);
								return_data.transaction_history	=	results;
							} 	
							parallel_done();							
						}  
					});
			   },
			   function(parallel_done) {				   
					
					PaymentAgentModel.getEarningWithdrawalAmountAvailableByUserId(function(error, results) {
						
						if (error) {    
							return parallel_done(error);
						} else {  
							if(results) {
								return_data.earning_withdrawal_amount_available	=	results;
							} 	
							parallel_done();							
						}  
					});
			   },			  
			], function(error) {
				
				if (error) {    
					throw error;
				} else { 
					//dbConnection.end();						
					res.json({
						"isSuccessful" : true,  
						"status" : res.statusCode,
						"code" : 1,
						"message" : "Transaction history has been found successfully.", 
						"data" : {
									"labels":  {0:"Fund", 1:"Available for Cash Out", 2:"Cash Out", "C":[{"sign":"+", "title":"Reward"}], "D":[{"sign":"-", "title":"Cash Out"}], "currency":"&pound;", },
									"earning_withdrawal_amount_available": return_data.earning_withdrawal_amount_available,
									"transaction_history_count": return_data.transaction_history.length,
									"transaction_history": return_data.transaction_history,
								}
					});	
				}			
			});
		}
	});
	
	
	/*
	Function to get earning history of an agent by user id.
	*/
	router.get('/transaction-history-new', passport.authenticate('bearer', { session: false }), function (req, res) {
	
		if(req.user) {
				
			var user_id 								=	req.user[0].user.id;
			var payment_expire_time 					= 	req.user[0].user.payment_expire_time;				
			var contractor_placed 						= 	null;
			var earning_total							=	null;
			var earning_history							= 	null;
			var earning_withdrawal_amount_available		= 	null;
			var transaction_history						= 	null;
			
			//console.log('offset = '+offset);
			//var return_data 							= 	{};
			var return_data 							= 	[];

			async.parallel([
			
				function(parallel_done) {				   
					
					PaymentAgentModel.getTransactionHistoryByUserId_nestTablesFalse(function(error, results) {
						
						if (error) {    
							return parallel_done(error);
						} else {  
							if(results) {
								//console.log(results);
								return_data.transaction_history	=	results;
							} 	
							parallel_done();							
						}  
					});
			   },
			   function(parallel_done) {				   
					
					PaymentAgentModel.getEarningWithdrawalAmountAvailableByUserId(function(error, results) {
						
						if (error) {    
							return parallel_done(error);
						} else {  
							if(results) {
								return_data.earning_withdrawal_amount_available	=	results;
							} 	
							parallel_done();							
						}  
					});
			   },			  
			], function(error) {
				
				if (error) {    
					throw error;
				} else { 
					//dbConnection.end();						
					res.json({
						"isSuccessful" : true,  
						"status" : res.statusCode,
						"code" : 1,
						"message" : "Transaction history has been found successfully.", 
						"data" : {
									"labels":  {0:"Fund", 1:"Available for Cash Out", 2:"Cash Out", "C":[{"sign":"+", "title":"Reward"}], "D":[{"sign":"-", "title":"Cash Out"}], "currency":"&pound;", },
									"earning_withdrawal_amount_available": return_data.earning_withdrawal_amount_available,
									"transaction_history_count": return_data.transaction_history.length,
									"transaction_history": return_data.transaction_history,
								}
					});	
				}			
			});
		}
	});
	
	
	/*
	Function to create payment request from an agent to Admin.
	*/
	router.get('/payment-request', passport.authenticate('bearer', { session: false }), function (req, res) {
			
		
		
		if(req.user) {							
					
			var user 				=	req.user[0].user;
			//var user_id 			=	req.user[0].user.id;
			var payment_expire_time	= 	req.user[0].user.payment_expire_time;				
			var postData			=	req.body;
			
			//console.log("Role = "+req.user[0].user.role);
			var apiResponseMessage 	=	config.apiResponseMessage[102];	
			
			TaleModel.getTaleDetailByUserId(function(error, results) {
				
				if (error) {    
					throw error;
				} else {
					if(!results.length) {
						apiResponseMessage	=	config.apiResponseMessage.TALE[101];	
						res.json({
							"isSuccessful" : false,  
							"status" : res.statusCode,
							"code" : 0,
							"message" : apiResponseMessage,
						});									
					} else {
						var tale = results[0].tale;
						PaymentAgentModel.createPaymentRequest(tale, function(error, results) {  
				
							if (error) {    
								throw error;
							} else {
								//console.log(results);
								if(results) {										
									res.json({
										"isSuccessful" : true,  
										"status" : res.statusCode,
										"code" : 1,
										"message" : config.apiResponseMessage.PAYMENT_AGENT[102],
									});									
								} else {
									res.json({
										"isSuccessful" : true,  
										"status" : res.statusCode,
										"code" : 0,
										"message" : config.apiResponseMessage.PAYMENT_AGENT[101],
									});
								}						
							}  
						});
					}						
				}  
			});
			
			/*
			PaymentAgentModel.createPaymentRequest(function(error, results) {  
				
				if (error) {    
					throw error;
				} else {
					if(results) {										
						res.json({
							"isSuccessful" : true,  
							"status" : res.statusCode,
							"code" : 1,
							"message" : "Payment request has been created successfully.",
						});									
					} else {
						res.json({
							"isSuccessful" : true,  
							"status" : res.statusCode,
							"code" : 0,
							"message" : "No pending request or bank account not configured.",
						});
					}						
				}  
			});
			*/	
		}		
	});	
	
	module.exports = router
	