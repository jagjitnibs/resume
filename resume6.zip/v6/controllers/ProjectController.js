	var express 		=	require('express')
	var router 			=	express.Router();
	var passport 		=	require('passport');
	//var Strategy		= 	require('passport-http-bearer').Strategy;
	var async      		= 	require('async');
	
	var ProjectModel	=	require('./../models/ProjectModel');
	var JobModel		=	require('./../models/JobModel');
	//var JobInviteModel	=	require('./../models/JobInviteModel');
	
	
	router.get('/:offset?', passport.authenticate('bearer', { session: false }), function (req, res) {	
		
		if(req.user) {
				
			var user_id 						=	req.user[0].user.id;
			var payment_expire_time 			= 	req.user[0].user.payment_expire_time;
			var offset 							= 	null;
			var pathViewAttachment 				= 	null;
			var countJobPublishTypeContacts 	= 	0;
			var countJobPublishTypeContactChild	=	0;
			var countJobPublishTypeBroadcast 	= 	0;
			var jobPublishTypeContacts			=	null;
			var jobPublishTypeContactChild 		= 	null;
			var jobPublishTypeBroadcast 		=	null;
			
			var offset 							= 	req.params.offset;		
			
			if (typeof offset === 'undefined' || offset === null || parseInt(offset)<=0) {
				offset	=	0;
			} else {
				offset = parseInt(offset);
			}
			
			//console.log('offset = '+offset);
			//var return_data 					= 	{};
			var return_data 					= 	[];

			async.parallel([
			
				function(parallel_done) {
					
					ProjectModel.getProjectByUserId(user_id, function(error, results) {  
											
						if (error) {    
							return parallel_done(error);
						} else {  
							//console.log(results);
							if(results) {
								return_data.project	=	results;
							} 		
							parallel_done();	
						}  
					});					
				},
				function(parallel_done) {
					
					JobModel.getJobOfProjectByUserId(user_id, function(error, results) {  
											
						if (error) {    
							return parallel_done(error);
						} else {  
							//console.log(results);
							if(results) {
								return_data.job	=	results;
							} 		
							parallel_done();	
						}  
					});					
				},
			], function(error) {
				
				if (error) {    
					throw error;
				} else { 
					//dbConnection.end();						
					res.json({
						"isSuccessful" : true,  
						"status" : res.statusCode,
						"code" : 1,
						"message" : "Projects list has been found successfully.", 
						"data" : {
									"offset": offset+config.params.SQL_LIMIT_JOB,
									"payment_expire_time": payment_expire_time,
									"countProject": return_data.project.length, 
									"countJob": return_data.job.length, 
									"project": return_data.project,
									"job": return_data.job,
								}
					});
				}			
			});
		}
	});
	
		
	/*
	Function to create new project.
	*/
	router.post('/create', passport.authenticate('bearer', { session: false }), function (req, res) {
			
		if(req.user) {	
		
			req.assert("title", "Invalid title").matches(/^([a-zA-Z0-9 ]+)$/, "i");
			req.assert("title", "Title must be between %1 and %2 chars long").len(config.params.TITLE_LENGTH_MIN, config.params.TITLE_LENGTH_MAX);
			req.assert('location', 'Invalid location').notEmpty().matches(/^([a-zA-Z0-9-, ]+)$/, "i");
			req.assert("location", "Location must be between %1 and %2 chars long").len(config.params.LOCATION_LENGTH_MIN, config.params.LOCATION_LENGTH_MAX);
			req.assert('latitude', 'Invalid latitude').notEmpty().isDecimal();
			req.assert('longitude', 'Invalid longitude').notEmpty().isDecimal();
			
			req.assert("organistion", "Invalid organization").matches(/^([a-zA-Z0-9 ]+)$/, "i");
			req.assert("organistion", "Organization must be between %1 and %2 chars long").len(config.params.ORGANIZATION_LENGTH_MIN, config.params.ORGANIZATION_LENGTH_MAX);
			
			req.sanitize('title').trim();				
			req.sanitize('location').trim();				
			req.sanitize('organistion').trim();
			
			req.getValidationResult().then(function(result) {				
				
				if (!result.isEmpty()) {
					
					res.status(400); //	BAD REQUEST
					res.json({
						"isSuccessful" : false,  
						"status" : res.statusCode,
						"code" : 0,
						"message" : result.mapped(),							
					});
				} else {						
					
					var user 				=	req.user[0].user;
					//var user_id 			=	req.user[0].user.id;
					var payment_expire_time	= 	req.user[0].user.payment_expire_time;				
					var postData			=	req.body;
					
					//console.log("Role = "+req.user[0].user.role);
					
					ProjectModel.createProject(user, postData, function(error, results) {  
						
						if (error) {    
							throw error;
						} else {
							if(results) {										
								res.json({
									"isSuccessful" : true,  
									"status" : res.statusCode,
									"code" : 1,
									"message" : "Project has been created successfully.", 
									"data" : {"project": results}
								});									
							} else {
								res.json({
									"isSuccessful" : true,  
									"status" : res.statusCode,
									"code" : 0,
									"message" : "Error while creating new project.", 
									"data" : {"project": null}
								});
							}						
						}  
					});
				}				
			});							
		}		
	});	
	
	
	module.exports = router