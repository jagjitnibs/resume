	var express 		=	require('express')
	var router 			=	express.Router();
	var passport 		=	require('passport');
	//var Strategy		= 	require('passport-http-bearer').Strategy;
	var async      		= 	require('async');
	
	// Include the public functions from 'helpers.js'
	var helpers 				= 	require('../common/components/helpers');

	var IndustrySectorModel		=	require('./../models/IndustrySectorModel');
	var SubIndustrySectorModel	=	require('./../models/SubIndustrySectorModel');
	var SectorRoleModel			=	require('./../models/SectorRoleModel');
	var SkillModel				=	require('./../models/SkillModel');
	var DurationTypeModel		=	require('./../models/DurationTypeModel');
	var RateTypeModel			=	require('./../models/RateTypeModel');
	var CurrencyModel			=	require('./../models/CurrencyModel');
	var JobModel				=	require('./../models/JobModel');
	var PageModel				=	require('./../models/PageModel');
	var MobileBuildVersionModel	=	require('./../models/MobileBuildVersionModel');
	var SettingServerModel		=	require('./../models/SettingServerModel');
	
	router.get('/registration/', function (req, res) {	
	
			//var return_data 					= 	{};
			var return_data 					= 	[];

			async.parallel([
			
				function(parallel_done) {
					
					IndustrySectorModel.getAll(function(error, results) {  
						
						if (error) {    
							return parallel_done(error);
						} else {  
							//console.log(results);
							if(results) {
								return_data.industrySector		=	results;
							} 		
							parallel_done();	
						}  
					});					
				},
				function(parallel_done) {
					
					SubIndustrySectorModel.getAll(function(error, results) {  
											
						if (error) {    
							return parallel_done(error);
						} else {  
							//console.log(results);
							if(results) {
								return_data.subIndustrySector		=	results;
							} 		
							parallel_done();	
						}  
					});					
				},
				function(parallel_done) {
					
					SectorRoleModel.getAll(function(error, results) {  
											
						if (error) {    
							return parallel_done(error);
						} else {  
							//console.log(results);
							if(results) {
								return_data.sectorRole		=	results;
							} 		
							parallel_done();	
						}  
					});					
				},
				function(parallel_done) {
					
					SkillModel.getAll(function(error, results) {  
											
						if (error) {    
							return parallel_done(error);
						} else {  
							//console.log(results);
							if(results) {
								return_data.skill		=	results;
							} 		
							parallel_done();	
						}  
					});					
				},
				function(parallel_done) {
					
					DurationTypeModel.getAll(function(error, results) {  
											
						if (error) {    
							return parallel_done(error);
						} else {  
							//console.log(results);
							if(results) {
								return_data.durationType		=	results;
							} 		
							parallel_done();	
						}  
					});					
				},
				function(parallel_done) {
					
					RateTypeModel.getAll(function(error, results) {  
											
						if (error) {    
							return parallel_done(error);
						} else {  
							//console.log(results);
							if(results) {
								return_data.rateType		=	results;
							} 		
							parallel_done();	
						}  
					});					
				},
				function(parallel_done) {
					
					CurrencyModel.getAll(function(error, results) {  
											
						if (error) {    
							return parallel_done(error);
						} else {  
							//console.log(results);
							if(results) {
								return_data.currency		=	results;
							} 		
							parallel_done();	
						}  
					});					
				},
				function(parallel_done) {
					
					JobModel.getJobType(function(error, results) {  
											
						if (error) {    
							return parallel_done(error);
						} else {  
							//console.log(results);
							if(results) {
								return_data.jobType		=	results;
							} 		
							parallel_done();	
						}  
					});					
				},
				function(parallel_done) {
					
					JobModel.getJobPublishType(function(error, results) {  
											
						if (error) {    
							return parallel_done(error);
						} else {  
							//console.log(results);
							if(results) {
								return_data.jobPublishType		=	results;
							} 		
							parallel_done();	
						}  
					});					
				},
				function(parallel_done) {
					
					JobModel.getJobExpiryTime(function(error, results) {  
											
						if (error) {    
							return parallel_done(error);
						} else {  
							//console.log(results);
							if(results) {
								return_data.jobExpiryTime		=	results;
							} 		
							parallel_done();	
						}  
					});					
				},
			], function(error) {
				
				if (error) {    
					throw error;
				} else { 
					//dbConnection.end();					
					res.json({
						"isSuccessful" : true,  
						"status" : res.statusCode,
						"code" : 1,
						"message" : "Settings has been found successfully.", 
						"data" : { 
									"jobType": return_data.jobType,
									"jobPublishType": return_data.jobPublishType,
									"jobExpiryTime": return_data.jobExpiryTime,
									"industrySector": return_data.industrySector, 
									"subIndustrySector": return_data.subIndustrySector,
									"sectorRole": return_data.sectorRole,
									"skill": return_data.skill,
									"durationType": return_data.durationType,
									"rateType": return_data.rateType,
									"currency": return_data.currency,
								}
					});
				}			
			});
	
	});
	
	// Get job filter 
	router.get('/introduction/', function (req, res) {
			
			var results	=	helpers.getAppIntroductionData();
			
			if (results) {
				
						//var jobFilterDistanceMinMax	= 	{"min": config.JOB_FILTER.DISTANCE.MIN, "max": config.JOB_FILTER.DISTANCE.MAX};
						//var jobFilterRateMinMax		=	{"min": config.JOB_FILTER.RATE.MIN, "max": config.JOB_FILTER.RATE.MAX};
						//var jobFilterSalaryMinMax	=	{"min": config.JOB_FILTER.SALARY.MIN, "max": config.JOB_FILTER.SALARY.MAX};
					
						res.send({
							"isSuccessful" : true, 
							"status" : res.statusCode, 
							"code" : 1,
							"message" : "Job filter has been found successfully.", 
							"data" : {"introduction": results}
						}); 				
					} else {
						res.send({
							"isSuccessful" : true,  
							"status" : res.statusCode,
							"code" : 0,
							"message" : "No matching records found.", 
							"data" : {"introduction": results}
						});
					}
				
	})
	
	
	
	// Get job filter 
	//router.get('/page/1', passport.authenticate('bearer', { session: false }), function (req, res) {
	router.get('/page/:id?', function (req, res) {		
		
		
				
			var apiResponseMessage 				=	config.apiResponseMessage[102];
			
			req.sanitize('id').toInt();
			
			req.getValidationResult().then(function(result) {				
				
				if (!result.isEmpty()) {					
					res.status(400); //	BAD REQUEST
					res.json({
						"isSuccessful" : false,  
						"status" : res.statusCode,
						"code" : 0,
						"message" : result.array(),							
					});
				} else {
					
					var id 							= 	req.params.id;		
			
					if (typeof id === 'undefined' || id === null || parseInt(id)<=0) {
						id	=	0;
					} else {
						id = parseInt(id);
					}
					
					PageModel.getById(id, function(error, results) {
						
						//console.log(results);			
						if (error) {    
							throw error;
						} else {
							if(results)	{
								
								//console.log(results);
								
								if(results.length) { 
									apiResponseMessage	=	config.apiResponseMessage.PAGE[101];

									res.json({
										"isSuccessful" : true,  
										"status" : res.statusCode,
										"code" : 1,
										"message" : apiResponseMessage, 
										"data" : {										
											"page": results,																		
										}
									});									
								} else {
									res.json({
										"isSuccessful" : false,  
										"status" : res.statusCode,
										"code" : 0,
										"message" : apiResponseMessage,									
									});
								}
								
								
							} else {
									res.json({
										"isSuccessful" : false,  
										"status" : res.statusCode,
										"code" : 0,
										"message" : apiResponseMessage,									
									});
								}					
						}
					});
				}
			
			});	
			
			
			
	})
	
	// Get job filter 
	router.post('/testpush/', function (req, res) {
			
			req.assert('device_token', 'Invalid device_token').notEmpty();
			req.sanitize('device_token').trim();	
			req.sanitize('device_token').escape();
			
			req.getValidationResult().then(function(result) {
				
				if (!result.isEmpty()) {
						
					res.status(400); //	BAD REQUEST
					res.json({
						"isSuccessful" : false,  
						"status" : res.statusCode,
						"code" : 0,
						"message" : result.mapped(),							
					});
				} else {
					var device_token	=	req.body.device_token;
					var device_tokens	=	device_token.split(",");
					
					console.log('device_tokens = '+device_tokens);
					/*
					var device_tokens = device_token.split(",").map(function (val) {
						//return Number(val) + 1;
						return val;
					});
					*/
					
					var device_tokens = device_token.toString().split(",");
					console.log(device_tokens);

					var results	=	helpers.sendAndroidPushNotification(device_tokens);
				
					if (results) {						
						res.send({
							"isSuccessful" : true, 
							"status" : res.statusCode, 
							"code" : 1,
							"message" : "Android push notification has been sent successfully.", 
							"data" : {"introduction": results}
						}); 				
					} else {
						res.send({
							"isSuccessful" : true,  
							"status" : res.statusCode,
							"code" : 0,
							"message" : "No matching records found.", 
							"data" : {"introduction": results}
						});
					}
				}
					
			});	
			
			
				
	})
	
	
	
	/*
	Function to update the user profile.
	*/
	router.post('/forceful_______222', passport.authenticate('bearer', { session: false }), function (req, res) {
			
		if(req.user) {

			//console.log('========================');
			//console.log('========================');
			//console.log("userLoggedIn = "+JSON.stringify(userLoggedIn));
			//console.log("AuthenticUser = "+AuthenticUser);
			//console.log("AuthenticUser.full_name = "+AuthenticUser.full_name);

			var user_id 							=	AuthenticUser.id;
			var full_name 							=	AuthenticUser.full_name;
			var payment_expire_time 				=	AuthenticUser.payment_expire_time;
			var date_availability 					=	AuthenticUser.date_availability;
			
			console.log("AuthenticUser.id = "+AuthenticUser.id);
			console.log("AuthenticUser.full_name = "+AuthenticUser.full_name);
			console.log("AuthenticUser.payment_expire_time = "+AuthenticUser.payment_expire_time);
			console.log("AuthenticUser.date_availability = "+AuthenticUser.date_availability);
			
			
			
			//var currentDate 						= 	moment().format('YYYY-MM-DD'); 
			//var currentDateTimeStamp				= 	moment(currentDate, 'YYYY-MM-DD');		
					
			var postData							=	req.body;
		
			
			req.sanitize('build_version').trim();				
			
			req.assert('build_version', 'Build version required').notEmpty();
			req.assert('build_version', 'Invalid build version').matches(/^([0-9.]+)$/, "i");
			
			req.assert('device_type', 'Device type required').notEmpty();
			req.assert('device_type', 'Device type must be an integer.').isInt();
			req.assert('device_type', 'Invalid device type').isIn([config.USER.DEVICE_TYPE_IOS, config.USER.DEVICE_TYPE_ANDROID]);
			
			req.sanitize('build_version').escape();			
			req.sanitize('device_type').escape();			
			
			req.getValidationResult().then(function(result) {				
				
				if (!result.isEmpty()) {
					
					res.status(400); //	BAD REQUEST
					res.json({
						"isSuccessful" : false,  
						"status" : res.statusCode,
						"code" : 0,
						"message" : result.array(),							
					});
				} else {					
								
					var postData			=	req.body;
					
					MobileBuildVersionModel.getForcefulUpdateBuildId(postData, function(error, results) {  
						
						if (error) {    
							throw error;
						} else {
							//if(results.length) {
							if(results) {
								console.log('results.length = '+results.length);
								var forcefulBuildDetails	=	results;
								
								console.log('forcefulBuildDetails outer = '+ JSON.stringify(results, null, 2));
								
								
								MobileBuildVersionModel.getCurrentBuildVersionDetails(postData, function(error, results) { 
						
									if (error) {    
										throw error;
									} else {
										if(results) {
											var currentBuildDetails	=	results;
											MobileBuildVersionModel.getLatestBuildVersionDetails(postData, function(error, results) { 
						
												if (error) {    
													throw error;
												} else {
													if(results) {
														var latestBuildDetails	=	results;

														console.log('forcefulBuildDetails = '+forcefulBuildDetails);
														
														res.json({
															"isSuccessful" : true,  
															"status" : res.statusCode,
															"code" : 1,
															"message" : "Build version details has been found successfully.", 
															"data" : {
																"latestBuildDetails": 	latestBuildDetails, 
																"forcefulBuildDetails":	forcefulBuildDetails, 
																"currentBuildDetails": 	currentBuildDetails
															}
														});									
													} else {
														res.json({
															"isSuccessful" : true,  
															"status" : res.statusCode,
															"code" : 0,
															"message" : "No matching record found.", 
															
														});
													}						
												}  
											});									
										} else {
											res.json({
												"isSuccessful" : true,  
												"status" : res.statusCode,
												"code" : 0,
												"message" : "No matching record found.", 
												
											});
										}						
									}  
								});
							} else {
								res.json({
									"isSuccessful" : true,  
									"status" : res.statusCode,
									"code" : 0,
									"message" : "No matching record found.",
								});
							}						
						}  
					});
				}				
			});							
		}		
	});
	
	
	
	//======================================================================
	/*
	API to manage build version with forceful download and skip options.
	*/
	/*
	router.post('/mobile-app', passport.authenticate('bearer', { session: false }), function (req, res) {
			
		if(req.user) {

			//console.log('========================');
			//console.log('========================');
			//console.log("userLoggedIn = "+JSON.stringify(userLoggedIn));
			//console.log("AuthenticUser = "+AuthenticUser);
			//console.log("AuthenticUser.full_name = "+AuthenticUser.full_name);

			var user_id 							=	AuthenticUser.id;
			var full_name 							=	AuthenticUser.full_name;
			var payment_expire_time 				=	AuthenticUser.payment_expire_time;
			var date_availability 					=	AuthenticUser.date_availability;
			
			var showAlertBox 						=	0;
			var forcefulDownload 					=	0;
			var showAlertTitle 						=	'';
			var showAlertMessage 					=	'';
						
			//console.log("AuthenticUser.id = "+AuthenticUser.id);
			//console.log("AuthenticUser.full_name = "+AuthenticUser.full_name);
			//console.log("AuthenticUser.payment_expire_time = "+AuthenticUser.payment_expire_time);
			//console.log("AuthenticUser.date_availability = "+AuthenticUser.date_availability);
			
			//var currentDate 						= 	moment().format('YYYY-MM-DD');
			//var currentDateTimeStamp				= 	moment(currentDate, 'YYYY-MM-DD');
					
			var postData							=	req.body;
		
			
			req.sanitize('current_build_version').trim();
			
			//req.assert('current_build_id', 'Current build ID required').notEmpty();
			//req.assert('current_build_id', 'Current build ID must be an integer.').isInt();
			
			req.assert('skip_build_id', 'Skip build ID required').notEmpty();
			req.assert('skip_build_id', 'Skip build ID must be an integer.').isInt();
			
			req.assert('current_build_version', 'Build version required').notEmpty();
			req.assert('current_build_version', 'Invalid build version').matches(/^([0-9.]+)$/, "i");
			
			req.assert('device_type', 'Device type required').notEmpty();
			req.assert('device_type', 'Device type must be an integer.').isInt();
			req.assert('device_type', 'Invalid device type').isIn([config.USER.DEVICE_TYPE_IOS, config.USER.DEVICE_TYPE_ANDROID]);
			
			//req.sanitize('current_build_id').escape();			
			req.sanitize('skip_build_id').escape();			
			req.sanitize('current_build_version').escape();
			req.sanitize('device_type').escape();			
			
			req.getValidationResult().then(function(result) {				
				
				if (!result.isEmpty()) {
					
					res.status(400); //	BAD REQUEST
					res.json({
						"isSuccessful" : false,  
						"status" : res.statusCode,
						"code" : 0,
						"message" : result.array(),							
					});
				} else {					
								
					var postData			=	req.body;
					
					var return_data 		= 	[];

					async.parallel([
					
						function(parallel_done) {
							MobileBuildVersionModel.getLatestBuildVersionDetails(postData, function(error, results) { 
								if (error) {    
									return parallel_done(error);
								} else {  
									if(results) {
										//console.log('results = '+ JSON.stringify(results, null, 2));
										return_data.latestBuildDetails	=	results;										
									} 		
									parallel_done();	
								}  
							});					
						},
						function(parallel_done) {
							MobileBuildVersionModel.getForcefulUpdateBuildId(postData, function(error, results) {  
								if (error) {    
									return parallel_done(error);
								} else {  
									if(results) {
										return_data.forcefulBuildDetails	=	results;
									} 		
									parallel_done();	
								}  
							});					
						},
						function(parallel_done) {					
							MobileBuildVersionModel.getCurrentBuildVersionDetails(postData, function(error, results) {					
								if (error) {    
									return parallel_done(error);
								} else {  
									if(results) {
										return_data.currentBuildDetails	=	results;
									} 	
									parallel_done();							
								}  
							});
					   },
					   function(parallel_done) {					
							MobileBuildVersionModel.getSkipBuildVersionDetails(postData, function(error, results) {					
								if (error) {    
									return parallel_done(error);
								} else {  
									if(results) {
										return_data.skipBuildDetails	=	results;
									} 	
									parallel_done();							
								}  
							});
					   },
					   
					], function(error) {
						
						if (error) {    
							throw error;
						} else {
							
							var latestBuildDetails_build_version 	=	(return_data.latestBuildDetails['build_version']) ? return_data.latestBuildDetails.build_version : '';
							var latestBuildDetails_id 				=	(return_data.latestBuildDetails['id']) ? parseInt(return_data.latestBuildDetails.id) : 0;
							var forcefulBuildDetails_id				=	(return_data.forcefulBuildDetails['id']) ? parseInt(return_data.forcefulBuildDetails.id) : 0;
							var currentBuildDetails_id 				=	(return_data.currentBuildDetails['id']) ? parseInt(return_data.currentBuildDetails.id) : 0;
							var skipBuildDetails_id 				=	(return_data.skipBuildDetails['id']) ? parseInt(return_data.skipBuildDetails.id) : 0;

							//if(skipBuildDetails_id > currentBuildDetails_id){
							//	skipBuildDetails_id	=	0;
							//}
							showAlertTitle				=	"Avoko";	
							showAlertMessage			=	"A new version of the "+config.params.SITE_NAME+" app is available. Please update to version "+latestBuildDetails_build_version+" now.";	
							
							console.log('latestBuildDetails_id = '+ latestBuildDetails_id);
							console.log('forcefulBuildDetails_id = '+ forcefulBuildDetails_id);
							console.log('currentBuildDetails_id = '+ currentBuildDetails_id);
							console.log('skipBuildDetails_id = '+ skipBuildDetails_id);
							
							
							// CODE START:: SHOW ALERT BOX
							if(currentBuildDetails_id <= 0) {
								showAlertBox		=	1;
							} else if(currentBuildDetails_id >= latestBuildDetails_id) {
								showAlertBox		=	0;
							} else if(currentBuildDetails_id < forcefulBuildDetails_id) {
								showAlertBox		=	1;
							} else if(currentBuildDetails_id < latestBuildDetails_id) {
								showAlertBox		=	1;
							}
							// CODE END:: SHOW ALERT BOX

							
							// CODE START:: SHOW FORCEFUL DOWNLOAD
							if(currentBuildDetails_id <= 0) {
								forcefulDownload	=	1;
							} else if(currentBuildDetails_id >= latestBuildDetails_id) {
								forcefulDownload	=	0;
							} else if(currentBuildDetails_id < forcefulBuildDetails_id) {
								forcefulDownload	=	1;
							}	
							// CODE END:: SHOW FORCEFUL DOWNLOAD

							
							// CODE START:: IF USER SKIP THE UPGRADE OPTION
							if(skipBuildDetails_id >= forcefulBuildDetails_id) {
								showAlertBox		=	0;
								forcefulDownload	=	0;
							}

							if(latestBuildDetails_id > skipBuildDetails_id && latestBuildDetails_id > currentBuildDetails_id) {
								showAlertBox		=	1;
							}	
							
							//	if(latestBuildDetails_id == skipBuildDetails_id) {
							//		showAlertBox		=	0;
							//	}	
						
							// CODE START:: IF USER SKIP THE UPGRADE OPTION							
							
							res.json({
								"isSuccessful" : true,  
								"status" : res.statusCode,
								"code" : 1,
								"message" : "Build version details has been found successfully.",
								"data" : {
									"showAlertBox": showAlertBox, 
									"forcefulDownload": forcefulDownload, 
									"showAlertTitle": showAlertTitle, 
									"showAlertMessage": showAlertMessage, 
									"latestBuildDetails": return_data.latestBuildDetails, 
									"forcefulBuildDetails": return_data.forcefulBuildDetails, 
									"currentBuildDetails": return_data.currentBuildDetails,								
									"skipBuildDetails": return_data.skipBuildDetails,								
								}
							});
						}			
					});
				}				
			});							
		}		
	});
	*/
	//======================================================================
	/*
	API to manage build version with forceful download and skip options.
	*/
	router.post('/mobile-app', passport.authenticate('bearer', { session: false }), function (req, res) {
			
		if(req.user) {

			//console.log('========================');
			//console.log('========================');
			//console.log("userLoggedIn = "+JSON.stringify(userLoggedIn));
			//console.log("AuthenticUser = "+AuthenticUser);
			//console.log("AuthenticUser.full_name = "+AuthenticUser.full_name);

			var user_id 							=	AuthenticUser.id;
			var full_name 							=	AuthenticUser.full_name;
			var payment_expire_time 				=	AuthenticUser.payment_expire_time;
			var date_availability 					=	AuthenticUser.date_availability;
			
			var showAlertBox 						=	0;
			var forcefulDownload 					=	0;
			var showAlertTitle 						=	'';
			var showAlertMessage 					=	'';
						
			//console.log("AuthenticUser.id = "+AuthenticUser.id);
			//console.log("AuthenticUser.full_name = "+AuthenticUser.full_name);
			//console.log("AuthenticUser.payment_expire_time = "+AuthenticUser.payment_expire_time);
			//console.log("AuthenticUser.date_availability = "+AuthenticUser.date_availability);
			
			//var currentDate 						= 	moment().format('YYYY-MM-DD');
			//var currentDateTimeStamp				= 	moment(currentDate, 'YYYY-MM-DD');
					
			var postData							=	req.body;
		
			
			req.sanitize('current_build_version').trim();
			
			//req.assert('current_build_id', 'Current build ID required').notEmpty();
			//req.assert('current_build_id', 'Current build ID must be an integer.').isInt();
			
			req.assert('skip_build_id', 'Skip build ID required').notEmpty();
			req.assert('skip_build_id', 'Skip build ID must be an integer.').isInt();
			
			req.assert('current_build_version', 'Build version required').notEmpty();
			req.assert('current_build_version', 'Invalid build version').matches(/^([0-9.]+)$/, "i");
			
			req.assert('device_type', 'Device type required').notEmpty();
			req.assert('device_type', 'Device type must be an integer.').isInt();
			req.assert('device_type', 'Invalid device type').isIn([config.USER.DEVICE_TYPE_IOS, config.USER.DEVICE_TYPE_ANDROID]);
			
			//req.sanitize('current_build_id').escape();			
			req.sanitize('skip_build_id').escape();			
			req.sanitize('current_build_version').escape();
			req.sanitize('device_type').escape();			
			
			req.getValidationResult().then(function(result) {				
				
				if (!result.isEmpty()) {
					
					res.status(400); //	BAD REQUEST
					res.json({
						"isSuccessful" : false,  
						"status" : res.statusCode,
						"code" : 0,
						"message" : result.array(),							
					});
				} else {					
								
					var postData			=	req.body;
					
					var return_data 		= 	[];

					async.parallel([
					
						function(parallel_done) {
							SettingServerModel.getServerDetails(postData, function(error, results) { 
								if (error) {    
									return parallel_done(error);
								} else {  
									if(results) {
										//console.log('serverDetails = '+ JSON.stringify(results, null, 2));
										return_data.serverDetails	=	results;										
									} 		
									parallel_done();	
								}  
							});					
						},
						function(parallel_done) {
							MobileBuildVersionModel.getLatestBuildVersionDetails(postData, function(error, results) { 
								if (error) {    
									return parallel_done(error);
								} else {  
									if(results) {
										//console.log('results = '+ JSON.stringify(results, null, 2));
										return_data.latestBuildDetails	=	results;										
									} 		
									parallel_done();	
								}  
							});					
						},
						function(parallel_done) {
							MobileBuildVersionModel.getForcefulUpdateBuildId(postData, function(error, results) {  
								if (error) {    
									return parallel_done(error);
								} else {  
									if(results) {
										return_data.forcefulBuildDetails	=	results;
									} 		
									parallel_done();	
								}  
							});					
						},
						function(parallel_done) {					
							MobileBuildVersionModel.getCurrentBuildVersionDetails(postData, function(error, results) {					
								if (error) {    
									return parallel_done(error);
								} else {  
									if(results) {
										return_data.currentBuildDetails	=	results;
									} 	
									parallel_done();							
								}  
							});
					   },
					   function(parallel_done) {					
							MobileBuildVersionModel.getSkipBuildVersionDetails(postData, function(error, results) {					
								if (error) {    
									return parallel_done(error);
								} else {  
									if(results) {
										return_data.skipBuildDetails	=	results;
									} 	
									parallel_done();							
								}  
							});
					   },
					   
					], function(error) {
						
						if (error) {    
							throw error;
						} else {
							
							var serverDetails 						=	(return_data.serverDetails) ? return_data.serverDetails : '';
							var latestBuildDetails_build_version 	=	(return_data.latestBuildDetails['build_version']) ? return_data.latestBuildDetails.build_version : '';
							var latestBuildDetails_id 				=	(return_data.latestBuildDetails['id']) ? parseInt(return_data.latestBuildDetails.id) : 0;
							var forcefulBuildDetails_id				=	(return_data.forcefulBuildDetails['id']) ? parseInt(return_data.forcefulBuildDetails.id) : 0;
							var currentBuildDetails_id 				=	(return_data.currentBuildDetails['id']) ? parseInt(return_data.currentBuildDetails.id) : 0;
							var skipBuildDetails_id 				=	(return_data.skipBuildDetails['id']) ? parseInt(return_data.skipBuildDetails.id) : 0;

							//if(skipBuildDetails_id > currentBuildDetails_id){
							//	skipBuildDetails_id	=	0;
							//}
							showAlertTitle				=	"Avoko";	
							//showAlertMessage			=	"A new version of the "+config.params.SITE_NAME+" app is available. Please update to version "+latestBuildDetails_build_version+" now.";	
							showAlertMessage			=	"A new version of the "+config.params.SITE_NAME+" app is available. Please update to the latest version now.";
							
							// console.log('latestBuildDetails_id = '+ latestBuildDetails_id);
							// console.log('forcefulBuildDetails_id = '+ forcefulBuildDetails_id);
							// console.log('currentBuildDetails_id = '+ currentBuildDetails_id);
							// console.log('skipBuildDetails_id = '+ skipBuildDetails_id);
							
							
							// CODE START:: SHOW ALERT BOX
							if(currentBuildDetails_id <= 0) {
								//showAlertBox		=	1;	// This line commented on Dec-20-2017. 
							} else if(currentBuildDetails_id >= latestBuildDetails_id) {
								showAlertBox		=	0;
							} else if(currentBuildDetails_id < forcefulBuildDetails_id) {
								showAlertBox		=	1;
							} else if(currentBuildDetails_id < latestBuildDetails_id) {
								showAlertBox		=	1;
							}
							// CODE END:: SHOW ALERT BOX

							
							// CODE START:: SHOW FORCEFUL DOWNLOAD
							if(currentBuildDetails_id <= 0) {
								//forcefulDownload	=	1;	// This line commented on Dec-20-2017. 
							} else if(currentBuildDetails_id >= latestBuildDetails_id) {
								forcefulDownload	=	0;
							} else if(currentBuildDetails_id < forcefulBuildDetails_id) {
								forcefulDownload	=	1;
							}	
							// CODE END:: SHOW FORCEFUL DOWNLOAD

							
							// CODE START:: IF USER SKIP THE UPGRADE OPTION
							if(skipBuildDetails_id >= forcefulBuildDetails_id) {
								showAlertBox		=	0;
								forcefulDownload	=	0;
							}

							//if(latestBuildDetails_id > skipBuildDetails_id && latestBuildDetails_id > currentBuildDetails_id) { // This line commented on Dec-20-2017. 
							if(latestBuildDetails_id > skipBuildDetails_id && skipBuildDetails_id>0) {
								showAlertBox		=	1;
							}	
							
							/*
							// This case added on Dec-20-2017. 
							if(currentBuildDetails_id <= 0) {
								showAlertBox		=	0;
								forcefulDownload	=	0;
							}
							*/
							
							//	if(latestBuildDetails_id == skipBuildDetails_id) {
							//		showAlertBox		=	0;
							//	}	
						
							// CODE START:: IF USER SKIP THE UPGRADE OPTION							
							
							res.json({
								"isSuccessful" : true,  
								"status" : res.statusCode,
								"code" : 1,
								"message" : "Build version details has been found successfully.",
								"data" : {
									"serverDetails": serverDetails, 
									"showAlertBox": showAlertBox, 
									"forcefulDownload": forcefulDownload, 
									"showAlertTitle": showAlertTitle, 
									"showAlertMessage": showAlertMessage, 
									"latestBuildDetails": return_data.latestBuildDetails, 
									"forcefulBuildDetails": return_data.forcefulBuildDetails, 
									"currentBuildDetails": return_data.currentBuildDetails,								
									"skipBuildDetails": return_data.skipBuildDetails,								
								}
							});
						}			
					});
				}				
			});							
		}		
	});
	//======================================================================
	//======================================================================
	//======================================================================
	//======================================================================
	
	
	/*
	// define the about route
	router.get('/about', passport.authenticate('bearer', { session: false }), function (req, res) {
		res.send('About Animals')
	})
	*/
	module.exports = router