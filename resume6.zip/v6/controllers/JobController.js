	var express 		=	require('express')
	var router 			=	express.Router();
	var passport 		=	require('passport');
	//var Strategy		= 	require('passport-http-bearer').Strategy;
	var async      		= 	require('async');
	var nodeDateTime 	= 	require('node-datetime');

	var JobModel		=	require('./../models/JobModel');
	var JobFilterModel	=	require('./../models/JobFilterModel');
	var JobInviteModel	=	require('./../models/JobInviteModel');
	
	
	
	router.get('/:offset?', passport.authenticate('bearer', { session: false }), function (req, res) {	
		
		if(req.user) {
			
			//var user_id 						=	req.user[0].user.id;
			//var payment_expire_time 			= 	req.user[0].user.payment_expire_time;
			
			var user_id 						= 	AuthenticUser.id;
			var payment_expire_time 			= 	AuthenticUser.payment_expire_time;
			var role 							= 	AuthenticUser.role;
			
			var offset 							= 	null;
			var pathViewAttachment 				= 	null;
			var countJobPublishTypeContacts 	= 	0;
			var countJobPublishTypeContactChild	=	0;
			var countJobPublishTypeBroadcast 	= 	0;
			var jobPublishTypeContacts			=	null;
			var jobPublishTypeContactChild 		= 	null;
			var jobPublishTypeBroadcast 		=	null;
			
			var offset 							= 	req.params.offset;		
			
			if (typeof offset === 'undefined' || offset === null || parseInt(offset)<=0) {
				offset	=	0;
			} else {
				offset = parseInt(offset);
			}
			
			//console.log('offset = '+offset);
			//var return_data 					= 	{};
			var return_data 					= 	[];

			async.parallel([
			
				function(parallel_done) {
					
					JobModel.getJobListPublishTypeContactByUserId(function(error, results) {  
											
						if (error) {    
							return parallel_done(error);
						} else {  
							//console.log(results);
							if(results) {
								return_data.jobPublishTypeContacts	=	results;
								countJobPublishTypeContacts			=	results.length;
							} 		
							parallel_done();	
						}  
					});					
				},
				function(parallel_done) {				   
					
					JobModel.getJobListPublishTypeBroadcastByUserId(offset, function(error, results) {
						
						if (error) {    
							return parallel_done(error);
						} else {  
							if(results) {
								return_data.jobPublishTypeBroadcast	=	results;
								countJobPublishTypeBroadcast		=	results.length;
							} 	
							parallel_done();							
						}  
					});
			   }
			], function(error) {
				
				if (error) {    
					throw error;
				} else { 
					//dbConnection.end();						
					res.json({
						"isSuccessful" : true,  
						"status" : res.statusCode,
						"code" : 1,
						"message" : config.apiResponseMessage.JOB[107], 
						"data" : {
									"offset": offset+config.params.SQL_LIMIT_JOB,
									"role": role,
									"payment_expire_time": payment_expire_time,
									"pathViewAttachment": config.url+config.params.SERVER_PATH_JOB_ATTACHMENT, 
									"messageJobShareMaximumAlert": config.apiResponseMessage.JOB[108], 
									"countJobPublishTypeContacts": countJobPublishTypeContacts, 
									//"countJobPublishTypeBroadcast": return_data.jobPublishTypeBroadcast.length, 
									"countJobPublishTypeBroadcast": countJobPublishTypeBroadcast, 
									"jobPublishTypeContacts": return_data.jobPublishTypeContacts, 
									"jobPublishTypeBroadcast": return_data.jobPublishTypeBroadcast
								}
					});
				}			
			});
		}
	});
	
	/*
	Function to get shared job list by user.
	*/
	router.get('/shared-jobs/:job_id?',	passport.authenticate('bearer', { session: false }), function (req, res) {
			
			var job_id = req.params.job_id;		
			
			if (typeof job_id === 'undefined' || job_id === null || parseInt(job_id)<=0) {
				job_id	=	0;
			} else {
				job_id = parseInt(job_id);
			}

			if(req.user) {
				
				var user_id 						=	req.user[0].user.id;
				var payment_expire_time 			= 	req.user[0].user.payment_expire_time;
				var offset 							= 	null;
				var pathViewAttachment 				= 	null;
				var countSharedJobs 				= 	null;
				var sharedJobs						=	null;
				var countSharedJobs					=	null;
				var sharedJobsInvitedUsers			=	null;
				
				var job_ids							=	[];
					
				JobModel.getJobListSharedByUserId(user_id, job_id, function(error, results) {  
					
					if (error) {    
						throw error;
					} else {  
						
						if(results) {
							//console.log('getJobListSharedByUserId = '+ JSON.stringify(results, null, 2));
							countSharedJobs	=	results.length;
							sharedJobs		=	results;					
							
							for (var i=0;i<results.length;i++) {
								job_ids.push(results[i]['job'].id);							
							}						
							
							JobInviteModel.getJobInviteByJodIds(user_id, job_ids, function(error, results) {
								
								if (error) {    
									throw error;
								} else {									
									res.json({
										"isSuccessful" : true,  
										"status" : res.statusCode,
										"code" : 1,
										"message" : "Jobs list has been found successfully.", 
										"data" : {
													"countSharedJobs": countSharedJobs,
													"sharedJobs": sharedJobs, 
													"sharedJobsInvitedUsers": results,												
												}
									});									
								}
							});	
							
						} else {
							res.json({
								"isSuccessful" : true,  
								"status" : res.statusCode,
								"code" : 0,
								"message" : "No matching record found.", 
								"data" : {
											"pathViewAttachment": null,
											"countSharedJobs": countSharedJobs,
											"sharedJobs": sharedJobs, 
											"sharedJobsInvitedUsers": sharedJobsInvitedUsers, 
											
										}
							});
						}											
					}  
				});						
			}		
		}
	);
	
	
	/*
	Function to create new job.
	*/
	router.post('/create', passport.authenticate('bearer', { session: false }), function (req, res) {
			
		//console.log("userLoggedIn = "+JSON.stringify(userLoggedIn));
		console.log("AuthenticUser = "+AuthenticUser);
		console.log("AuthenticUser.full_name = "+AuthenticUser.full_name);
		//console.log(config.CURRENCY.ID);
		//console.log(Object.keys(config.CURRENCY.ID));
		//console.log(Object.keys(config.JOB.EXPIRY_TIME_DROPDOWN));
		
		if(req.user) {	
		
			var dateTime = nodeDateTime.create();
			dateTime.offsetInDays(-1);
			var yesterdayDate = dateTime.format('Y-m-d');

			req.sanitize('hiring_manager_name').trim();			
			req.sanitize('hiring_manager_email').trim();			
			req.sanitize('hiring_manager_mobile').trim();			
			req.sanitize('sector_role_id').toInt();			
			req.sanitize('start_date').trim();			
			req.sanitize('job_type').toInt();			
			req.sanitize('title').trim();			
			req.sanitize('currency_id').toInt();			
			req.sanitize('rate_type_id').toInt();			
			req.sanitize('contract_duration').toInt();			
			req.sanitize('duration_type_id').toInt();			
			req.sanitize('job_skill').trim();			
			req.sanitize('other_skill').trim();			
			req.sanitize('description').trim();			
			req.sanitize('expiry_time').toInt();
			req.sanitize('job_invite').trim();			
			
			req.assert('project_id', 'Invalid project id').notEmpty().isInt();
			req.assert("hiring_manager_name", "Invalid hiring manager name").matches(/^([a-zA-Z0-9 ]+)$/, "i");
			req.assert("hiring_manager_name", "Hiring manager name must be between %1 and %2 chars long").len(config.params.FULL_NAME_LENGTH_MIN, config.params.FULL_NAME_LENGTH_MAX);
			
			req.assert('hiring_manager_email', 'Invalid hiring manager email').notEmpty().isEmail();
			
			req.assert('hiring_manager_mobile', 'Invalid hiring manager mobile').notEmpty().matches(/^([0-9 ]+)$/, "i");
			req.assert("hiring_manager_mobile", "Hiring manager mobile must be between %1 and %2 chars long").len(config.params.MOBILE_LENGTH_MIN, config.params.MOBILE_LENGTH_MAX);
			//req.assert('hiring_manager_mobile', 'Invalid hiring manager mobile').notEmpty().isMobilePhone("en-GB");
			
			req.assert('sector_role_id', 'Invalid sector role id').notEmpty().isInt();
			
			//req.assert('start_date', 'Invalid start date').notEmpty().isDate().isAfter(yesterdayDate);

			req.assert('start_date', ' You cannot select start date in the past').notEmpty().isDate().isAfter(yesterdayDate);
			req.assert('start_date', 'Invalid start date date').notEmpty().isDate();
			req.assert('start_date', 'Start date date required').notEmpty();			
				
			req.assert('job_type', 'Invalid job type').notEmpty().isInt().isIn([config.JOB.JOB_TYPE.CONTRACTOR, config.JOB.JOB_TYPE.PERMANENT]);
			req.assert('title', 'Invalid title').notEmpty().matches(/^([a-zA-Z0-9 ]+)$/, "i");
			req.assert('rate', 'Invalid rate').notEmpty().matches(/^[1-9][0-9]*$/, "i");  
			req.assert('currency_id', 'Invalid currency id').notEmpty().isInt().isIn(Object.keys(config.CURRENCY.ID));
			req.assert('rate_type_id', 'Invalid rate type id').notEmpty().isInt().isIn(Object.keys(config.RATE_TYPE.ID));
			 
			if(req.body.job_type == config.JOB.JOB_TYPE.CONTRACTOR) {
				req.assert('contract_duration', 'Invalid contract duration').notEmpty().isInt();
				req.assert('duration_type_id', 'Invalid duration type id').notEmpty().isInt().isIn(Object.keys(config.DURATION_TYPE.ID));
			}
			req.assert('job_skill', 'Invalid job skill').optional().matches(/^([0-9,]+)$/, "i");
			req.assert('other_skill', 'Invalid other skill').optional().matches(/^([a-zA-Z0-9-, ]+)$/, "i");
			req.assert('description', 'Invalid description').notEmpty().matches(/^([a-zA-Z0-9-, ]+)$/, "i");
			req.assert('expiry_time', 'Invalid expiry time').notEmpty().notEmpty().isInt().isIn(Object.keys(config.JOB.EXPIRY_TIME_DROPDOWN));
				
			req.assert('job_invite', 'Invalid invite ids').optional().matches(/^([0-9,]+)$/, "i");				
					
			
			/*			
			req.sanitize('sector_role_id').toInt();				
			req.sanitize('job_type').toInt();				
			req.sanitize('currency_id').toInt();			
			req.sanitize('rate_type_id').toInt();			
			req.sanitize('contract_duration').toInt();			
			req.sanitize('duration_type_id').toInt();					
			req.sanitize('expiry_time').toInt();
			*/	
			
			req.getValidationResult().then(function(result) {				
				
				if (!result.isEmpty()) {
					
					res.status(400); //	BAD REQUEST
					res.json({
						"isSuccessful" : false,  
						"status" : res.statusCode,
						"code" : 0,
						"message" : result.mapped(),							
					});
				} else {						
					
					var user 				=	req.user[0].user;
					//var user_id 			=	req.user[0].user.id;
					var payment_expire_time	= 	req.user[0].user.payment_expire_time;				
					var postData			=	req.body;
					
					//console.log("Role = "+req.user[0].user.role);
					
					JobModel.createJob(user, postData, function(error, results) {  
						//console.log('results 123 = '+results);
						if (error) {    
							throw error;
						} else {
							if(results) {								

								var job_id	=	results;
								//JobModel.getJobDetailById(job_id, function(error, results) {
								JobModel.getComprehensiveJobDetailById(job_id, function(error, results) {
									//console.log("-----333333333"+JSON.stringify(results,0,2));
									//console.log("333333333"+JSON.stringify(results.job,0,2));
									//console.log("333333333"+JSON.stringify(results.invite,0,2));
									if (error) {    
										throw error;
									} else {									
										res.json({
											"isSuccessful" : true,  
											"status" : res.statusCode,
											"code" : 1,
											"message" : "Jobs has been created successfully.", 
											//"data" : results
											"data" : {
												"job": results.job,												
												"invite": results.invite,												
											}
										});									
									}
								});
								//=============

								
																
							} 						
						}  
					});
				}				
			});							
		}		
	});
	
	
	
	/*
	Function to view job details.
	*/	
	router.post('/view', passport.authenticate('bearer', { session: false }), function (req, res) {
			
		if(req.user) {
			
			var user_id 			= 	AuthenticUser.id;
			var payment_expire_time	= 	AuthenticUser.payment_expire_time;
						
			var apiResponseMessage	=	config.apiResponseMessage[102];
						
			req.sanitize('job_id').toInt();
			req.assert('job_id').notEmpty();			
			
			req.getValidationResult().then(function(result) {				
				
				if (!result.isEmpty()) {					
					res.status(400); //	BAD REQUEST
					res.json({
						"isSuccessful" : false,  
						"status" : res.statusCode,
						"code" : 0,
						"message" : result.array(),							
					});
				} else {
					var postData	=	req.body;
					var job_id		=	postData.job_id;
					
					//console.log('job_id = '+job_id);
					
					JobModel.getComprehensiveJobDetailById(job_id, function(error, results) {
						
						if (error) {    
							throw error;
						} else {									
							res.json({
								"isSuccessful" : true,  
								"status" : res.statusCode,
								"code" : 1,
								"message" : config.apiResponseMessage.JOB[110], 
								"data" : {
									"job": results.job,												
									"invite": results.invite,												
								}
							});									
						}
					});					
				}				
			});												
		}		
	});
	
	module.exports = router