	var express 		=	require('express')
	var router 			=	express.Router();
	var passport 		=	require('passport');
	//var Strategy		= 	require('passport-http-bearer').Strategy;

	var JobFilterModel	=	require('./../models/JobFilterModel');
		
	// Get job filter 
	router.get('/', passport.authenticate('bearer', { session: false }), function (req, res) {	
		
		if(req.user) {
				
			var user_id	=	req.user[0].user.id;	
			
			JobFilterModel.getJobFilterByUserId(function (error, results) {
				
				if (error) {    
					throw error;
				} else {
					if (results) {
				
						var jobFilterDistanceMinMax	= 	{"min": config.JOB_FILTER.DISTANCE.MIN, "max": config.JOB_FILTER.DISTANCE.MAX};
						var jobFilterRateMinMax		=	{"min": config.JOB_FILTER.RATE.MIN, "max": config.JOB_FILTER.RATE.MAX};
						var jobFilterSalaryMinMax	=	{"min": config.JOB_FILTER.SALARY.MIN, "max": config.JOB_FILTER.SALARY.MAX};
					
						res.send({
							"isSuccessful" : true, 
							"status" : res.statusCode, 
							"code" : 1,
							"message" : "Job filter has been found successfully.", 
							"data" : {
										"jobFilterDistanceMinMax": jobFilterDistanceMinMax,
										"jobFilterRateMinMax": jobFilterRateMinMax,
										"jobFilterSalaryMinMax": jobFilterSalaryMinMax,
										"job_filter": results, 											
									}
						}); 				
					} else {
						res.send({
							"isSuccessful" : true,  
							"status" : res.statusCode,
							"code" : 0,
							"message" : "No matching records found.", 
							"data" : {"job_filter": results}
						});
					}
				}
			});
		}		
	})
	
	/*
	// define the about route
	router.get('/about', passport.authenticate('bearer', { session: false }), function (req, res) {
		res.send('About Animals')
	})
	*/
	module.exports = router