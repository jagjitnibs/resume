	var express 		=	require('express')
	var router 			=	express.Router();
	var passport 		=	require('passport');
	//var Strategy		= 	require('passport-http-bearer').Strategy;

	var SmsJobInviteModel	=	require('./../models/SmsJobInviteModel');
		
	// Create real job invites from SMS job invites. 
	router.post('/create-real-job-invite', passport.authenticate('bearer', { session: false }), function (req, res) {
		
		if(req.user) {
				
			var user_id 						= 	AuthenticUser.id;
			var payment_expire_time 			= 	AuthenticUser.payment_expire_time;
			var role 							= 	AuthenticUser.role;
						
			SmsJobInviteModel.createRealJobInviteFromSMS(function (error, results) {
				
				if (error) {    
					throw error;
				} else {
					if (results) {
										
						res.send({
							"isSuccessful" : true, 
							"status" : res.statusCode, 
							"code" : 1,
							"message" : "Job filter has been found successfully.", 
							"data" : {										
								"sms_job_invites": results, 											
							}
						}); 				
					} else {
						res.send({
							"isSuccessful" : true,  
							"status" : res.statusCode,
							"code" : 0,
							"message" : "No matching records found.", 
							"data" : {"sms_job_invites": results}
						});
					}
				}
			});
		}		
	})
	
	/*
	// define the about route
	router.get('/about', passport.authenticate('bearer', { session: false }), function (req, res) {
		res.send('About Animals')
	})
	*/
	module.exports = router