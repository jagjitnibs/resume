//exports.users = require('./users');
exports.users = require('./../models/UserModel');
