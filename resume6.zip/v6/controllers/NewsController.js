	var express 		=	require('express')
	var router 			=	express.Router();
	var passport 		=	require('passport');
	//var Strategy		= 	require('passport-http-bearer').Strategy;
	//var nodeDateTime 	= 	require('node-datetime');

	var NewsModel		=	require('./../models/NewsModel');
	
	
	/*
	Function to get user profile.
	*/
	router.get('/', passport.authenticate('bearer', { session: false }), function (req, res) {
			
		if(req.user) {			
			var user_id 			=	req.user[0].user.id;
			var payment_expire_time	= 	req.user[0].user.payment_expire_time;
			var apiResponseMessage	=	config.apiResponseMessage[102];
			
			NewsModel.getAll(function(error, results) {  
						
				if (error) {    
					throw error;
				} else {
					if(results) {
						if(results.length>0) {
							apiResponseMessage = config.apiResponseMessage.NEWS[101];
						}
						
						res.json({
							"isSuccessful" : true,  
							"status" : res.statusCode,
							"code" : 1,
							"message" : apiResponseMessage, 
							"data" : {"count_news": results.length, "news": results}
						});									
					} else {
						res.json({
							"isSuccessful" : true,  
							"status" : res.statusCode,
							"code" : 0,
							"message" : apiResponseMessage,
							"data" : {"count_news": 0, "news": null}
						});
					}						
				}  
			});							
		}		
	});
	
	

	module.exports = router