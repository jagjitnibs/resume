	var express 		=	require('express')
	var router 			=	express.Router();
	var passport 		=	require('passport');
	//var Strategy		= 	require('passport-http-bearer').Strategy;
	var async      		= 	require('async');
	var nodeDateTime 	= 	require('node-datetime');

	var NotificationModel	=	require('./../models/NotificationModel');
	//var JobFilterModel	=	require('./../models/JobFilterModel');
	//var JobInviteModel	=	require('./../models/JobInviteModel');
	
	
	//=================================================================
	/*
	Function to get list of notifications by user ID.
	*/
	/*
	router.get('/:id?', passport.authenticate('bearer', { session: false }), function (req, res) {			
			
		var id = req.params.id;		
		
		if (typeof id === 'undefined' || id === null || parseInt(id)<=0) {
			id	=	0;
		} else {
			id = parseInt(id);
		}

		if(req.user) {
			
			var user_id 						= 	AuthenticUser.id;
			var payment_expire_time 			= 	AuthenticUser.payment_expire_time;
			var role 							= 	AuthenticUser.role;
					
			// var offset 							= 	null;
			// var pathViewAttachment 				= 	null;
			// var countSharedJobs 				= 	null;
			// var sharedJobs						=	null;
			// var countSharedJobs					=	null;
			// var sharedJobsInvitedUsers			=	null;
			
			// var job_ids							=	[];
				
			NotificationModel.getNotificationListById(id, function(error, results) {
							
				if (error) {    
					throw error;
				} else {									
					res.json({
						"isSuccessful" : true,  
						"status" : res.statusCode,
						"code" : 1,
						"message" : "Jobs list has been found successfully.", 
						"data" : {
									"countNotifications": results.length,
									//"sharedJobs": sharedJobs, 
									"notifications": results,												
								}
					});									
				}
			});						
		}		
	});
	*/
	//=================================================================	
	/*
	Function to get list of notifications by user ID.
	*/
	router.get('/:id?', passport.authenticate('bearer', { session: false }), function (req, res) {	
		
		var id = req.params.id;		
		
		if (typeof id === 'undefined' || id === null || parseInt(id)<=0) {
			id	=	0;
		} else {
			id = parseInt(id);
		}
		
		if(req.user) {
				
			var user_id 						= 	AuthenticUser.id;
			var payment_expire_time 			= 	AuthenticUser.payment_expire_time;
			var role 							= 	AuthenticUser.role;
			
			// var offset 							= 	null;
			// var pathViewAttachment 				= 	null;
			// var countJobPublishTypeContacts 	= 	0;
			// var countJobPublishTypeContactChild	=	0;
			// var countJobPublishTypeBroadcast 	= 	0;
			// var jobPublishTypeContacts			=	null;
			// var jobPublishTypeContactChild 		= 	null;
			// var jobPublishTypeBroadcast 		=	null;
			
			// var offset 							= 	req.params.offset;		
			
			
			
			//console.log('offset = '+offset);
			//var return_data 					= 	{};
			var return_data 					= 	[];

			async.parallel([
			
				function(parallel_done) {
					
					NotificationModel.getNotificationTemplate(function(error, results) {
											
						if (error) {    
							return parallel_done(error);
						} else {  
							//console.log(results);
							if(results) {
								return_data.listNotificationTemplate		=	results;
							} 		
							parallel_done();	
						}  
					});					
				},
				function(parallel_done) {				   
					
					NotificationModel.getNotificationListByUserId(id, function(error, results) {
						
						if (error) {    
							return parallel_done(error);
						} else {  
							if(results) {
								return_data.countNotifications	=	results.length;
								return_data.notifications		=	results;
							} 	
							parallel_done();							
						}  
					});
			   }
			], function(error) {
				
				if (error) {    
					throw error;
				} else { 
					//dbConnection.end();						
					res.json({
						"isSuccessful" : true,  
						"status" : res.statusCode,
						"code" : 1,
						"message" : config.apiResponseMessage.NOTIFICATION[101], 
						"data" : {
									//"offset": offset+config.params.SQL_LIMIT_JOB,
									//"role": role,
									//"payment_expire_time": payment_expire_time,
									"limit": config.params.SQL_LIMIT_NOTIFICATION, 
									"siteName": config.params.SITE_NAME, 
									"pathProfileImage": config.url+config.params.SERVER_PATH_USER_PROFILE_IMAGE, 
									"pathProfileImageThumb": config.url+config.params.SERVER_PATH_USER_PROFILE_IMAGE_THUMB, 
									"pathViewAttachment": config.url+config.params.SERVER_PATH_JOB_ATTACHMENT, 
									"countNotifications": return_data.countNotifications,
									"listNotificationTemplate": return_data.listNotificationTemplate,
									"notifications": return_data.notifications,
								}
					});
				}			
			});
		}
	});
	//=================================================================
	//=================================================================
	//=================================================================
	//=================================================================
	//=================================================================
	//=================================================================
	//=================================================================
	//=================================================================
	
	module.exports = router