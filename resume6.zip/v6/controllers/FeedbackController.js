	var express 		=	require('express')
	var router 			=	express.Router();
	var passport 		=	require('passport');
	//var Strategy		= 	require('passport-http-bearer').Strategy;
	var async      		= 	require('async');
	
	var FeedbackModel	=	require('./../models/FeedbackModel');
	
	
	
	/*
	Function to create new feedback.
	*/
	router.post('/create', passport.authenticate('bearer', { session: false }), function (req, res) {
			
		if(req.user) {	

			var apiResponseMessage	=	config.apiResponseMessage[102];		
			
			req.sanitize('description').trim();					
			
			req.assert('description', 'Description required').notEmpty();
			//req.assert("description", "Invalid description").matches(/^([a-zA-Z0-9,. ]+)$/, "i");
			//req.assert("description", "Invalid description").matches(/^([A-Za-z0-9-&\/"\'\\\,()-.:?\s+]+)$/, "i");
			req.assert("description", "Invalid description").matches(/^([A-Za-z0-9-&\/"\'\\\,()-._:!£?\s+]+)$/, "i");
			req.assert("description", "Description must be between %1 and %2 chars long").len(config.FEEDBACK.DESCRIPTION.MIN, config.FEEDBACK.DESCRIPTION.MAX);
			
			req.getValidationResult().then(function(result) {				
				
				if (!result.isEmpty()) {
					
					res.status(400); //	BAD REQUEST
					res.json({
						"isSuccessful" : false,  
						"status" : res.statusCode,
						"code" : 0,
						"message" : result.array(),							
					});
				} else {						
					
					var postData	=	req.body;
					
					FeedbackModel.createFeedback(postData, function(error, results) {  
						
						if (error) {    
							throw error;
						} else {
							if(results) {
								
								apiResponseMessage = config.apiResponseMessage.FEEDBACK[101];								
								
								res.json({
									"isSuccessful" : true,  
									"status" : res.statusCode,
									"code" : 1,
									"message" : apiResponseMessage,
								});															
							} 						
						}  
					});
				}				
			});							
		}		
	});
	
	
	module.exports = router