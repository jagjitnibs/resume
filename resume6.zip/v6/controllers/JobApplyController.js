	var express 		=	require('express')
	var router 			=	express.Router();
	var passport 		=	require('passport');
	
	//var Strategy		= 	require('passport-http-bearer').Strategy;
	//var async      	= 	require('async');
	//var nodeDateTime 	= 	require('node-datetime');

	var JobApplyModel	=	require('./../models/JobApplyModel');
	
	//==================================================================
	/*
	Function to get the list of applied jobs shared job list by user.
	*/
	router.get('/applied-jobs-newapi/:offset?',	passport.authenticate('bearer', { session: false }), function (req, res) {
			
		if(req.user) {
			
			var user_id 						= 	AuthenticUser.id;
			var payment_expire_time 			= 	AuthenticUser.payment_expire_time;
			var role 							= 	AuthenticUser.role;								
			var offset 							= 	req.params.offset;		
			var apiResponseMessage 				=	config.apiResponseMessage[102];	

			
			if (typeof offset === 'undefined' || offset === null || parseInt(offset)<=0) {
				offset	=	0;
			} else {
				offset = parseInt(offset);
			}
			
			JobApplyModel.getJobApplyByUserIdNewApi(user_id, offset, function(error, results) {							
				if (error) {    
					throw error;
				} else {
					if(results)	{						
						if(results.length)	{
							apiResponseMessage	=	config.apiResponseMessage.JOB_APPLY[101];
							offset 				=	offset+config.params.SQL_LIMIT_JOB;
						}						
						res.json({
							"isSuccessful" : true,  
							"status" : res.statusCode,
							"code" : 1,
							"message" : apiResponseMessage, 
							"data" : {
								"offset": offset,
								"payment_expire_time": payment_expire_time,
								"countJobApplied": results.length,
								"jobApplied": results,												
							}
						});
					} else {
						res.json({
							"isSuccessful" : false,  
							"status" : res.statusCode,
							"code" : 0,
							//"message" : apiResponseMessage, 
						});
					}					
				}
			});									
		}		
	});	
	//==================================================================
	/*
	Function to get the list of applied jobs shared job list by user.
	*/
	router.get('/applied-jobs/:offset?',	passport.authenticate('bearer', { session: false }), function (req, res) {
			
		if(req.user) {
			
			var user_id 						=	req.user[0].user.id;
			var payment_expire_time 			= 	req.user[0].user.payment_expire_time;						
			var offset 							= 	req.params.offset;		
			var apiResponseMessage 				=	config.apiResponseMessage[102];	

			
			if (typeof offset === 'undefined' || offset === null || parseInt(offset)<=0) {
				offset	=	0;
			} else {
				offset = parseInt(offset);
			}
			
			JobApplyModel.getJobApplyByUserId(user_id, offset, function(error, results) {
							
				if (error) {    
					throw error;
				} else {
					if(results)	{
						
						if(results.length)	{
							apiResponseMessage	=	config.apiResponseMessage.JOB_APPLY[101];
							offset 				=	offset+config.params.SQL_LIMIT_JOB;
						}
						
						res.json({
							"isSuccessful" : true,  
							"status" : res.statusCode,
							"code" : 1,
							"message" : apiResponseMessage, 
							"data" : {
								"offset": offset,
								"payment_expire_time": payment_expire_time,
								"countJobApplied": results.length,
								"jobApplied": results,												
							}
						});
					} else {
						res.json({
							"isSuccessful" : false,  
							"status" : res.statusCode,
							"code" : 0,
							//"message" : apiResponseMessage, 
						});
					}					
				}
			});									
		}		
	});	
	//==================================================================
	/*
	Function to view CV and marked as cv viewed by an agent.
	*/
	router.post('/cv-view', passport.authenticate('bearer', { session: false }), function (req, res) {
			
		if(req.user) {
			
			var user_id 						=	req.user[0].user.id;
			var payment_expire_time 			= 	req.user[0].user.payment_expire_time;						
				
			var apiResponseMessage 				=	config.apiResponseMessage[102];
			
			var jobApplyData 					= 	[];	
			
			req.sanitize('id').toInt();
			req.sanitize('job_id').toInt();
			
			req.assert('id', 'Invalid id').notEmpty();
			req.assert('job_id', 'Invalid job_id').notEmpty();			
			
			req.getValidationResult().then(function(result) {				
				
				if (!result.isEmpty()) {					
					res.status(400); //	BAD REQUEST
					res.json({
						"isSuccessful" : false,  
						"status" : res.statusCode,
						"code" : 0,
						"message" : result.array(),							
					});
				} else {
					var postData						=	req.body;
					jobApplyData.id						=	postData.id;
					jobApplyData.job_id					=	postData.job_id;
					
					JobApplyModel.setStatusCvViewByAgent(jobApplyData, function(error, results) {
						
						//console.log(results);			
						if (error) {    
							throw error;
						} else {
							if(results)	{
								//console.log(results);
								var affectedRows	=	results.affectedRows;
								var changedRows		=	results.changedRows;
										
									if(affectedRows>0) {
										apiResponseMessage	=	config.apiResponseMessage.JOB_APPLY[102];							
									}
								
								res.json({
									"isSuccessful" : true,  
									"status" : res.statusCode,
									"code" : 1,
									"message" : apiResponseMessage, 
									"data" : {										
										"id": jobApplyData.id,												
										"job_id": jobApplyData.job_id,												
									}
								});
							} else {
								res.json({
									"isSuccessful" : false,  
									"status" : res.statusCode,
									"code" : 0,
									"message" : apiResponseMessage, 
									"data" : {										
										"id": jobApplyData.id,												
										"job_id": jobApplyData.job_id,												
									} 
								});
							}					
						}
					});
					
				}
				
			});	
			
												
		}		
	});
	//==================================================================
	/*
	Function to view CV and marked as cv viewed by an agent.
	*/
	router.post('/hide-by-applicant', passport.authenticate('bearer', { session: false }), function (req, res) {
			
		if(req.user) {
			
			var user_id 						=	req.user[0].user.id;
			var payment_expire_time 			= 	req.user[0].user.payment_expire_time;						
				
			var apiResponseMessage 				=	config.apiResponseMessage[102];
			
			var jobApplyData 					= 	[];	
			
			req.sanitize('id').toInt();
			req.sanitize('job_id').toInt();
			
			req.assert('id', 'Invalid ID').notEmpty();
			req.assert('job_id', 'Invalid Job ID').notEmpty();
			
			
			req.getValidationResult().then(function(result) {				
				
				if (!result.isEmpty()) {					
					res.status(400); //	BAD REQUEST
					res.json({
						"isSuccessful" : false,  
						"status" : res.statusCode,
						"code" : 0,
						"message" : result.array(),							
					});
				} else {
					var postData						=	req.body;
					jobApplyData.id						=	postData.id;
					jobApplyData.job_id					=	postData.job_id;
					
					
					JobApplyModel.setStatusHideByApplicant(jobApplyData, function(error, results) {
						
						//console.log(results);			
						if (error) {    
							throw error;
						} else {
							if(results)	{
								//console.log(results);
								var affectedRows	=	results.affectedRows;
								var changedRows		=	results.changedRows;
										
									if(affectedRows>0) {
										apiResponseMessage	=	config.apiResponseMessage.JOB_APPLY[103];							
									}
								
								res.json({
									"isSuccessful" : true,  
									"status" : res.statusCode,
									"code" : 1,
									"message" : apiResponseMessage, 
									"data" : {										
										"id": jobApplyData.id,												
										"job_id": jobApplyData.job_id,												
									}
								});
							} else {
								res.json({
									"isSuccessful" : false,  
									"status" : res.statusCode,
									"code" : 0,
									"message" : apiResponseMessage, 
									"data" : {										
										"id": jobApplyData.id,												
										"job_id": jobApplyData.job_id,												
									} 
								});
							}					
						}
					});
					
				}
				
			});	
			
												
		}		
	});
	//==================================================================
	//==================================================================
	//==================================================================
	
	
	module.exports = router