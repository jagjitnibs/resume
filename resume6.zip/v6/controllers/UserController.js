	var express 			=	require('express')
	var router 				=	express.Router();
	var passport 			=	require('passport');
	//var Strategy			= 	require('passport-http-bearer').Strategy;
	var async      			= 	require('async');
	var nodeDateTime 		= 	require('node-datetime');
	var moment 				= 	require('moment');
	var unixTime			=	require('unix-time');

	var UserModel			=	require('./../models/UserModel');
	var ContactModel		=	require('./../models/ContactModel');
	var JobModel			=	require('./../models/JobModel');
	var JobApplyModel		=	require('./../models/JobApplyModel');
	var JobInviteModel		=	require('./../models/JobInviteModel');
	var NotificationModel	=	require('./../models/NotificationModel');
	var PaymentAgentModel	=	require('./../models/PaymentAgentModel');
	
	/*
	Function to get user profile.
	*/
	router.get('/profile', passport.authenticate('bearer', { session: false }), function (req, res) {
			
		if(req.user) {			
			var user_id 			=	req.user[0].user.id;
			var payment_expire_time	= 	req.user[0].user.payment_expire_time;
					
			UserModel.getUserProfileByUserId(user_id, function(error, results) {  
						
				if (error) {    
					throw error;
				} else {
					if(results) {										
						res.json({
							"isSuccessful" : true,  
							"status" : res.statusCode,
							"code" : 1,
							"message" : "User profile has been found successfully.", 
							"data" : {"SERVER_PATH_USER_PROFILE_IMAGE_THUMB":config.url+config.params.SERVER_PATH_USER_PROFILE_IMAGE_THUMB, "user": results}
						});									
					} else {
						res.json({
							"isSuccessful" : true,  
							"status" : res.statusCode,
							"code" : 0,
							"message" : "No matching record found.", 
							"data" : {"user": null}
						});
					}						
				}  
			});							
		}		
	});
	
	
	/*
	Function to update the user profile.
	*/
	router.put('/profile-update', passport.authenticate('bearer', { session: false }), function (req, res) {
			
		if(req.user) {

			//console.log('========================');
			//console.log('========================');
			var user_id 							=	req.user[0].user.id;
			var payment_expire_time					= 	req.user[0].user.payment_expire_time;
			var date_availability					= 	req.user[0].user.date_availability;
			var dateAvailabilityValidateRequired	=	false;
			
			//var currentDate 						= 	moment().format('YYYY-MM-DD'); 
			//var currentDateTimeStamp				= 	moment(currentDate, 'YYYY-MM-DD');		
			
			var dateAvailabilityOld					= 	moment.unix(date_availability).format("YYYY-MM-DD"); 		
			var dateAvailabilityOldTimeStamp		= 	moment(dateAvailabilityOld, 'YYYY-MM-DD');
						
			var postData							=	req.body;
			var dateAvailabilityNew					=	postData.date_availability;
			var dateAvailabilityNewTimeStamp		= 	moment(dateAvailabilityNew, 'YYYY-MM-DD');
			var differenceInDays					=	dateAvailabilityNewTimeStamp.diff(dateAvailabilityOldTimeStamp,'days', true);
			
			if(differenceInDays != 0) {
				dateAvailabilityValidateRequired	=	true;
			}		
		
			
			var dateTime 		=	nodeDateTime.create();
			dateTime.offsetInDays(-1);
			var yesterdayDate	=	dateTime.format('Y-m-d');
			
			//console.log('yesterdayDate = '+yesterdayDate);
			
			//req.sanitize('first_name').trim();
			//req.sanitize('last_name').trim();
			req.sanitize('location').trim();				
			req.sanitize('organization').trim();			
			req.sanitize('date_availability').trim();	
		
			//req.assert("first_name", "Invalid first name").matches(/^([a-zA-Z0-9 ]+)$/, "i");
			//req.assert("first_name", "First name must be between %1 and %2 chars long").len(config.params.USER_FIRST_NAME_LENGTH_MIN, config.params.USER_FIRST_NAME_LENGTH_MAX);
			
			//req.assert("last_name", "Invalid last name").matches(/^([a-zA-Z0-9 ]+)$/, "i");
			//req.assert("last_name", "Last name must be between %1 and %2 chars long").len(config.params.USER_LAST_NAME_LENGTH_MIN, config.params.USER_LAST_NAME_LENGTH_MAX);
			
			req.assert('location', 'Invalid location').notEmpty().matches(/^([a-zA-Z0-9-, ]+)$/, "i");
			req.assert("location", "Location must be between %1 and %2 chars long").len(config.params.LOCATION_LENGTH_MIN, config.params.LOCATION_LENGTH_MAX);
			req.assert('latitude', 'Invalid latitude').notEmpty().isDecimal();
			req.assert('longitude', 'Invalid longitude').notEmpty().isDecimal();
			
			//req.assert("organization", "Invalid organization").matches(/^([a-zA-Z0-9 ]+)$/, "i");
			req.assert("organization", "Invalid organization").matches(/^([a-zA-Z0-9&-_ ]+)$/, "i");
			req.assert("organization", "Organization must be between %1 and %2 chars long").len(config.params.ORGANIZATION_LENGTH_MIN, config.params.ORGANIZATION_LENGTH_MAX);
			
			req.assert('sub_industry_sector_id', 'Invalid sub industry sector id').optional(true).isInt();
			req.assert('sector_role_id', 'Invalid sector role id').notEmpty().isInt();
			//req.assert('job_type', 'Invalid job type').notEmpty().isInt().isIn([config.JOB.JOB_TYPE.CONTRACTOR, config.JOB.JOB_TYPE.PERMANENT]);
			req.assert('job_type', 'Invalid job type').notEmpty().isInt({ min: config.USER.SIGNUP_JOB_TYPE_CONTRACTOR, max: config.USER.SIGNUP_JOB_TYPE_OTHER });
			
			//if(req.body.job_type == config.JOB.JOB_TYPE.CONTRACTOR) {
			//if(req.body.job_type == config.JOB.JOB_TYPE.CONTRACTOR && dateAvailabilityValidateRequired) {
			if(req.body.job_type <= config.USER.SIGNUP_JOB_TYPE_SABBATICAL && dateAvailabilityValidateRequired) {
				//req.assert('date_availability', 'Invalid availability date').notEmpty().isDate().isAfter();
				req.assert('date_availability', 'You cannot select a date in the past').notEmpty().isDate().isAfter(yesterdayDate);
				req.assert('date_availability', 'Invalid availability date').notEmpty().isDate();
				req.assert('date_availability', 'Availability date required').notEmpty();
				//req.assert('date_availability', 'Invalid availability date').isDate();
				
			}
			
			//req.sanitize('first_name').escape();
			//req.sanitize('last_name').escape();
			req.sanitize('location').escape();
			req.sanitize('latitude').escape();
			req.sanitize('longitude').escape();
			//req.sanitize('organization').escape();
			req.sanitize('sub_industry_sector_id').escape();
			req.sanitize('sector_role_id').escape();
			req.sanitize('job_type').escape();
			req.sanitize('date_availability').escape();
			
			req.getValidationResult().then(function(result) {				
				
				if (!result.isEmpty()) {
					
					res.status(400); //	BAD REQUEST
					res.json({
						"isSuccessful" : false,  
						"status" : res.statusCode,
						"code" : 0,
						"message" : result.mapped(),							
					});
				} else {						
					
					var user_id 			=	req.user[0].user.id;
					var payment_expire_time	= 	req.user[0].user.payment_expire_time;				
					var postData			=	req.body;
					
					UserModel.profileUpdateByUserId(user_id, postData, function(error, results) {  
						
						if (error) {    
							throw error;
						} else {
							if(results) {
								UserModel.getUserProfileByUserId(user_id, function(error, results) {  
						
									if (error) {    
										throw error;
									} else {
										if(results) {										
											res.json({
												"isSuccessful" : true,  
												"status" : res.statusCode,
												"code" : 1,
												"message" : "Your profile has been updated successfully.", 
												"data" : {"user": results}
											});									
										} else {
											res.json({
												"isSuccessful" : true,  
												"status" : res.statusCode,
												"code" : 0,
												"message" : "No matching record found.", 
												"data" : {"user": null}
											});
										}						
									}  
								});
							} else {
								res.json({
									"isSuccessful" : true,  
									"status" : res.statusCode,
									"code" : 0,
									"message" : "No matching record found.", 
									"data" : {											
												"affectedRows": results.affectedRows,
												"changedRows": results.changedRows,
												"user": null,											
											}
								});
							}						
						}  
					});
				}				
			});							
		}		
	});
	
	
	
	/*
	Function to get user dashboard data.
	*/
	router.get('/dashboard', passport.authenticate('bearer', { session: false }), function (req, res) {
			
		if(req.user) {			
			var user_id 			=	req.user[0].user.id;
			var payment_expire_time	= 	req.user[0].user.payment_expire_time;
					
			res.json({
				"isSuccessful" : true,  
				"status" : res.statusCode,
				"code" : 1,
				"message" : "Dashboard data has been found successfully.", 
				"data" : {
							"count_associates": Math.floor((Math.random() * 999) + 1), 
							"count_cv_review": Math.floor((Math.random() * 999) + 1), 
							"count_broadcast_job": Math.floor((Math.random() * 9999) + 1), 
							"count_exclusive_job": Math.floor((Math.random() * 999) + 1),							
						}
			});							
		} else {
			res.json({
				"isSuccessful" : true,  
				"status" : 401,
				"code" : 0,
				"message" : "User not found.", 
				"data" : {
							"count_associates": 0, 
							"count_cv_review": 0, 
							"count_broadcast_job": 0, 
							"count_exclusive_job": 0,							
						}
			});	
		}		
	});
	
	
	/*
	Function to get user dashboard data.
	*/
	router.get('/dashboard-new', passport.authenticate('bearer', { session: false }), function (req, res) {
		
		if(req.user) {
				
			var user_id 						=	req.user[0].user.id;
			var payment_expire_time 			= 	req.user[0].user.payment_expire_time;
			
			/*
			var pathViewAttachment 				= 	null;
			var countJobPublishTypeContacts 	= 	0;
			var countJobPublishTypeContactChild	=	0;
			var countJobPublishTypeBroadcast 	= 	0;
			var jobPublishTypeContacts			=	null;
			var jobPublishTypeContactChild 		= 	null;
			var jobPublishTypeBroadcast 		=	null;
			*/
		
			//var return_data 					= 	{};
			var return_data 					= 	[];

			async.parallel([
			
				function(parallel_done) {
					ContactModel.getContactCountByUserId(function(error, results) {											
						if (error) {    
							return parallel_done(error);
						} else {  
							if(results) {
								//console.log('results = '+ JSON.stringify(results, null, 2));
								return_data.count_associates	=	results[0]['count_associates'];
								
							} 		
							parallel_done();	
						}  
					});					
				},
				function(parallel_done) {
					JobApplyModel.getCountCvNotViewByAgentByUserId(function(error, results) {											
						if (error) {    
							return parallel_done(error);
						} else {  
							if(results) {
								//console.log('results = '+ JSON.stringify(results, null, 2));
								return_data.count_cv_review	=	results[0]['count_cv_review'];
							} 		
							parallel_done();	
						}  
					});					
				},
				function(parallel_done) {					
					JobModel.getCountAvailableBroadcastedJobsByUserId(function(error, results) {						
						if (error) {    
							return parallel_done(error);
						} else {  
							if(results) {
								//console.log('results = '+ JSON.stringify(results, null, 2));
								return_data.count_broadcast_job	=	results[0]['count_broadcast_job'];
							} 	
							parallel_done();							
						}  
					});
			   },
			   function(parallel_done) {					
					JobModel.getCountUnreadExclusiveJobsByUserId(function(error, results) {						
						if (error) {    
							return parallel_done(error);
						} else {  
							if(results) {
								console.log('results = '+ JSON.stringify(results, null, 2));
								return_data.count_exclusive_job	=	results[0]['count_exclusive_job'];
							} 	
							parallel_done();							
						}  
					});
			   },
			], function(error) {
				
				if (error) {    
					throw error;
				} else { 
					//dbConnection.end();						
					res.json({
						"isSuccessful" : true,  
						"status" : res.statusCode,
						"code" : 1,
						"message" : "Dashboard data has been found successfully.",
						"data" : {
									"count_associates": return_data.count_associates, 
									"count_cv_review": return_data.count_cv_review, 
									"count_broadcast_job": return_data.count_broadcast_job, 
									"count_exclusive_job": return_data.count_exclusive_job,								
								}
					});
				}			
			});
		}
	});
	
	
	/*
	Function to get user dashboard data.
	*/
	router.post('/dashboard-new', passport.authenticate('bearer', { session: false }), function (req, res) {
		
		if(req.user) {
				
			var user_id 						=	req.user[0].user.id;
			var payment_expire_time 			= 	req.user[0].user.payment_expire_time;
			
			/*
			var pathViewAttachment 				= 	null;
			var countJobPublishTypeContacts 	= 	0;
			var countJobPublishTypeContactChild	=	0;
			var countJobPublishTypeBroadcast 	= 	0;
			var jobPublishTypeContacts			=	null;
			var jobPublishTypeContactChild 		= 	null;
			var jobPublishTypeBroadcast 		=	null;
			*/
			req.sanitize('notification_id').trim();
			req.sanitize('notification_id').toInt();
			
			var postData			=	req.body;
			var notification_id		=	postData.notification_id;
		
			//console.log('notification_id = '+notification_id);
			
			if (typeof notification_id === 'undefined' || notification_id === null || parseInt(notification_id)<=0 || isNaN(notification_id)) {
				notification_id	=	0;
			} else {
				notification_id = parseInt(notification_id);
			}
			
			//console.log('notification_id = '+notification_id);
			
			//var return_data 					= 	{};
			var return_data 					= 	[];

			async.parallel([
			
				function(parallel_done) {
					ContactModel.getContactCountByUserId(function(error, results) {											
						if (error) {    
							return parallel_done(error);
						} else {  
							if(results) {
								//console.log('results = '+ JSON.stringify(results, null, 2));
								return_data.count_associates	=	results[0]['count_associates'];
								
							} 		
							parallel_done();	
						}  
					});					
				},
				function(parallel_done) {
					JobApplyModel.getCountCvNotViewByAgentByUserId(function(error, results) {											
						if (error) {    
							return parallel_done(error);
						} else {  
							if(results) {
								//console.log('results = '+ JSON.stringify(results, null, 2));
								return_data.count_cv_review	=	results[0]['count_cv_review'];
							} 		
							parallel_done();	
						}  
					});					
				},
				function(parallel_done) {					
					JobModel.getCountAvailableBroadcastedJobsByUserId(function(error, results) {						
						if (error) {    
							return parallel_done(error);
						} else {  
							if(results) {
								console.log('results = '+ JSON.stringify(results, null, 2));
								return_data.count_broadcast_job	=	parseInt(results[0]['count_broadcast_job']);
							} 	
							parallel_done();							
						}  
					});
			   },
			   function(parallel_done) {					
					JobModel.getCountUnreadExclusiveJobsByUserId({filter_type:'AVOKO'},function(error, results) {						
					
						if (error) {    
							return parallel_done(error);
						} else {  
							//if(results) {
								console.log('results AVOKO = '+ JSON.stringify(results, null, 2));
								//return_data.count_exclusive_job	=	results[0]['count_exclusive_job'];
								return_data.count_exclusive_job_create_by_admin	=	parseInt(results);
							//} 	
							parallel_done();							
						}  
					});
			   },
			   function(parallel_done) {					
					JobModel.getCountUnreadExclusiveJobsByUserId({filter_type:'ASSOCIATE'},function(error, results) {						
					
						if (error) {    
							return parallel_done(error);
						} else {  
							//if(results) {
								//console.log('results = '+ JSON.stringify(results, null, 2));
								//return_data.count_exclusive_job	=	results[0]['count_exclusive_job'];
								return_data.count_exclusive_job	=	parseInt(results);
							//} 	
							parallel_done();							
						}  
					});
			   },
			   function(parallel_done) {					
					NotificationModel.getUnreadNotificationCountById(notification_id, function(error, results) {						
						if (error) {    
							return parallel_done(error);
						} else {  
							if(results) {
								//console.log('results = '+ JSON.stringify(results, null, 2));
								return_data.count_notification	=	results[0]['count_notification'];
							} 	
							parallel_done();							
						}  
					});
			   },
			   function(parallel_done) {				   
					
					PaymentAgentModel.getEarningTotalByUserId(function(error, results) {
						
						if (error) {    
							return parallel_done(error);
						} else {  
							if(results) {
								return_data.earning_total	=	results[0].total;
							} 	
							parallel_done();							
						}  
					});
			   },
			], function(error) {
				
				if (error) {    
					throw error;
				} else { 
					//dbConnection.end();						
					res.json({
						"isSuccessful" : true,  
						"status" : res.statusCode,
						"code" : 1,
						"message" : "Dashboard data has been found successfully.",
						"data" : {
									"count_associates": return_data.count_associates, 
									"count_cv_review": return_data.count_cv_review, 
									"count_broadcast_job": return_data.count_broadcast_job+return_data.count_exclusive_job_create_by_admin, 
									"count_exclusive_job": return_data.count_exclusive_job,								
									"count_notification": return_data.count_notification,								
									"earning_total": return_data.earning_total,								
									//"count_notification": 0,								
								}
					});
				}			
			});
		}
	});
	
	module.exports = router