	var fs 			= 	require("fs");	
	var thumb		=	require('node-thumbnail').thumb;
	var randomize	= 	require('randomatic');
	
	var helpers = {

		// Function : Get mobile app introduction data.
		getAppIntroductionData  : function () {
			
			var list_data	=	{
									'beforeSignup_1'		:	[
																	"Unlocking the Power of Talent Advocacy",
																	"Add and Forward Jobs",
																	"Share your jobs and the networks jobs. Easy!",
																],
									'beforeSignup_2'		:	[
																	"Unlocking the Power of Talent Advocacy",
																	"Apply or Refer Connections",
																	"Access to exclusive jobs. Powerful!",
																],
									'beforeSignup_3'		:	[
																	"Unlocking the Power of Talent Advocacy",
																	"Expand Networks",
																	"Increase opportunities to find and fill great roles. Simple!",
																],
									'beforeSignup_4'		:	[
																	"Unlocking the Power of Talent Advocacy",
																	"Earn Money",
																	"Everybody in the chain earns £'s every month. Lots!",
																],							
									'pushNotification_1' 	: 	'pushNotification_1: Dummy Text', 
									'pushNotification_2' 	: 	'pushNotification_2: Dummy Text', 
									'appTour_1' 			: 	'appTour_1: Dummy Text', 
									'appTour_2' 			: 	'appTour_2: Dummy Text', 
									'appTour_3' 			: 	'appTour_3: Dummy Text',
								};
			return list_data;
		},
		
		
		// Function : Get size Of base64 encoded string
		sizeOfBase64EncodedString  : function (dataString) {

			var filesize_byte	=	Math.round(dataString.length*3/4);
			var filesize_kb 	=	filesize_byte/1000;

			//console.log('filesize_byte = '+filesize_byte);
			//console.log('filesize_kb = '+filesize_kb);
			
			return filesize_kb;
		},
		
		
		// Function : Get Base64 image data.
		decodeBase64Image  : function (dataString) {

			var matches = dataString.match(/^data:([A-Za-z-+\/]+);base64,(.+)$/);
			var response = {};

			if (matches.length !== 3) {
				return new Error('Invalid input string');
			}

			response.type = matches[1];
			response.data = new Buffer(matches[2], 'base64');

			return response;
		},
		
		
		// Function : Get Base64 image extension.
		decodeBase64ImageType  : function (dataString) {

			var imageTypeRegularExpression	=	/\/(.*?)$/;   
			var matches 					= 	dataString.match(/^data:([A-Za-z-+\/]+);base64,(.+)$/);
			var response 					= 	{};

			if (matches.length !== 3) {
				return new Error('Invalid input string');
			}
			
			var image_type 			= 	matches[1];
			var imageTypeDetected	= 	image_type.match(imageTypeRegularExpression);

			return imageTypeDetected[1];
		},
				
		// Function : Get random alphanumeric string.
		getRandomStringAlphaNumeric  : function () {
			var timestamp 			=	Math.floor(Date.now() / 1000);
			var crypto              =	require('crypto');
			var seed                = 	crypto.randomBytes(20);
			var uniqueSHA1String	= 	crypto.createHash('sha1').update(seed).digest('hex');
			var string				=	timestamp+uniqueSHA1String;
			return string;
		},
		
		
		// Function : Get job reference number randomly.
		getJobReferenceNumber : function (sector_role_title) {
			
			var string_length	=	config.JOB.REFERENCE_NUMBER_LENGTH;
			var prefix_one		=	config.JOB.REFERENCE_NUMBER_PREFIX;						
			var prefix_two		=	sector_role_title+"-";

			if (typeof sector_role_title === 'undefined' || sector_role_title === null || sector_role_title==="") {
				sector_role_title	=	null;
			}
			
			//var string	=	randomize('Aa0!', 10);
			var string	=	randomize('A0', string_length);
			return prefix_one+prefix_two+string;
		},
		
		
		// Function to upload the image file.
		uploadImage : function (filename, filedata) {
			
			// Save base64 image to disk
			try
			{
				// Regular expression for image type:
				// This regular image extracts the "jpeg" from "image/jpeg"
				var imageTypeRegularExpression      	=	/\/(.*?)$/;      

				var base64Data 							= 	filedata;

				var imageBuffer                     	= 	this.decodeBase64Image(base64Data);					
				var userUploadedFeedMessagesLocation	=	'../../../'+config.params.SERVER_PATH_USER_PROFILE_IMAGE;

				//var uniqueRandomImageName            	= 	'image-' + uniqueSHA1String;
				// This variable is actually an array which has 5 values,
				// The [1] value is the real image extension
				var imageTypeDetected                	= 	imageBuffer.type.match(imageTypeRegularExpression);
				
				var filename							=	filename + '.' + imageTypeDetected[1];
				var userUploadedImagePath            	= 	userUploadedFeedMessagesLocation + filename;

				// Save decoded binary image to disk
				try {
					fs.writeFile(userUploadedImagePath, imageBuffer.data,  
						function() {					  
							thumb({
								source: userUploadedImagePath, // could be a filename: dest/path/image.jpg 
								destination: '../../../'+config.params.SERVER_PATH_USER_PROFILE_IMAGE_THUMB,		
								prefix: '',
								suffix: '',
								digest: false,
								hashingType: 'sha1', // 'sha1', 'md5', 'sha256', 'sha512' 
								width: config.params.IMAGE_THUMB_W90,
								concurrency: 100,
								quiet: false, // if set to 'true', console.log status messages will be supressed 
								overwrite: true,
								basename: undefined, // basename of the thumbnail. If unset, the name of the source file is used as basename. 
								ignore: false, // Ignore unsupported files in "dest"  
							}, function(files, error, stdout, stderr) {
								if (error) { 
									throw error; 
								}
								//console.log('All done!');
							});						  
							return filename;
					});
				}
				catch(error) {
					console.log('ERROR:', error);
				}

			}
			catch(error) {
				console.log('ERROR:', error);
			}
		},
		
		
		
		// Function to upload the image file.
		uploadJobAttachmentFile : function (filename, filedata) {
			
			// Save base64 image to disk
			try
			{
				// Regular expression for image type:
				// This regular image extracts the "jpeg" from "image/jpeg"
				var imageTypeRegularExpression      	=	/\/(.*?)$/;      

				var base64Data 							= 	filedata;

				var imageBuffer                     	= 	this.decodeBase64Image(base64Data);					
				var userUploadedFeedMessagesLocation	=	'../../'+config.params.SERVER_PATH_JOB_ATTACHMENT;

				//var uniqueRandomImageName            	= 	'image-' + uniqueSHA1String;
				// This variable is actually an array which has 5 values,
				// The [1] value is the real image extension
				var imageTypeDetected                	= 	imageBuffer.type.match(imageTypeRegularExpression);
				
				var filename							=	filename + '.' + imageTypeDetected[1];
				var userUploadedImagePath            	= 	userUploadedFeedMessagesLocation + filename;

				// Save decoded binary image to disk
				try {
					fs.writeFile(userUploadedImagePath, imageBuffer.data,  
						function() {					  
							thumb({
								source: userUploadedImagePath, // could be a filename: dest/path/image.jpg 
								destination: '../../'+config.params.SERVER_PATH_USER_PROFILE_IMAGE_THUMB,		
								prefix: '',
								suffix: '',
								digest: false,
								hashingType: 'sha1', // 'sha1', 'md5', 'sha256', 'sha512' 
								width: config.params.IMAGE_THUMB_W90,
								concurrency: 100,
								quiet: false, // if set to 'true', console.log status messages will be supressed 
								overwrite: true,
								basename: undefined, // basename of the thumbnail. If unset, the name of the source file is used as basename. 
								ignore: false, // Ignore unsupported files in "dest"  
							}, function(files, error, stdout, stderr) {
								if (error) { 
									throw error; 
								}
								//console.log('All done!');
							});						  
							return filename;
					});
				}
				catch(error) {
					console.log('ERROR:', error);
				}

			}
			catch(error) {
				console.log('ERROR:', error);
			}
		},
		
		
		/* // Function : Convert the reward data to cumulative data.
		convertRewardDataToCumulativeData  : function (graphStartYear, graphStartMonth, graphData) {
			
			console.log('convertRewardDataToCumulativeData');
			console.log('graphStartYear = '+graphStartYear);
			console.log('graphStartMonth = '+graphStartMonth);
						
			//console.log('.......1111111111111111111');
			//console.log(graphData);
			//console.log('.......1111111111111111111');
		
			var graphEndYear 		= 	graphStartYear;
			var graphEndMonth		=	graphStartMonth+6;
			
			if(graphEndMonth>12) {
				graphEndYear	=	graphStartYear+1;
				graphEndMonth = (graphEndMonth-12)-1;				
			}
			
			console.log('graphEndYear = '+graphEndYear);
			console.log('graphEndMonth = '+graphEndMonth);
			
			var rewardCumulativeData 		= 	[];
			var rewardCumulativeDataFinal	=	[];
			
			var timesheet_year 			= 	parseInt(graphData[0].timesheet_year);
			var timesheet_month_min 	= 	parseInt(graphData[0].timesheet_month);
			var timesheet_month_max 	= 	parseInt(graphData[graphData.length-1].timesheet_month);
			
			//console.log('timesheet_month_min = '+timesheet_month_min);
			//console.log('timesheet_month_max = '+timesheet_month_max);
			
			//----------------------------------------------
			// CODE START :: ADD THE MISSING MONTHS IN RESULT.
			//----------------------------------------------
			for (var month=1; month<=12; month++) {
				
				//console.log('month='+month);
				var monthExist	=	false;
				for (var j=0; j<graphData.length; j++) {
					//console.log('j='+j);
					
					var timesheet_month 	= 	parseInt(graphData[j].timesheet_month);
					//console.log('timesheet_month='+timesheet_month);
					if(month === timesheet_month) {
						monthExist	=	true;
					}					
				}
				
				//console.log('monthExist='+monthExist);
				if(monthExist == false) { 
					
					rewardCumulativeData[month-1] = {
						timesheet_year:   timesheet_year,
						timesheet_month: month,
						commission_amount_total: 0
					};
				
				} else {
					//console.log('else month='+month);
					
					for (var k=0; k<graphData.length; k++) {
						//console.log('k='+k);
						
						var timesheet_month 	= 	parseInt(graphData[k].timesheet_month);
						//console.log('timesheet_month='+timesheet_month);
						if(month === timesheet_month) {
														
							rewardCumulativeData[month-1] = {
								timesheet_year:   parseInt(graphData[k].timesheet_year),
								timesheet_month: parseInt(graphData[k].timesheet_month),
								commission_amount_total: parseInt(graphData[k].commission_amount_total)
							};
						}					
					}
				}
			}	
			//----------------------------------------------
			// CODE END :: ADD THE MISSING MONTHS IN RESULT.
			//----------------------------------------------
			//console.log('...............................................222222222222222222222');
			//console.log(rewardCumulativeData);
			//console.log(JSON.stringify(rewardCumulativeData));
			//console.log('rewardCumulativeData.length === '+rewardCumulativeData.length);
			//console.log('...............................................222222222222222222222');
						
			//console.log(JSON.stringify(rewardCumulativeData));
			//console.log('...............................................333333333333333333333');
			
			//----------------------------------------------
			// CODE START :: CONVERT THE MONTHLY COMMISSION INTO CUMULATIVE COMMISSION.
			//----------------------------------------------
			for(i=0;i<rewardCumulativeData.length;i++)
			{
				var timesheet_year 			= 	rewardCumulativeData[i]['timesheet_year'];
				var timesheet_month 		=	rewardCumulativeData[i]['timesheet_month'];
				var commission_amount_total	=	parseInt(rewardCumulativeData[i]['commission_amount_total']);
				
				
				//console.log('............');
				//console.log(rewardCumulativeData[i]['timesheet_year']);
				//console.log(rewardCumulativeData[i]['timesheet_month']);
				//console.log(rewardCumulativeData[i]['commission_amount_total']);
				//console.log('............');
				
				if(i==0) {
					rewardCumulativeDataFinal[i] = {
						timesheet_year:   parseInt(rewardCumulativeData[i]['timesheet_year']),
						timesheet_month: parseInt(rewardCumulativeData[i]['timesheet_month']),
						commission_amount_total: parseInt(rewardCumulativeData[i]['commission_amount_total'])+commission_amount_total
					};
							
				} else {
					
					//console.log('rewardCumulativeDataFinal i = '+i);
					
					var timesheet_year 			= 	rewardCumulativeDataFinal[i-1]['timesheet_year'];
					var timesheet_month 		=	rewardCumulativeDataFinal[i-1]['timesheet_month'];
					var commission_amount_total	=	rewardCumulativeDataFinal[i-1]['commission_amount_total'];
					
					//console.log('............');
					//console.log('rewardCumulativeDataFinal Length = '+rewardCumulativeDataFinal.length);
					//console.log('............');
					
					//console.log(rewardCumulativeDataFinal[i-1]['timesheet_year']);
					//console.log(rewardCumulativeDataFinal[i-1]['timesheet_month']);
					//console.log(rewardCumulativeDataFinal[i-1]['commission_amount_total']);
					//console.log('............');
					
					rewardCumulativeDataFinal[i] = {
						timesheet_year:   parseInt(rewardCumulativeData[i]['timesheet_year']),
						timesheet_month: parseInt(rewardCumulativeData[i]['timesheet_month']),
						commission_amount_total: parseInt(rewardCumulativeData[i]['commission_amount_total'])+commission_amount_total
					};
				}							
			}			
			//----------------------------------------------
			// CODE START :: CONVERT THE MONTHLY COMMISSION INTO CUMULATIVE COMMISSION.
			//----------------------------------------------
			
			//console.log('...............................................333333333333333333333');
			
			return rewardCumulativeDataFinal;
		}, */
		
		
		/*
		// Function : Convert the reward data to cumulative data.
		convertRewardDataToCumulativeData  : function (commission_amount_total_history, graphStartYear, graphStartMonth, graphData) {
			
			//console.log('convertRewardDataToCumulativeData');
			//console.log('graphStartYear = '+graphStartYear);
			//console.log('graphStartMonth = '+graphStartMonth);
			
			var firstMonthOfYear	=	1;
			var lastMonthOfYear		=	12;
			var totalMonthInYear	=	12;
			var showGarphMaxMonth	=	6;
			var yearIncrement		=	1;
			
			//console.log('.......1111111111111111111');
			//console.log(graphData);
			//console.log('.......1111111111111111111');
		
			var graphStartYear 		=  	parseInt(graphStartYear);
			var graphStartMonth		=	parseInt(graphStartMonth);
			
			var graphEndYear 		= 	graphStartYear;
			var graphEndMonth		=	graphStartMonth+showGarphMaxMonth;
			
			if(graphEndMonth > totalMonthInYear) {
				graphEndYear	=	graphStartYear+yearIncrement;
				graphEndMonth 	=	(graphEndMonth-totalMonthInYear)-1;				
			}
			
			//console.log('graphEndYear = '+graphEndYear);
			//console.log('graphEndMonth = '+graphEndMonth);
			
			var rewardCumulativeDataStep1 	= 	[];
			//var rewardCumulativeDataStep2 = 	[];
			var rewardCumulativeData 		= 	[];
			var rewardCumulativeDataFinal	=	[];
			
			var count = 0;
			
			//----------------------------------------------
			// CODE START :: STEP-1 :: CREATE BLANK ARRAY OF 6 MONTHS OF COMMISSION
			//----------------------------------------------
			if(graphStartYear == graphEndYear) {
				
				//console.log('graphStartYear = graphEndYear');
				
				for(i=graphStartMonth; i<graphStartMonth+showGarphMaxMonth; i++) {
					
					rewardCumulativeDataStep1[count] = {
						timesheet_year:   graphStartYear,
						timesheet_month: i,
						commission_amount_total: 0
					};
					count++;
				}				
				//console.log('rewardCumulativeDataStep1='+rewardCumulativeDataStep1);
				
				
			} else if (graphEndYear > graphStartYear) {
				
				//console.log('Graph data have 2 years...');
				
				for(i=graphStartMonth; i<=lastMonthOfYear; i++) {
					
					//console.log('graphStartYear - graphStartMonth - i  ='+i);
					
					rewardCumulativeDataStep1[count] = {
						timesheet_year:   graphStartYear,
						timesheet_month: i,
						commission_amount_total: 0
					};
					count++;
				}
				//console.log('rewardCumulativeDataStep1 2 ='+JSON.stringify(rewardCumulativeDataStep1));			
				//console.log('graphStartMonth ='+graphStartMonth);
				
				for(i=firstMonthOfYear; i<=graphEndMonth; i++) {
					
					//console.log('graphEndYear - graphEndMonth - i  ='+i);
					
					rewardCumulativeDataStep1[count] = {
						timesheet_year:   graphEndYear,
						timesheet_month: i,
						commission_amount_total: 0
					};
					count++;
				}
				//console.log('rewardCumulativeDataStep1 3 ='+JSON.stringify(rewardCumulativeDataStep1));
			}
			
			//----------------------------------------------
			// CODE END :: STEP-1 :: CREATE BLANK ARRAY OF 6 MONTHS OF COMMISSION
			//----------------------------------------------
			
			
			//----------------------------------------------
			// CODE START :: STEP-2 :: ASSIGN VALUES TO BLANK ARRAY OF 6 MONTHS COMMISSION
			//----------------------------------------------
			for (var i=0; i<rewardCumulativeDataStep1.length; i++) {
				
				var step1_timesheet_year 			= 	parseInt(rewardCumulativeDataStep1[i].timesheet_year);
				var step1_timesheet_month 			= 	parseInt(rewardCumulativeDataStep1[i].timesheet_month);
					
				for (var j=0; j<graphData.length; j++) {
										
					var timesheet_year 			= 	parseInt(graphData[j].timesheet_year);
					var timesheet_month 		= 	parseInt(graphData[j].timesheet_month);
					var commission_amount_total = 	parseFloat(graphData[j].commission_amount_total);
					
					if((step1_timesheet_year === timesheet_year) && (step1_timesheet_month===timesheet_month)) {
						
						rewardCumulativeDataStep1[i] = {
							timesheet_year:   timesheet_year,
							timesheet_month: timesheet_month,
							commission_amount_total: commission_amount_total
						};
					}										
				}				
			}
			//----------------------------------------------
			// CODE END :: STEP-2 :: ASSIGN VALUES TO BLANK ARRAY OF 6 MONTHS COMMISSION
			//----------------------------------------------
			
			
			
			
			//----------------------------------------------
			// CODE START :: STEP-3 :: CONVERT THE MONTHLY COMMISSION INTO CUMULATIVE COMMISSION.
			//----------------------------------------------
			for (var i=0; i<rewardCumulativeDataStep1.length; i++) {			
				
				if(i==0) {
					
					rewardCumulativeDataFinal[i] = {
						commission_amount_total_history: parseFloat(commission_amount_total_history),
						commission_amount: parseFloat(rewardCumulativeDataStep1[i]['commission_amount_total']),
						timesheet_year: parseInt(rewardCumulativeDataStep1[i]['timesheet_year']),
						timesheet_month: parseInt(rewardCumulativeDataStep1[i]['timesheet_month']),
						commission_amount_total: parseFloat(commission_amount_total_history) + parseFloat(rewardCumulativeDataStep1[i]['commission_amount_total'])
					};
							
				} else {
					
					var timesheet_year 			= 	rewardCumulativeDataFinal[i-1]['timesheet_year'];
					var timesheet_month 		=	rewardCumulativeDataFinal[i-1]['timesheet_month'];
					var commission_amount_total	=	rewardCumulativeDataFinal[i-1]['commission_amount_total'];					
									
					rewardCumulativeDataFinal[i] = {
						commission_amount_total_history: parseFloat(commission_amount_total_history),
						commission_amount: parseFloat(rewardCumulativeDataStep1[i]['commission_amount_total']),
						timesheet_year: parseInt(rewardCumulativeDataStep1[i]['timesheet_year']),
						timesheet_month: parseInt(rewardCumulativeDataStep1[i]['timesheet_month']),
						commission_amount_total: parseFloat(rewardCumulativeDataStep1[i]['commission_amount_total'])+commission_amount_total
					};
				}
			}			
			//----------------------------------------------
			// CODE END :: STEP-3 :: CONVERT THE MONTHLY COMMISSION INTO CUMULATIVE COMMISSION.
			//----------------------------------------------
			
			//return rewardCumulativeDataStep1;
			return rewardCumulativeDataFinal;
		},
		*/
		
		
		
		
		// Function : Convert the reward data to cumulative data.
		convertRewardDataToCumulativeData  : function (commission_amount_total_history, graphStartYear, graphStartMonth, graphData) {
			
			//console.log('convertRewardDataToCumulativeData');
			//console.log('graphStartYear = '+graphStartYear);
			//console.log('graphStartMonth = '+graphStartMonth);
			
			var firstMonthOfYear	=	1;
			var lastMonthOfYear		=	12;
			var totalMonthInYear	=	12;
			var showGarphMaxMonth	=	6;
			var yearIncrement		=	1;
			
			//console.log('.......1111111111111111111');
			//console.log(graphData);
			//console.log('.......1111111111111111111');
		
			var graphStartYear 		=  	parseInt(graphStartYear);
			var graphStartMonth		=	parseInt(graphStartMonth);
			
			var graphEndYear 		= 	graphStartYear;
			var graphEndMonth		=	graphStartMonth+showGarphMaxMonth;
			
			if(graphEndMonth > totalMonthInYear) {
				graphEndYear	=	graphStartYear+yearIncrement;
				graphEndMonth 	=	(graphEndMonth-totalMonthInYear)-1;				
			}
			
			//console.log('graphEndYear = '+graphEndYear);
			//console.log('graphEndMonth = '+graphEndMonth);
			
			var rewardCumulativeDataStep1 	= 	[];
			//var rewardCumulativeDataStep2 = 	[];
			var rewardCumulativeData 		= 	[];
			var rewardCumulativeDataFinal	=	[];
			
			var count = 0;
			
			//----------------------------------------------
			// CODE START :: STEP-1 :: CREATE BLANK ARRAY OF 6 MONTHS OF COMMISSION
			//----------------------------------------------
			if(graphStartYear == graphEndYear) {
				
				//console.log('graphStartYear = graphEndYear');
				
				for(i=graphStartMonth; i<graphStartMonth+showGarphMaxMonth; i++) {
					
					rewardCumulativeDataStep1[count] = {
						timesheet_year:   graphStartYear,
						timesheet_month: i,
						commission_amount_total: 0
					};
					count++;
				}				
				//console.log('rewardCumulativeDataStep1='+rewardCumulativeDataStep1);
				
				
			} else if (graphEndYear > graphStartYear) {
				
				//console.log('Graph data have 2 years...');
				
				for(i=graphStartMonth; i<=lastMonthOfYear; i++) {
					
					//console.log('graphStartYear - graphStartMonth - i  ='+i);
					
					rewardCumulativeDataStep1[count] = {
						timesheet_year:   graphStartYear,
						timesheet_month: i,
						commission_amount_total: 0
					};
					count++;
				}
				//console.log('rewardCumulativeDataStep1 2 ='+JSON.stringify(rewardCumulativeDataStep1));			
				//console.log('graphStartMonth ='+graphStartMonth);
				
				for(i=firstMonthOfYear; i<=graphEndMonth; i++) {
					
					//console.log('graphEndYear - graphEndMonth - i  ='+i);
					
					rewardCumulativeDataStep1[count] = {
						timesheet_year:   graphEndYear,
						timesheet_month: i,
						commission_amount_total: 0
					};
					count++;
				}
				//console.log('rewardCumulativeDataStep1 3 ='+JSON.stringify(rewardCumulativeDataStep1));
			}
			
			//----------------------------------------------
			// CODE END :: STEP-1 :: CREATE BLANK ARRAY OF 6 MONTHS OF COMMISSION
			//----------------------------------------------
			
			
			//----------------------------------------------
			// CODE START :: STEP-2 :: ASSIGN VALUES TO BLANK ARRAY OF 6 MONTHS COMMISSION
			//----------------------------------------------
			for (var i=0; i<rewardCumulativeDataStep1.length; i++) {
				
				var step1_timesheet_year 			= 	parseInt(rewardCumulativeDataStep1[i].timesheet_year);
				var step1_timesheet_month 			= 	parseInt(rewardCumulativeDataStep1[i].timesheet_month);
					
				for (var j=0; j<graphData.length; j++) {
										
					var timesheet_year 			= 	parseInt(graphData[j].timesheet_year);
					var timesheet_month 		= 	parseInt(graphData[j].timesheet_month);
					var commission_amount_total = 	parseFloat(graphData[j].commission_amount_total);
					
					if((step1_timesheet_year === timesheet_year) && (step1_timesheet_month===timesheet_month)) {
						
						rewardCumulativeDataStep1[i] = {
							timesheet_year:   timesheet_year,
							timesheet_month: timesheet_month,
							commission_amount_total: commission_amount_total
						};
					}										
				}				
			}
			//----------------------------------------------
			// CODE END :: STEP-2 :: ASSIGN VALUES TO BLANK ARRAY OF 6 MONTHS COMMISSION
			//----------------------------------------------
			
			
			
			
			//----------------------------------------------
			// CODE START :: STEP-3 :: CONVERT THE MONTHLY COMMISSION INTO CUMULATIVE COMMISSION.
			//----------------------------------------------
			for (var i=0; i<rewardCumulativeDataStep1.length; i++) {			
				
				if(i==0) {
					
					rewardCumulativeDataFinal[i] = {
						commission_amount_total_history: 0,
						commission_amount: parseFloat(rewardCumulativeDataStep1[i]['commission_amount_total']),
						timesheet_year: parseInt(rewardCumulativeDataStep1[i]['timesheet_year']),
						timesheet_month: parseInt(rewardCumulativeDataStep1[i]['timesheet_month']),
						commission_amount_total: parseFloat(rewardCumulativeDataStep1[i]['commission_amount_total'])
					};
							
				} else {
					
					var timesheet_year 			= 	rewardCumulativeDataFinal[i-1]['timesheet_year'];
					var timesheet_month 		=	rewardCumulativeDataFinal[i-1]['timesheet_month'];
					var commission_amount_total	=	rewardCumulativeDataFinal[i-1]['commission_amount_total'];					
									
					rewardCumulativeDataFinal[i] = {
						commission_amount_total_history: 0,
						commission_amount: parseFloat(rewardCumulativeDataStep1[i]['commission_amount_total']),
						timesheet_year: parseInt(rewardCumulativeDataStep1[i]['timesheet_year']),
						timesheet_month: parseInt(rewardCumulativeDataStep1[i]['timesheet_month']),
						commission_amount_total: parseFloat(rewardCumulativeDataStep1[i]['commission_amount_total'])
					};
				}
			}			
			//----------------------------------------------
			// CODE END :: STEP-3 :: CONVERT THE MONTHLY COMMISSION INTO CUMULATIVE COMMISSION.
			//----------------------------------------------
			
			//return rewardCumulativeDataStep1;
			return rewardCumulativeDataFinal;
		},
		
		
		// Function : Convert the reward data to cumulative data.
		//convertForecastRewardDataToCumulativeData  : function (graphStartYear, graphStartMonth, graphData) {
		processForecastRewardDataStep1  : function (graphStartYear, graphStartMonth, graphData) {
			
			//console.log('==========================================');
			//console.log('convertForecastRewardDataToCumulativeData');
			//console.log('graphStartYear = '+graphStartYear);
			//console.log('graphStartMonth = '+graphStartMonth);
			//console.log('graphData = '+JSON.stringify(graphData,null,2));
			//console.log('==========================================');
						
			var firstMonthOfYear	=	1;
			var lastMonthOfYear		=	12;
			//var totalMonthInYear	=	12;
			var averageDaysInMonth	=	30;
			var showGarphMaxMonth	=	6;
			var yearIncrement		=	1;
			
			var defaultWorkingDays	=	19;
			
			//console.log('.......1111111111111111111');
			//console.log(graphData);
			//console.log('.......1111111111111111111');
		
			var graphStartYear 		=  	parseInt(graphStartYear);
			var graphStartMonth		=	parseInt(graphStartMonth);
			
			var graphEndYear 		= 	graphStartYear;
			var graphEndMonth		=	graphStartMonth+showGarphMaxMonth;
			
			if(graphEndMonth > lastMonthOfYear) {
				graphEndYear	=	graphStartYear+yearIncrement;
				graphEndMonth 	=	(graphEndMonth-lastMonthOfYear)-1;				
			}
			
			//console.log('graphEndYear = '+graphEndYear);
			//console.log('graphEndMonth = '+graphEndMonth);
			
			var rewardCumulativeDataStep1 	= 	[];
			//var rewardCumulativeDataStep2 = 	[];
			var rewardCumulativeData 		= 	[];
			var rewardCumulativeDataFinal	=	[];
			
			var count = 0;
			
			//----------------------------------------------
			// CODE START :: STEP-1 :: CREATE BLANK ARRAY OF 6 MONTHS OF COMMISSION
			//----------------------------------------------
			if(graphStartYear == graphEndYear) {
				
				//console.log('graphStartYear = graphEndYear');
				
				for(i=graphStartMonth; i<graphStartMonth+showGarphMaxMonth; i++) {
					
					rewardCumulativeDataStep1[count] = {
						timesheet_year:   graphStartYear,
						timesheet_month: i,
						commission_amount_total: 0
					};
					count++;
				}				
				//console.log('rewardCumulativeDataStep1='+rewardCumulativeDataStep1);
				
				
			} else if (graphEndYear > graphStartYear) {
				
				//console.log('Graph data have 2 years...');
				
				for(i=graphStartMonth; i<=lastMonthOfYear; i++) {
					
					//console.log('graphStartYear - graphStartMonth - i  ='+i);
					
					rewardCumulativeDataStep1[count] = {
						timesheet_year:   graphStartYear,
						timesheet_month: i,
						commission_amount_total: 0
					};
					count++;
				}
				//console.log('rewardCumulativeDataStep1 2 ='+JSON.stringify(rewardCumulativeDataStep1));			
				//console.log('graphStartMonth ='+graphStartMonth);
				
				for(i=firstMonthOfYear; i<=graphEndMonth; i++) {
					
					//console.log('graphEndYear - graphEndMonth - i  ='+i);
					
					rewardCumulativeDataStep1[count] = {
						timesheet_year:   graphEndYear,
						timesheet_month: i,
						commission_amount_total: 0
					};
					count++;
				}
				//console.log('rewardCumulativeDataStep1 3 ='+JSON.stringify(rewardCumulativeDataStep1));
			}
			
			//----------------------------------------------
			// CODE END :: STEP-1 :: CREATE BLANK ARRAY OF 6 MONTHS OF COMMISSION
			//----------------------------------------------
			
			
			
			
			//console.log('******************************************');
			//console.log('******************************************');
			//----------------------------------------------
			// CODE START :: STEP-2 :: CREATE ARRAY OF CONTRACTS FOR EVERY MONTH.
			//----------------------------------------------
			var contractStep1	=	[];
			var contractStep2	=	[];
			
			if(graphData.length) {
				
				for(i=0; i<graphData.length; i++) {
					
					var job_share_level 			= 	parseInt(graphData[i]['contract_commission_share_holder_job_share_level']);
					var contract_id 				= 	parseInt(graphData[i]['contract_id']);
					var contract_start_date_year 	= 	parseInt(graphData[i]['_contract_start_date_year']);
					var contract_start_date_month	=	parseInt(graphData[i]['_contract_start_date_month']);
					var contract_start_date_day 	= 	parseInt(graphData[i]['_contract_start_date_day']);
					
					var contract_end_date_year 		= 	parseInt(graphData[i]['_contract_end_date_year']);
					var contract_end_date_month 	= 	parseInt(graphData[i]['_contract_end_date_month']);
					var contract_end_date_day 		= 	parseInt(graphData[i]['_contract_end_date_day']);
					
					
					var contract_rate 				= 	parseInt(graphData[i]['contract_rate']);
					var contract_rate_type_id 		= 	parseInt(graphData[i]['contract_rate_type_id']);
					
					//console.log('contract_start_date_year = '+contract_start_date_year);
					//console.log('contract_start_date_month = '+contract_start_date_month);
					//console.log('contract_start_date_day = '+contract_start_date_day);
					//console.log('contract_end_date_year = '+contract_end_date_year);
					//console.log('contract_end_date_month = '+contract_end_date_month);
					//console.log('contract_end_date_day = '+contract_end_date_day);
					
					var count	=	0;
					if(contract_start_date_year==contract_end_date_year) {
					
						for(m=contract_start_date_month; m<=contract_end_date_month; m++) {
							
							if(m == contract_start_date_month){
								var working_days = (defaultWorkingDays*(averageDaysInMonth-contract_start_date_day+1))/averageDaysInMonth;
							} else if(m == contract_end_date_month){
								var working_days = Math.floor((defaultWorkingDays*contract_end_date_day)/averageDaysInMonth);
							} else {
								var working_days =	defaultWorkingDays;
							}
							contractStep1[count] = {
								job_share_level: job_share_level,
								contract_id: contract_id,
								contract_start_date_year: contract_start_date_year,
								contract_start_date_month: m,
								contract_start_date_day: contract_start_date_day,
								contract_end_date_year: contract_end_date_year,
								contract_end_date_month: contract_end_date_month,
								contract_end_date_day: contract_end_date_day,
								contract_rate_type_id: contract_rate_type_id,
								contract_rate: contract_rate,
								working_days: working_days,
							};
							count++;
						}
						
					} else if(contract_end_date_year > contract_start_date_year) {
						
						for(y=contract_start_date_year; y<=contract_end_date_year; y++) {
							
							if(y == contract_start_date_year) {
								
								for(m=contract_start_date_month; m<=lastMonthOfYear; m++) {
									
									if(m == contract_start_date_month){
										var working_days = (defaultWorkingDays*(averageDaysInMonth-contract_start_date_day+1))/averageDaysInMonth;
									} else {
										var working_days =	defaultWorkingDays;
									}
									contractStep1[count] = {
										job_share_level: job_share_level,
										contract_id: contract_id,
										contract_start_date_year: y,
										contract_start_date_month: m,
										contract_start_date_day: contract_start_date_day,
										contract_end_date_year: contract_end_date_year,
										contract_end_date_month: contract_end_date_month,
										contract_end_date_day: contract_end_date_day,
										contract_rate_type_id: contract_rate_type_id,
										contract_rate: contract_rate,
										working_days: defaultWorkingDays,
									};
									
									count++;
								}
							} else if((y > contract_start_date_year) && (y < contract_end_date_year))  {
								
								for(m=firstMonthOfYear; m<=lastMonthOfYear; m++) {
									
									contractStep1[count] = {
										job_share_level: job_share_level,
										contract_id: contract_id,
										contract_start_date_year: y,
										contract_start_date_month: m,
										contract_start_date_day: contract_start_date_day,
										contract_end_date_year: contract_end_date_year,
										contract_end_date_month: contract_end_date_month,
										contract_end_date_day: contract_end_date_day,
										contract_rate_type_id: contract_rate_type_id,
										contract_rate: contract_rate,
										working_days: defaultWorkingDays,
									};
									
									count++;
								}
							} else if(y == contract_end_date_year)  {
								
								for(m=firstMonthOfYear; m<=contract_end_date_month; m++) {
								
									if(m == contract_end_date_month){
										var working_days = Math.floor((defaultWorkingDays*contract_end_date_day)/averageDaysInMonth);
									} else {
										var working_days =	defaultWorkingDays;
									}
									
									contractStep1[count] = {
										job_share_level: job_share_level,
										contract_id: contract_id,
										contract_start_date_year: y,
										contract_start_date_month: m,
										contract_start_date_day: contract_start_date_day,
										contract_end_date_year: contract_end_date_year,
										contract_end_date_month: contract_end_date_month,
										contract_end_date_day: contract_end_date_day,
										contract_rate_type_id: contract_rate_type_id,
										contract_rate: contract_rate,
										working_days: working_days,
									};
									
									count++;
								}
							}
							
							
						}
					}
					//console.log('+++++++++++++++++++++++++++++++++++++++++++++');
					//console.log('contractStep1 = '+JSON.stringify(contractStep1,null,2));
					//console.log('contractStep1.length = '+contractStep1.length);
					//console.log('+++++++++++++++++++++++++++++++++++++++++++++');
				}
			}
			//----------------------------------------------
			// CODE END :: STEP-2 :: CREATE ARRAY OF CONTRACTS FOR EVERY MONTH.
			//----------------------------------------------
			
			
			
			
			//----------------------------------------------
			// CODE START :: STEP-3 :: REMOVE ENTRIES FROM CONTRACT ARRAY OTHER THAN GRAPH TIME RANGE.
			//----------------------------------------------
			
			if(contractStep1.length) {
				
				for (var c=0; c<contractStep1.length; c++) {
					
					var step1_contract_start_date_year 			= 	contractStep1[c].contract_start_date_year;
					var step1_contract_start_date_month 		= 	contractStep1[c].contract_start_date_month;
					
						
						for (var r=0; r<rewardCumulativeDataStep1.length; r++) {
				
							var step1_timesheet_year 			= 	parseInt(rewardCumulativeDataStep1[r].timesheet_year);
							var step1_timesheet_month 			= 	parseInt(rewardCumulativeDataStep1[r].timesheet_month);
							
							if((step1_contract_start_date_year == step1_timesheet_year) && (step1_contract_start_date_month == step1_timesheet_month)) {
								
								contractStep2[c] = {
									job_share_level: contractStep1[c].job_share_level,
									contract_id: contractStep1[c].contract_id,
									contract_start_date_year: contractStep1[c].contract_start_date_year,
									contract_start_date_month: contractStep1[c].contract_start_date_month,
									contract_start_date_day: contractStep1[c].contract_start_date_day,
									contract_end_date_year: contractStep1[c].contract_end_date_year,
									contract_end_date_month: contractStep1[c].contract_end_date_month,
									contract_end_date_day: contractStep1[c].contract_end_date_day,
									contract_rate_type_id: contractStep1[c].contract_rate_type_id,
									contract_rate: contractStep1[c].contract_rate,
									working_days: contractStep1[c].working_days, 
									contractor_receivable_amount: (contractStep1[c].working_days*contractStep1[c].contract_rate), 
								};
							}
						}
					
				}
				//console.log('+++++++++++++++++++++++++++++++++++++++++++++');
				//console.log('contractStep2 = '+JSON.stringify(contractStep2,null,2));
				//console.log('contractStep2.length = '+contractStep2.length);
				//console.log('+++++++++++++++++++++++++++++++++++++++++++++');	
				return contractStep2;
			}
			
			
			
			//----------------------------------------------
			// CODE END :: STEP-3 :: REMOVE ENTRIES FROM CONTRACT ARRAY OTHER THAN GRAPH TIME RANGE.
			//----------------------------------------------
			
			
			//console.log('******************************************');
			//console.log('******************************************');
			
			
			
			
			return rewardCumulativeDataFinal;
		},
		
		
		
		// Function : Send Android Push Notification.
		sendAndroidPushNotification  : function (validDeviceRegistrationToken) {
			
			//console.log('validDeviceRegistrationToken here... = '+validDeviceRegistrationToken);
			//console.log('validDeviceRegistrationToken here123... = '+JSON.stringify(validDeviceRegistrationToken));
			//console.log('validDeviceRegistrationToken length... = '+validDeviceRegistrationToken.length);
			
			var FCM 		=	require('fcm-node');
			//var serverKey	= 	'AAAA_Uzws90:APA91bFRTfSmGdx1CGdLKHgyBOox65edhEPamQ95X2NLxvSME4sXbE0jUcl7ELJoqFRlX7h2X7FjXMsgXm7SA5uwpJUVQ0yqNc5yYra7Gw9a7-bPkTB7_pmD9mpgmDp-bBAVw5pI4g9c'; //put your server key here 
			var serverKey	= 	config.params.API_KEY.FIREBASE_CLOUD_MESSAGING; //put your server key here 
			var fcm 		= 	new FCM(serverKey);
		 
			var message = { //this may vary according to the message type (single recipient, multicast, topic, et cetera) 
				// local contact
				//to: 'c3PsNZAKmMg:APA91bFyXP56izDMtcSIGoi2rEtdC1pNtHRuJgoNyRm8-oI3M36c5H0NmAaWPLh5WBDP8lRGk2IqvHdA1l1jNLq2gVFxv9DxqwAQQGzRTttc5uQ2D_bO0tomwj8-rNI34JMiTAu1TGS9', 
				
				// stdu9
				//to: 'dmcp-Gukmm0:APA91bF2ahY6sRWUAU-stGPvE03fA49L-qcXZ4ULkntwDf7EfSOQM7-pTb-aOODTr50scFVy8OWDCamfaCxgU18lYnhDw7fXePeoc7bkzr2MZTy0vHtl0NZcjv_QJsfK7I2XLp5OMfrC', 
				priority: 'high',
				content_available: true,
				//registration_ids:["c3PsNZAKmMg:APA91bFyXP56izDMtcSIGoi2rEtdC1pNtHRuJgoNyRm8-oI3M36c5H0NmAaWPLh5WBDP8lRGk2IqvHdA1l1jNLq2gVFxv9DxqwAQQGzRTttc5uQ2D_bO0tomwj8-rNI34JMiTAu1TGS9", 'eWeovmlvGIM:APA91bHecGPEcusWu6Ro430Tp15d9rK9ecvCn5q77i9GrFrzCPxlMaZzsAymTGLNO3Ypyc6hiBEPSK3-LOvhV8aAFVfZCJMJzPfgPHqeAI45LfPzh9rQ_FMwZpZOV8raNCDFdxNE08Vr',],
				registration_ids:validDeviceRegistrationToken,
				collapse_key: 'your_collapse_key',
				
				notification: {
					title: 'Title of your push notification', 
					body: 'Body of your push notification',
					sound : "default", 
					badge: "1"					
				},
				
				data: {  //you can send only notification or only data(or include both) 
					my_key: 'my value',
					my_another_key: 'my another value'
				}
			};
			
			fcm.send(message, function(err, response){
				if (err) {
					console.log("Something has gone wrong! "+err);
				} else {
					console.log("Successfully sent with response: ", response);
				}
			});
			return true;
		},
		
		
	};
	module.exports = helpers; 