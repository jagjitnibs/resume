	module.exports = function(config) {
		
		var mysql	=	require('mysql');
		
		//CODE START :: MySQL Connection
		/*
		var connection = mysql.createConnection({
		  
		  host     : config.database.host, 		//mysql database host name
		  user     : config.database.user, 		//mysql database user name
		  password : config.database.password, 	//mysql database password
		  database : config.database.db 		//mysql database name 
		  
		});

		connection.connect(function(error) {
			if (error) throw error
			console.log('Success: Database connection working!'); // Do not delete this code without any confirmation.
			console.log('Press Ctrl-C to terminate.'); // Do not delete this code without any confirmation.
			console.log("-------------------------------------"); // Do not delete this code without any confirmation.
		})
		
		return connection;
		*/
		
		var pool	=	mysql.createPool({
							connectionLimit 	: 10,
							host     			: config.database.host, 		//mysql database host name
							user     			: config.database.user, 		//mysql database user name
							password 			: config.database.password, 	//mysql database password
							database 			: config.database.db, 			//mysql database name 
							debug				: false,
							multipleStatements	: false
						});
		
		pool.getConnection(function(error) {
			if (error) throw error
			console.log('Success: Database connection working!'); // Do not delete this code without any confirmation.
			console.log('Press Ctrl-C to terminate.'); // Do not delete this code without any confirmation.
			console.log("-------------------------------------"); // Do not delete this code without any confirmation.
			
		})
		
		//CODE END :: MySQL Connection
		return pool;
	}