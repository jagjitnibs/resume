	var config	=	{
						development: {
							
							API: {
								VERSION: 'v6',
							},
							
							//Url to be used in link generation
							url: (os_hostname==serverDevelopment[2]) ? 'http://52.213.50.174/gv/' : (os_hostname==serverDevelopment[1]) ? 'http://202.164.59.237:1717/avoko_webapp_version_6_0/' : 'http://localhost/avoko_webapp_version_6_0/',
							
							port: 3030,	//	V6
							
							//MySQL connection settings
							database: {
								host:     	(os_hostname==serverDevelopment[2]) ? 'localhost' : (os_hostname==serverDevelopment[1]) ? '127.0.0.1' : '127.0.0.1',
								db:			(os_hostname==serverDevelopment[2]) ? 'avoko_z1' : (os_hostname==serverDevelopment[1]) ? 'axis_local' : 'axis_local',
								user:		(os_hostname==serverDevelopment[2]) ? 'admin' : (os_hostname==serverDevelopment[1]) ? 'root' : 'root',
								password:	(os_hostname==serverDevelopment[2]) ? '@dm1n@78945' : (os_hostname==serverDevelopment[1]) ? '' : '',
								port:     	(os_hostname==serverDevelopment[2]) ? '' : (os_hostname==serverDevelopment[1]) ? '' : '',
							},
							
							//Server details
							server: {
								host: '127.0.0.1',
								port: '3422'
							},
							
							params: {
								
								API_KEY: { 
									FIREBASE_CLOUD_MESSAGING:	'AAAA_Uzws90:APA91bFRTfSmGdx1CGdLKHgyBOox65edhEPamQ95X2NLxvSME4sXbE0jUcl7ELJoqFRlX7h2X7FjXMsgXm7SA5uwpJUVQ0yqNc5yYra7Gw9a7-bPkTB7_pmD9mpgmDp-bBAVw5pI4g9c',
								},
								
								SITE_NAME:											'Avoko',	
								SITE_NAME_HTML:										'<b>Avoko</b>',
								
								CRON_JOB_PAYMENT_AGENT_FORECAST_DATE: 				'2017-01-01',
								
								SERVER_PATH_USER_PROFILE_IMAGE:						'frontend/web/upload/images/original/',
								SERVER_PATH_USER_PROFILE_IMAGE_THUMB:				'frontend/web/upload/images/thumb/',
								SERVER_PATH_JOB_ATTACHMENT:							'upload/attachment/',
								
								USER_FIRST_NAME_LENGTH_MIN: 						2,
								USER_FIRST_NAME_LENGTH_MAX: 						35,
								USER_LAST_NAME_LENGTH_MIN:							2,
								USER_LAST_NAME_LENGTH_MAX:							35,
								
								TITLE_LENGTH_MIN:									2,
								TITLE_LENGTH_MAX:									35,	
								
								MOBILE_LENGTH_MIN:									2,
								MOBILE_LENGTH_MAX:									16,
								
								FULL_NAME_LENGTH_MIN:								2,
								FULL_NAME_LENGTH_MAX:								35,
								
								ORGANIZATION_LENGTH_MIN:							2,
								ORGANIZATION_LENGTH_MAX:							35,	

								LOCATION_LENGTH_MIN:								2,
								LOCATION_LENGTH_MAX:								250,	
								
								IMAGE_THUMB_W90:									200,	
								SQL_LIMIT_JOB:										20,	
								SQL_LIMIT_NOTIFICATION:								50,	
								
								STATUS_DELETE:										0,	
								STATUS_BLOCKED:										1,
								STATUS_ACTIVE:										2,									
																
								DEBIT_CREDIT_C:										'C',									
								DEBIT_CREDIT_D:										'D',									
								
								DEFAULT_WORKING_DAYS_IN_MONTH: 						19,
								
								MOBILE_BUILD_VERSION_STATUS_FORCEFUL_UPDATE_NO:		0,
								MOBILE_BUILD_VERSION_STATUS_FORCEFUL_UPDATE_YES:	1,
								
								MOBILE_BUILD_VERSION_STATUS_LIVE_NO:				1,
								MOBILE_BUILD_VERSION_STATUS_LIVE_YES:				1,
								
								DB_TABLE_MOBILE_BUILD_VERSION_IOS:					'mobile_build_version_ios',
								DB_TABLE_MOBILE_BUILD_VERSION_ANDROID:				'mobile_build_version_android',
								
								
								
								JOB_COLOR: { 
									CONTRACTOR:	"#52BE80",
									PENDING:	"#BDBDBD",
									INVITE: 	"#FFA500",
									BROADCAST: 	"#00FFFF"			
								},
							},
							
							apiResponseMessage: {	
								101: "Records has been found successfully.",
								102: "No matching records found.",
								INVITE: { 
									101: "Job marked as reviewed.",						
								},
								CONTRACT: { 
									101: "Job Awarded",						
								},
								JOB: { 
									101: "Your job has been shared with your selected connections.<br><br>You can now view this job in the Added by Me tab with full real time activity statuses.",
									102: "This job has been shared with your selected connections who have not previously received it from other Avoko networks.<br><br>Real time statuses can be viewed in your Shared Jobs tab.",
									103: "This job has already been shared with all selected connections.",
									104: "Job was deleted by creator.",
									105: "You can not share your own jobs.",
									106: "Job has been expired.",
									107: "Jobs list has been found successfully.",
									108: "Unable to share further as the maximum referral chain of 3 has been reached.",
									109: "Job not found.",
									110: "Job details has been found successfully.",
								},
								JOB_APPLY: { 
									101: "List of applied jobs has been found successfully.",
									102: "CV marked as reviewed.",
									103: "Job apply record has been removed successfully.",
									CV_APPLY: "Applied for this job",
									SENT_TO_AVOKO: "Sent to Avoko for review",
									SENT_TO_HR: "Submitted to Hiring Manager",
								},
								PAGE: { 
									101: "Page content has been found successfully.",									
								},
								NEWS: { 
									101: "List of news has been found successfully.",									
								},
								NOTIFICATION: { 
									101: "List of notifications has been found successfully.",									
								},
								TALE: { 
									101: "We do not have your bank details. Log into the web portal and update your details.",									
								},
								PAYMENT_AGENT: { 
									101: "No funds available for cash out.",
									102: "Payment request has been created successfully.",							
								},
								FEEDBACK: { 
									101: "Your feedback has been sent successfully.",						
								},								
							},
							
							FEEDBACK: {
								DESCRIPTION: { 
									MIN: 1,
									MAX: 1000
								},								
							},
							
							INVITE: {							
								STATUS_JOB_VIEW_BY_INVITED_USER_PENDING:	null,
								STATUS_JOB_VIEW_BY_INVITED_USER_DONE:		1,							
							},
							
							JOB_APPLY: { 
								STATUS_CV_NOT_SEND_TO_EXPERT:			0,
								STATUS_CV_SENT_TO_EXPERT :				1,
								STATUS_CV_REJECTED_BY_EXPERT:			2,
								STATUS_CV_ACCEPTED_BY_EXPERT:			3,
								STATUS_CV_SUBMITTED_TO_HIRING_MANAGER:	4,
								
								STATUS_CV_DIRECT_RECEIVE_NO: 			null,
								STATUS_CV_DIRECT_RECEIVE_YES:			1,
								
								STATUS_DELETE_NO:						0,
								STATUS_DELETE_YES:						1,
								
								STATUS_CV_VIEW_BY_AGENT_NO:				null,
								STATUS_CV_VIEW_BY_AGENT_YES:			1,
								
								STATUS_HIDE_BY_APPLICANT_NO:			0,
								STATUS_HIDE_BY_APPLICANT_YES:			1,								
							},
							
							CONTRACT: {
								STATUS_ADMIN_PENDING:	1,
								STATUS_ADMIN_REFUSED:	2,	
								STATUS_ADMIN_SIGNED:	3,
							},
							
							CURRENCY: {	
								ID: { 
									1: 'GBP',
									2: 'EURO',
								},							
							},							
							
							DURATION_TYPE: {	
								ID: { 
									1:	'Hour(s)',
									2:	'Day(s)',
									3:	'Week(s)',
									4:	'Month',
									5:	'Year(s)',
								},							
							},
							
							JOB: {
								REFERENCE_NUMBER_PREFIX:   		"GV-",
								REFERENCE_NUMBER_LENGTH:   		10,
								END_DATE_MAX:   				'2037-12-31',
								
								//JOB_TYPE_CONTRACT:   			1,
								//JOB_TYPE_PERMANENT:   		2,

								//JOB_PUBLISH_TYPE_PENDING:   	0,
								//JOB_PUBLISH_TYPE_CONTACTS:   	1,
								//JOB_PUBLISH_TYPE_BROADCAST:	2,

								//STATUS_BLOCKED:   				1,
								//STATUS_ACTIVE:   				2,	

								//STATUS_DELETE_NO:   			null,
								//STATUS_DELETE_YES:   			1,
								
								STATUS: { 
									'BLOCKED':	1,
									'ACTIVE':	2,
								},
								
								STATUS_DELETE: { 
									NO: null,
									YES: 1,
								},

								STATUS_DELETE_PARENT_JOB: { 
									NO: null,
									YES: 1,
								},								
								
								STATUS_CLOSE_BY_ADMIN: { 
									NO: null,
									YES: 1,
								},
								
								STATUS_CLOSE_BY_ADMIN_PARENT_JOB: { 
									NO: null,
									YES: 1,
								},
								
								//STATUS_CV_DIRECT_RECEIVE: { 
								//	NO: null,
								//	YES: 1,
								//},
								
								JOB_SHARE_LEVEL_0:   			0,
								JOB_SHARE_LEVEL_1:   			1,
								JOB_SHARE_LEVEL_2:   			2,
								
								JOB_TYPE: { 
									'CONTRACTOR':		1,
									'PERMANENT':		2,
								},
								
								PUBLISH_TYPE: { 
									'PENDING':		0,
									'INVITE':		1,
									'BROADCAST':	2,			
								},
								
								EXPIRY_TIME_DROPDOWN: { 
									7:	'7 days',
									5:	'5 days',
									3:	'3 days',									
								},
							},							
							
							JOB_FILTER: {
								DISTANCE: { 
									MIN: 0,
									MAX: 100
								},
								RATE: {
									MIN: 0,
									MAX: 2000
								},
								SALARY: {
									MIN: 0,
									MAX: 150000
								},
							},							
							
							NEWS: {
								 STATUS_DELETE_NO:	0,
								 STATUS_DELETE_YES:	1,								 								
							},	
							
							NOTIFICATION: {
								
								STATUS: {
									DELETE: 	0,
									BLOCKED:	1,
									ACTIVE:	 	2,
								},
								
								SHOW_ON_WEB:   			[1,2,3,4,5,6,7,11,12,13,14,17,18,22,23,24,26,27],							
								SHOW_ON_IOS:   			[1,2,3,4,5,6,7,11,12,13,14,17,18,22,23,24,26,27],							
								SHOW_ON_ANDROID:   		[1,2,3,4,5,6,7,11,12,13,14,17,18,22,23,24,26,27],	
								SHOW_JOB_RELATED:		[1,2,3,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28],	
							},
							
							PAYMENT_AGENT: {
								 TRANSACTION_HISTORY_TIME_LIMIT:	'18 MONTH',
								 
								 STATUS_PAYMENT_REQUEST_PENDING:	null,
								 STATUS_PAYMENT_REQUEST_SENT:		1,

								 STATUS_PAYMENT_PENDING:   			null,
								 STATUS_PAYMENT_PAID:   			1,								
							},						
							
							PROJECT: {
								STATUS: { 
									DELETE: 	0,
									BLOCKED:	1,
									ACTIVE: 	2,
								},								
							},							
							
							RATE_TYPE: {	
								ID: { 
									1:	'Per Hour',
									2:	'Per Day',
									3:	'Per Week',
									4:	'Per Month',
									5:	'Per Annum',
								},							
							},
							
							TALE: {
								STATUS_DELETE: { 
									NO: 	null,
									YES:	1,
								},								
							},
							
							USER: {
								STATUS_DELETED:   					0,
								STATUS_UNVERIFIED:   				1,
								STATUS_BLOCKED:   					2,
								STATUS_ACTIVE:   					10,	

								STATUS_EMAIL_UNVERIFIED:			0,
								STATUS_EMAIL_VERIFIED:   			1,

								STATUS_PHONE_UNVERIFIED:   			0,
								STATUS_PHONE_VERIFIED:   			1,

								ROLE_SUPERADMIN: 					1,
								ROLE_ADMIN:							2,
								ROLE_AGENT: 						3,
								ROLE_COMPANY: 						4,
								ROLE_STANDARD_USER: 				5,

								IDENTITY_KEY_LENGTH: 				8,

								COUNTRY_CODE_UK: 					44,	//	For production set it for UK.
								//const COUNTRY_CODE_UK: 			91,	//	For testing set it for India.

								DEVICE_TYPE_WEB: 					null,
								DEVICE_TYPE_IOS: 					1,
								DEVICE_TYPE_ANDROID: 				2,

								//SIGNUP_JOB_TYPE_CONTRACTOR:		1,
								//SIGNUP_JOB_TYPE_PERMANENT: 		2,
								
								SIGNUP_JOB_TYPE_CONTRACTOR:			1,
								SIGNUP_JOB_TYPE_INTERIM: 			2,
								SIGNUP_JOB_TYPE_CONSULTANT: 		3,
								SIGNUP_JOB_TYPE_SABBATICAL: 		4,
								SIGNUP_JOB_TYPE_PERMANENT: 			5,
								SIGNUP_JOB_TYPE_RETIRED: 			6,
								SIGNUP_JOB_TYPE_STUDENT: 			7,
								SIGNUP_JOB_TYPE_OTHER: 				8,
	
							},
							
							USER_ROLE: {
								TITLE: { 
									SUPER_ADMIN:	0,
									ADMIN: 			1,
									AGENT: 			3,
									COMPANY: 		4,
									STANDARD_USER: 	5,
								},
								
							},
							
	
						},
						
						
						
						
						production: {
							
							API: {
								VERSION: 'v6',
							},
							
							//Url to be used in link generation							
							url: 'https://app.avoko.com/gv/',	// Production Server URL
							
							port: 3030,	//	V6
							
							//MySQL connection settings							
							/*
							database: {
								host:     	'172.30.31.21',
								port:     	'',
								db:			'avoko_gv',
								user:     	'admin',
								password: 	'eKlQWTbYcX',							
							},
							*/
							
							//Server details
							server: {
								host:   '127.0.0.1',
								port:   '3421'
							},							
							
							params: {
								
								API_KEY: { 
									FIREBASE_CLOUD_MESSAGING:	'AAAA_Uzws90:APA91bFRTfSmGdx1CGdLKHgyBOox65edhEPamQ95X2NLxvSME4sXbE0jUcl7ELJoqFRlX7h2X7FjXMsgXm7SA5uwpJUVQ0yqNc5yYra7Gw9a7-bPkTB7_pmD9mpgmDp-bBAVw5pI4g9c',
								},
								
								SITE_NAME:											'Avoko',	
								SITE_NAME_HTML:										'<b>Avoko</b>',
								
								CRON_JOB_PAYMENT_AGENT_FORECAST_DATE: 				'2017-01-01',
								
								SERVER_PATH_USER_PROFILE_IMAGE:						'frontend/web/upload/images/original/',
								SERVER_PATH_USER_PROFILE_IMAGE_THUMB:				'frontend/web/upload/images/thumb/',
								SERVER_PATH_JOB_ATTACHMENT:							'upload/attachment/',
								
								USER_FIRST_NAME_LENGTH_MIN: 						2,
								USER_FIRST_NAME_LENGTH_MAX: 						35,
								USER_LAST_NAME_LENGTH_MIN:							2,
								USER_LAST_NAME_LENGTH_MAX:							35,
								
								TITLE_LENGTH_MIN:									2,
								TITLE_LENGTH_MAX:									35,	
								
								MOBILE_LENGTH_MIN:									2,
								MOBILE_LENGTH_MAX:									16,
								
								FULL_NAME_LENGTH_MIN:								2,
								FULL_NAME_LENGTH_MAX:								35,
								
								ORGANIZATION_LENGTH_MIN:							2,
								ORGANIZATION_LENGTH_MAX:							35,	

								LOCATION_LENGTH_MIN:								2,
								LOCATION_LENGTH_MAX:								250,	
								
								IMAGE_THUMB_W90:									200,	
								SQL_LIMIT_JOB:										20,	
								SQL_LIMIT_NOTIFICATION:								50,
								
								STATUS_DELETE:										0,	
								STATUS_BLOCKED:										1,
								STATUS_ACTIVE:										2,									
																
								DEBIT_CREDIT_C:										'C',									
								DEBIT_CREDIT_D:										'D',									
								
								DEFAULT_WORKING_DAYS_IN_MONTH: 						19,
								
								MOBILE_BUILD_VERSION_STATUS_FORCEFUL_UPDATE_NO:		0,
								MOBILE_BUILD_VERSION_STATUS_FORCEFUL_UPDATE_YES:	1,
								
								MOBILE_BUILD_VERSION_STATUS_LIVE_NO:				1,
								MOBILE_BUILD_VERSION_STATUS_LIVE_YES:				1,
								
								DB_TABLE_MOBILE_BUILD_VERSION_IOS:					'mobile_build_version_ios',
								DB_TABLE_MOBILE_BUILD_VERSION_ANDROID:				'mobile_build_version_android',
								
								
								
								JOB_COLOR: { 
									CONTRACTOR:	"#52BE80",
									PENDING:	"#BDBDBD",
									INVITE: 	"#FFA500",
									BROADCAST: 	"#00FFFF"			
								},
							},
							
							apiResponseMessage: {	
								101: "Records has been found successfully.",
								102: "No matching records found.",
								INVITE: { 
									101: "Job marked as reviewed.",						
								},
								CONTRACT: { 
									101: "Job Awarded",						
								},
								JOB: { 
									101: "Your job has been shared with your selected connections.<br><br>You can now view this job in the Added by Me tab with full real time activity statuses.",
									102: "This job has been shared with your selected connections who have not previously received it from other Avoko networks.<br><br>Real time statuses can be viewed in your Shared Jobs tab.",
									103: "This job has already been shared with all selected connections.",
									104: "Job was deleted by creator.",
									105: "You can not share your own jobs.",
									106: "Job has been expired.",
									107: "Jobs list has been found successfully.",
									108: "Unable to share further as the maximum referral chain of 3 has been reached.",
									109: "Job not found.",
									110: "Job details has been found successfully.",
								},
								JOB_APPLY: { 
									101: "List of applied jobs has been found successfully.",
									102: "CV marked as reviewed.",
									103: "Job apply record has been removed successfully.",
									CV_APPLY: "Applied for this job",
									SENT_TO_AVOKO: "Sent to Avoko for review",
									SENT_TO_HR: "Submitted to Hiring Manager",
								},
								PAGE: { 
									101: "Page content has been found successfully.",									
								},
								NEWS: { 
									101: "List of news has been found successfully.",									
								},
								NOTIFICATION: { 
									101: "List of notifications has been found successfully.",									
								},
								TALE: { 
									101: "We do not have your bank details. Log into the web portal and update your details.",									
								},
								PAYMENT_AGENT: { 
									101: "No funds available for cash out.",
									102: "Payment request has been created successfully.",							
								},
								FEEDBACK: { 
									101: "Your feedback has been sent successfully.",						
								},								
							},
							
							FEEDBACK: {
								DESCRIPTION: { 
									MIN: 1,
									MAX: 1000
								},								
							},
							
							INVITE: {							
								STATUS_JOB_VIEW_BY_INVITED_USER_PENDING:	null,
								STATUS_JOB_VIEW_BY_INVITED_USER_DONE:		1,							
							},
							
							JOB_APPLY: { 
								STATUS_CV_NOT_SEND_TO_EXPERT:			0,
								STATUS_CV_SENT_TO_EXPERT :				1,
								STATUS_CV_REJECTED_BY_EXPERT:			2,
								STATUS_CV_ACCEPTED_BY_EXPERT:			3,
								STATUS_CV_SUBMITTED_TO_HIRING_MANAGER:	4,
								
								STATUS_CV_DIRECT_RECEIVE_NO: 			null,
								STATUS_CV_DIRECT_RECEIVE_YES:			1,
								
								STATUS_DELETE_NO:						0,
								STATUS_DELETE_YES:						1,
								
								STATUS_CV_VIEW_BY_AGENT_NO:				null,
								STATUS_CV_VIEW_BY_AGENT_YES:			1,
								
								STATUS_HIDE_BY_APPLICANT_NO:			0,
								STATUS_HIDE_BY_APPLICANT_YES:			1,								
							},
							
							CONTRACT: {
								STATUS_ADMIN_PENDING:	1,
								STATUS_ADMIN_REFUSED:	2,	
								STATUS_ADMIN_SIGNED:	3,
							},
							
							CURRENCY: {	
								ID: { 
									1: 'GBP',
									2: 'EURO',
								},							
							},							
							
							DURATION_TYPE: {	
								ID: { 
									1:	'Hour(s)',
									2:	'Day(s)',
									3:	'Week(s)',
									4:	'Month',
									5:	'Year(s)',
								},							
							},
							
							JOB: {
								REFERENCE_NUMBER_PREFIX:   		"GV-",
								REFERENCE_NUMBER_LENGTH:   		10,
								END_DATE_MAX:   				'2037-12-31',
								
								//JOB_TYPE_CONTRACT:   			1,
								//JOB_TYPE_PERMANENT:   		2,

								//JOB_PUBLISH_TYPE_PENDING:   	0,
								//JOB_PUBLISH_TYPE_CONTACTS:   	1,
								//JOB_PUBLISH_TYPE_BROADCAST:	2,

								//STATUS_BLOCKED:   				1,
								//STATUS_ACTIVE:   				2,	

								//STATUS_DELETE_NO:   			null,
								//STATUS_DELETE_YES:   			1,
								
								STATUS: { 
									'BLOCKED':	1,
									'ACTIVE':	2,
								},
								
								STATUS_DELETE: { 
									NO: null,
									YES: 1,
								},

								STATUS_DELETE_PARENT_JOB: { 
									NO: null,
									YES: 1,
								},								
								
								STATUS_CLOSE_BY_ADMIN: { 
									NO: null,
									YES: 1,
								},
								
								STATUS_CLOSE_BY_ADMIN_PARENT_JOB: { 
									NO: null,
									YES: 1,
								},
								
								//STATUS_CV_DIRECT_RECEIVE: { 
								//	NO: null,
								//	YES: 1,
								//},
								
								JOB_SHARE_LEVEL_0:   			0,
								JOB_SHARE_LEVEL_1:   			1,
								JOB_SHARE_LEVEL_2:   			2,
								
								JOB_TYPE: { 
									'CONTRACTOR':		1,
									'PERMANENT':		2,
								},
								
								PUBLISH_TYPE: { 
									'PENDING':		0,
									'INVITE':		1,
									'BROADCAST':	2,			
								},
								
								EXPIRY_TIME_DROPDOWN: { 
									7:	'7 days',
									5:	'5 days',
									3:	'3 days',									
								},
							},							
							
							JOB_FILTER: {
								DISTANCE: { 
									MIN: 0,
									MAX: 100
								},
								RATE: {
									MIN: 0,
									MAX: 2000
								},
								SALARY: {
									MIN: 0,
									MAX: 150000
								},
							},							
							
							NEWS: {
								 STATUS_DELETE_NO:	0,
								 STATUS_DELETE_YES:	1,								 								
							},	
							
							NOTIFICATION: {
								
								STATUS: {
									DELETE: 	0,
									BLOCKED:	1,
									ACTIVE: 	2,
								},	
								
								SHOW_ON_WEB:   			[1,2,3,4,5,6,7,11,12,13,14,17,18,22,23,24,26,27],							
								SHOW_ON_IOS:   			[1,2,3,4,5,6,7,11,12,13,14,17,18,22,23,24,26,27],							
								SHOW_ON_ANDROID:   		[1,2,3,4,5,6,7,11,12,13,14,17,18,22,23,24,26,27],	
								SHOW_JOB_RELATED:		[1,2,3,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28],		
							},
							
							PAYMENT_AGENT: {
								 TRANSACTION_HISTORY_TIME_LIMIT:	'18 MONTH',
								 
								 STATUS_PAYMENT_REQUEST_PENDING:	null,
								 STATUS_PAYMENT_REQUEST_SENT:		1,

								 STATUS_PAYMENT_PENDING:   			null,
								 STATUS_PAYMENT_PAID:   			1,								
							},						
							
							PROJECT: {
								STATUS: { 
									DELETE: 	0,
									BLOCKED:	1,
									ACTIVE: 	2,
								},								
							},							
							
							RATE_TYPE: {	
								ID: { 
									1:	'Per Hour',
									2:	'Per Day',
									3:	'Per Week',
									4:	'Per Month',
									5:	'Per Annum',
								},							
							},
							
							TALE: {
								STATUS_DELETE: { 
									NO: 	null,
									YES:	1,
								},								
							},
							
							USER: {
								STATUS_DELETED:   					0,
								STATUS_UNVERIFIED:   				1,
								STATUS_BLOCKED:   					2,
								STATUS_ACTIVE:   					10,	

								STATUS_EMAIL_UNVERIFIED:			0,
								STATUS_EMAIL_VERIFIED:   			1,

								STATUS_PHONE_UNVERIFIED:   			0,
								STATUS_PHONE_VERIFIED:   			1,

								ROLE_SUPERADMIN: 					1,
								ROLE_ADMIN:							2,
								ROLE_AGENT: 						3,
								ROLE_COMPANY: 						4,
								ROLE_STANDARD_USER: 				5,

								IDENTITY_KEY_LENGTH: 				8,

								COUNTRY_CODE_UK: 					44,	//	For production set it for UK.
								//const COUNTRY_CODE_UK: 			91,	//	For testing set it for India.

								DEVICE_TYPE_WEB: 					null,
								DEVICE_TYPE_IOS: 					1,
								DEVICE_TYPE_ANDROID: 				2,

								//SIGNUP_JOB_TYPE_CONTRACTOR:		1,
								//SIGNUP_JOB_TYPE_PERMANENT: 		2,
								
								SIGNUP_JOB_TYPE_CONTRACTOR:			1,
								SIGNUP_JOB_TYPE_INTERIM: 			2,
								SIGNUP_JOB_TYPE_CONSULTANT: 		3,
								SIGNUP_JOB_TYPE_SABBATICAL: 		4,
								SIGNUP_JOB_TYPE_PERMANENT: 			5,
								SIGNUP_JOB_TYPE_RETIRED: 			6,
								SIGNUP_JOB_TYPE_STUDENT: 			7,
								SIGNUP_JOB_TYPE_OTHER: 				8,
	
							},
							
							USER_ROLE: {
								TITLE: { 
									SUPER_ADMIN:	0,
									ADMIN: 			1,
									AGENT: 			3,
									COMPANY: 		4,
									STANDARD_USER: 	5,
								},
								
							},
							
	
						},
					};
				
	module.exports	=	config;
	
	