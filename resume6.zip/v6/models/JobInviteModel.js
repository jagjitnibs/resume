	var unixTime	=	require('unix-time');
	
	var JobInviteModel	=	{  
		  
		/* 
		Function to get list of invited job ids by user ID
		*/
		getJobInviteByUserId: function(callback) {
			
			//console.log('getJobInviteByUserId');
			var user_id 			= 	AuthenticUser.id;
			
			if (typeof user_id === 'undefined' || user_id === null || parseInt(user_id)<=0) {
				user_id	=	0;
			} else {
				user_id = parseInt(user_id);
			}
			
			var sqlSelectArray 		= 	[];			
			var sqlJoinArray 		= 	[];
			var sqlQueryWhereArray 	= 	[];
			
			var sqlSelect		 	= 	'';
			var sqlFromTable		= 	'';
			var sqlJoin		 		= 	'';			
			var sqlQueryWhere		=	'';
			var sqlOrderBy			=	'';
			
			var invite_job_ids 		= 	[];			
			
			sqlFromTable			=	" FROM invite ";
			sqlOrderBy				=	" ORDER BY invite.id ASC ";
			
			sqlSelectArray.push("SELECT invite.job_id, invite.invite_to");			
			sqlQueryWhereArray.push("WHERE invite.invite_to = "+pool.escape(user_id));		
			
			sqlSelect		=	sqlSelectArray.join(', ');			
			sqlJoin			=	sqlJoinArray.join(' ');			
			sqlQueryWhere	=	sqlQueryWhereArray.join(' AND ');			
			
			var sqlQuery	=	sqlSelect + sqlFromTable + sqlJoin + sqlQueryWhere + sqlOrderBy;
			
			//console.log('sqlQuery = '+sqlQuery);
			
			pool.getConnection(function(error, connection) {									
				// Use the database connection
				var options = {sql: sqlQuery, nestTables: false};
				connection.query(options, function (error, results, fields) {
				// And done with the database connection.
					connection.release();

					if (error) { 
						throw error; 
					} else {
						
						if(!results.length) {
							return callback(null, null);
						} else {						
							for (var i=0;i<results.length;i++) {
								invite_job_ids.push(results[i].job_id);							
							}
							return callback(null, invite_job_ids);
						}			
						return callback(null, null);
					}

					// Don't use the connection here, it has been returned to the pool.
				});
			});
		},

		/* 
		Function to get list of invited users by job ids.
		*/
		//getJobInviteByJodIds: function(user_id, jobIds, callback) {
		getJobInviteByJodIds: function(jobIds, callback) {
			
			//console.log('getJobInviteByJodIds');
			//console.log('LLLLLLL ====  '+jobIds.length);
			
			var user_id = AuthenticUser.id;
			
			if(!jobIds.length) {
				return callback(null, []);
			}

			var sqlSelectArray 		= 	[];			
			var sqlJoinArray 		= 	[];
			var sqlQueryWhereArray 	= 	[];
			
			var sqlSelect		 	= 	'';
			var sqlFromTable		= 	'';
			var sqlJoin		 		= 	'';			
			var sqlQueryWhere		=	'';
			var sqlOrderBy			=	'';			
			
			sqlFromTable			=	" FROM invite ";
			sqlOrderBy				=	" ORDER BY invite.id ASC ";
			
			sqlSelectArray.push("SELECT invite.job_id, invite.invite_to");
			sqlSelectArray.push("user.full_name AS user_full_name");
			sqlSelectArray.push("contact.full_name AS contact_full_name");
			
			sqlJoinArray.push("LEFT JOIN user ON user.id = invite.invite_to");
			sqlJoinArray.push("LEFT JOIN contact ON contact.user_id_contact = invite.invite_to AND contact.user_id = "+pool.escape(user_id));
			
			//sqlQueryWhereArray.push(" WHERE invite.job_id IN ("+jobIds.join(', ')+")");			
			sqlQueryWhereArray.push(" WHERE invite.job_id IN ("+pool.escape(jobIds)+")");			
			
			sqlSelect		=	sqlSelectArray.join(', ');			
			sqlJoin			=	sqlJoinArray.join(' ');			
			sqlQueryWhere	=	sqlQueryWhereArray.join(' AND ');			
			
			var sqlQuery	=	sqlSelect + sqlFromTable + sqlJoin + sqlQueryWhere + sqlOrderBy;		
			
			//console.log('sqlQuery = '+sqlQuery);
			
			pool.getConnection(function(error, connection) {									
				// Use the database connection
				var options = {sql: sqlQuery, nestTables: '_'};
				connection.query(options, function (error, results, fields) {
				// And done with the database connection.
					connection.release();

					if (error) { 
						throw error; 
					} else {
						if(!results) {
							return callback(null, null);
						} else {						
							return callback(null, results);
						}			
						return callback(null, null);
					}

					// Don't use the connection here, it has been returned to the pool.
				});
			});
		},	
		
		/* 
		Function to save job invite.
		*/
		createJobInvites: function(project_id, job_id, invite_from, invite_to, callback) {
			
			//var user_id		=	user.id;
			var project_id	=	parseInt(project_id);
			var job_id		=	parseInt(job_id);
			var invite_from =	parseInt(invite_from);
			var created_at	=	unixTime(new Date()); // 1374016861 
			
			//var invite_to 	=	parseInt(invite_to);
			
			//console.log('job_skill = '+job_skill);
			//console.log('other_skill = '+other_skill);
			
			/*
			var sql = "INSERT INTO Test (name, email, n) VALUES ?";
			var values = [
				['demian', 'demian@gmail.com', 1],
				['john', 'john@gmail.com', 2],
				['mark', 'mark@gmail.com', 3],
				['pete', 'pete@gmail.com', 4]
			];
			conn.query(sql, [values], function(err) {
				if (err) throw err;
				conn.end();
			});
			*/
			var values 		= 	[];		
			
			if(invite_to) {
				var invite_to_ids = invite_to.split(",");
				for (var i=0;i<invite_to_ids.length;i++) {
					var invite_to_id = parseInt(invite_to_ids[i]);
					if(invite_to_id>0) {
						values.push([project_id, job_id, invite_from, invite_to_id, created_at]);	
					}
				}
			}	
			
			
			
			//console.log('values length = '+values.length);	
			if(values.length) {
				
				var sqlQuery	=	"INSERT INTO invite (project_id, job_id, invite_from, invite_to, created_at) VALUES ?";
				
				/*
				var values		= 	[
										[user_id, job_id, 1],
										[user_id, job_id, 2],
										[user_id, job_id, 3],
										[user_id, job_id, 4]
									];
				*/
								
				/* 
				pool.getConnection(function(error, connection) {									
					// Use the database connection
					connection.query(sqlQuery, [values], function (error, results, fields) {
					// And done with the database connection.
						connection.release();
					});
				}); 
				*/
				
				pool.getConnection(function(error, connection) {									
					// Use the database connection
					//var options = {sql: sqlQuery, nestTables: true};
					connection.query(sqlQuery, [values], function (error, results, fields) {
					// And done with the database connection.
						connection.release();

						if (error) { 
							throw error; 
						} else {
							if(!results) {
								return callback(null, null);
							} else {						
								return callback(null, results);
							}			
							return callback(null, null);
						}

						// Don't use the connection here, it has been returned to the pool.
					});
				});
			}					
		},
		
		
		
		//=================================================================
		/* 
		Function to get list of invited job ids by user ID
		*/
		getInvitedJobIdsByUserId: function(callback) {
			
			var user_id 			= 	AuthenticUser.id;
			
			if (typeof user_id === 'undefined' || user_id === null || parseInt(user_id)<=0) {
				user_id	=	0;
			} else {
				user_id = parseInt(user_id);
			}
			
			
			var sqlSelectArray 		= 	[];			
			var sqlJoinArray 		= 	[];
			var sqlQueryWhereArray 	= 	[];
			
			var sqlSelect		 	= 	'';
			var sqlFromTable		= 	'';
			var sqlJoin		 		= 	'';			
			var sqlQueryWhere		=	'';
			var sqlOrderBy			=	'';
			
			var invite_job_ids 		= 	[];			
			
			sqlFromTable			=	" FROM invite ";
			sqlOrderBy				=	" ORDER BY invite.id ASC ";
			
			sqlSelectArray.push(" SELECT invite.job_id ");			
			sqlQueryWhereArray.push(" WHERE invite.invite_to = "+pool.escape(user_id));		
			
			sqlSelect		=	sqlSelectArray.join(', ');			
			sqlJoin			=	sqlJoinArray.join(' ');			
			sqlQueryWhere	=	sqlQueryWhereArray.join(' AND ');			
			
			var sqlQuery	=	sqlSelect + sqlFromTable + sqlJoin + sqlQueryWhere + sqlOrderBy;
			
			//console.log('sqlQuery = '+sqlQuery);
			
			
			pool.getConnection(function(error, connection) {									
				// Use the database connection
				var options = {sql: sqlQuery, nestTables: false};
				connection.query(options, function (error, results, fields) {
				// And done with the database connection.
					connection.release();

					if (error) { 
						throw error; 
					} else {
						
						if(!results.length) {
							return callback(null, null);
						} else {						
							for (var i=0;i<results.length;i++) {
								invite_job_ids.push(results[i].job_id);							
							}
							return callback(null, invite_job_ids);
						}			
						return callback(null, null);
					}

					// Don't use the connection here, it has been returned to the pool.
				});
			});
		},
		//=================================================================
	
	};	
	module.exports = JobInviteModel;