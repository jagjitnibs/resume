	// Include the public functions from 'helpers.js'
	// var helpers 			= 	require('../common/components/helpers');
	
	
	var SettingServerModel = {  
		  
		/* 
		Function to get server details.
		*/		
		getServerDetails: function(postData, callback) {
			
			//console.log('getServerDetails');
			console.log('os_hostname = '+os_hostname);
								
			//-------------------------------------------------------------
			//var os_hostname	=  'DESK5WIN7'; 		//	Localhost
			//var os_hostname	=  'DESK7WIN10'; 		// 	202
			//var os_hostname 	=  'ip-10-0-0-14'; 		// 	UAT
			//var os_hostname 	=  'ip-172-30-31-11';	// 	Production
			//-------------------------------------------------------------
			var serverDetails = {
									host:					null,
									api:					null, 
									api_nodejs:				null, 
									ejabberd:				null,
									ejabberd_host:			null,
									ejabberd_port:			null,
									path_job_attachment:	null
								};								
			//-------------------------------------------------------------
			if(os_hostname == 'DESK5WIN7') {
				
				serverDetails	=	{
					host:					'localhost',
					api:					'http://localhost/avoko_webapp_version_5_0/api/web/v6/', 
					api_nodejs:				'http://localhost:2020/', 
					ejabberd:				'ws://52.213.50.174:5280/xmpp-websocket',
					ejabberd_host:			'ip-10-0-0-14.eu-west-1.compute.internal',
					ejabberd_port:			5222,
					path_job_attachment:	'http://localhost/avoko_webapp_version_5_0/upload/attachment/',
				};
				
			} else if(os_hostname == 'DESK7WIN10') {
			
				serverDetails	=	{
					host:					'202.164.59.237',
					api:					'http://202.164.59.237:1717/avoko_webapp_version_6_0/api/web/v6/', 
					api_nodejs: 			'http://202.164.59.237:3030/', 
					ejabberd:				'ws://52.213.50.174:5280/xmpp-websocket',
					ejabberd_host:			'ip-10-0-0-14.eu-west-1.compute.internal',
					ejabberd_port:			5222,
					path_job_attachment:	'http://202.164.59.237:1717/avoko_webapp_version_5_0/upload/attachment/',										
				};
			
			} else if(os_hostname == 'ip-10-0-0-14') {
			
				serverDetails	=	{
					host:					'52.213.50.174',
					api:					'http://52.213.50.174/gv/api/web/v6/', 
					api_nodejs: 			'http://52.213.50.174:3030/', 
					ejabberd:				'ws://52.213.50.174:5280/xmpp-websocket',
					ejabberd_host:			'ip-10-0-0-14.eu-west-1.compute.internal',
					ejabberd_port:			5222,
					path_job_attachment:	'http://52.213.50.174/gv/upload/attachment/',										
				};
			
			} else if(os_hostname == 'ip-172-30-31-11') {
			
				serverDetails	=	{
					host:					'52.208.246.73',
					api:					'https://app.avoko.com/gv/api/web/v6/', 
					api_nodejs: 			'https://app.avoko.com:3030/', 
					ejabberd:				'ws://52.208.246.73:5280/xmpp-websocket',
					ejabberd_host:			'ip-172-30-31-11.eu-west-1.compute.internal',
					ejabberd_port:			5222,
					path_job_attachment:	'https://app.avoko.com/gv/upload/attachment/',
				};			
			}
			//-------------------------------------------------------------
			return callback(null, serverDetails);
		},	
	};	
	module.exports = SettingServerModel;