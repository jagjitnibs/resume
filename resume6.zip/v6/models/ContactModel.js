	var ContactModel = {  
		  
		//getContactCountByUserId: function(callback) {
		getContactCountByUserId: function(callback) {
			
			//console.log('getContractsPlacedByUserId');			
			var user_id 			= 	AuthenticUser.id;
			//console.log('user_id = '+user_id);			
				
			if((typeof user_id !== 'undefined' && user_id !== null && user_id>0)) {
				
				var sqlSelectArray 		= 	[];			
				var sqlJoinArray 		= 	[];
				var sqlGroupByArray 	= 	[];
				var sqlQueryWhereArray 	= 	[];
				
				var sqlSelect		 	= 	'';
				var sqlFromTable		= 	'';
				var sqlJoin		 		= 	'';			
				var sqlQueryWhere		=	'';
				var sqlGroupBy			=	'';
				var sqlOrderBy			=	'';

				sqlFromTable			=	" FROM contact ";
				
				sqlSelectArray.push("SELECT COUNT(contact.id) AS count_associates");
				
				sqlQueryWhereArray.push(" WHERE contact.user_id = "+pool.escape(user_id));
									
				sqlQueryWhere 	= 	sqlQueryWhereArray.join(' AND ');						
				sqlSelect		=	sqlSelectArray.join(', ');			
				sqlJoin			=	sqlJoinArray.join(' ');			
				sqlQueryWhere	=	sqlQueryWhereArray.join(' AND ');
				sqlGroupBy		=	sqlGroupByArray.join(' ');

				var sqlQuery	=	sqlSelect + sqlFromTable + sqlJoin + sqlQueryWhere + sqlGroupBy + sqlOrderBy;		
				
				//console.log('--------------------------------');
				//console.log('sqlQuery = '+sqlQuery);
							
				pool.getConnection(function(error, connection) {									
					// Use the database connection
					var options = {sql: sqlQuery, nestTables: false};
					connection.query(options, function (error, results, fields) {
					// And done with the database connection.
						connection.release();

						if (error) { 
							throw error; 
						} else {
							if(!results.length) {
								return callback(null, null);
							} else {
								//console.log(JSON.stringify(results, null, 2))
								return callback(null, results);
							}			
							return callback(null, null);
						}

						// Don't use the connection here, it has been returned to the pool.
					});
				});
				
			} else {
				return callback(null, null);
			}		 
		},	  
	
	
	};	
	
	module.exports = ContactModel;  


