	var DurationTypeModel	=	{
		
		getAll: function (callback) {
			
			var sqlSelectArray 		= 	[];			
			var sqlJoinArray 		= 	[];
			var sqlQueryWhereArray 	= 	[];
			
			var sqlSelect		 	= 	'';
			var sqlFromTable		= 	'';
			var sqlJoin		 		= 	'';			
			var sqlQueryWhere		=	'';
			var sqlOrderBy			=	'';			
			
			sqlFromTable			=	" FROM duration_type ";
			
			sqlSelectArray.push("SELECT duration_type.id,  duration_type.title");
				
			sqlQueryWhereArray.push(" WHERE duration_type.status=2" );
			
			sqlSelect		=	sqlSelectArray.join(', ');			
			sqlJoin			=	sqlJoinArray.join(' ');			
			sqlQueryWhere	=	sqlQueryWhereArray.join(' AND ');		
			
			var sqlQuery	=	sqlSelect + sqlFromTable + sqlJoin + sqlQueryWhere + sqlOrderBy;		
			
			//console.log('sqlQuery = '+sqlQuery);
			
			pool.getConnection(function(error, connection) {									
				// Use the database connection

				var options = {sql: sqlQuery, nestTables: false};
				connection.query(options, function (error, results, fields) {
						
					// And done with the database connection.
					connection.release();

					if (error) { 
						throw error; 
					} else {

						if(!results) {
							return callback(null, null);
						} else {
							return callback(null, results);
						}			
						return callback(null, null);
					}
					// Don't use the connection here, it has been returned to the pool.
				});
			});
		},
	};
	
	module.exports = DurationTypeModel;
	