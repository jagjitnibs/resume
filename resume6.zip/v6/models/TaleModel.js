	// Include the public functions from 'helpers.js'
	var helpers 			= 	require('../common/components/helpers');
	
	
	var TaleModel = {  
		  
		
		/* 
		Function to get bank account details by id (primary key).
		*/
		getTaleDetailByUserId: function(callback) {
			
			//console.log('getTaleDetailByUserId');
			
			var user_id 				= 	AuthenticUser.id;
				
			var sqlQueryUpdateColumnArray	= 	[];			
			var sqlQueryWhereArray 			= 	[];			
			var sqlQueryUpdateTable		 	= 	'';
			var sqlQueryUpdateColumn		= 	'';
			var sqlQueryWhere				=	'';
			var sqlQuery					=	'';
			
			var sqlSelectArray 		= 	[];			
			var sqlJoinArray 		= 	[];
			var sqlQueryWhereArray 	= 	[];
			
			var sqlSelect		 	= 	'';
			var sqlFromTable		= 	'';
			var sqlJoin		 		= 	'';			
			var sqlQueryWhere		=	'';
			var sqlOrderBy			=	'';
			
			sqlFromTable			=	" FROM tale ";
			
			sqlSelectArray.push("SELECT tale.id, tale.sort_code, tale.account_number");
			
			sqlQueryWhereArray.push(" WHERE tale.user_id = "+pool.escape(user_id));
			sqlQueryWhereArray.push("tale.status_delete IS "+pool.escape(config.TALE.STATUS_DELETE.NO));
				
			sqlQueryWhere 	= 	sqlQueryWhereArray.join(' AND ');
			sqlSelect		=	sqlSelectArray.join(', ');
			sqlJoin			=	sqlJoinArray.join(' ');
			sqlQueryWhere	=	sqlQueryWhereArray.join(' AND ');

			var sqlQuery	=	sqlSelect + sqlFromTable + sqlJoin + sqlQueryWhere + sqlOrderBy;		

			//console.log('sqlQuery = '+sqlQuery);				
						
			pool.getConnection(function(error, connection) {									
				var options = {sql: sqlQuery, nestTables: true};
				connection.query(options, function (error, results, fields) {
				// And done with the database connection.
					connection.release();

					if (error) { 
						throw error; 
					} else {
						if(!results) {
							return callback(null, null);
						} else {
							return callback(null, results);
						}			
						return callback(null, null);
					}

					// Don't use the connection here, it has been returned to the pool.
				});
			});
		},
		
		
	
	};	
	module.exports = TaleModel;