	// Include the public functions from 'helpers.js'
	var helpers 			= 	require('../common/components/helpers');
	
	
	var FeedbackModel = {  
		  
		//==============================================================
		/* 
		Function to create new feedback.
		*/
		createFeedback: function(postData, callback) {
			
			var user_id 			= 	AuthenticUser.id;
			
			if (typeof user_id === 'undefined' || user_id === null || parseInt(user_id)<=0) {
				user_id	=	0;
			} else {
				user_id = parseInt(user_id);
			}
			
			var description					=	postData.description;			

			var sqlQueryInsertColumnArray	= 	[];	
			var sqlQueryWhereArray 			= 	[];		
			var sqlQueryUpdateTable		 	= 	'';
			var sqlQueryUpdateColumn		= 	'';
			var sqlQueryWhere				=	'';
			var sqlQuery					=	'';
			
			sqlQueryInsertTable				=	" INSERT INTO feedback SET ";
			
			sqlQueryInsertColumnArray.push("feedback.created_by = "+pool.escape(user_id));
			sqlQueryInsertColumnArray.push("feedback.created_at = UNIX_TIMESTAMP()");
			sqlQueryInsertColumnArray.push("feedback.description = "+pool.escape(description));
						
			sqlQueryInsertColumn		=	sqlQueryInsertColumnArray.join(', ');			
			sqlQueryWhere				=	sqlQueryWhereArray.join(' AND ');		
			sqlQuery					=	sqlQueryInsertTable + sqlQueryInsertColumn;
			
			//console.log('sqlQuery = '+sqlQuery);

			pool.getConnection(function(error, connection) {									
				// Use the database connection
				connection.query(sqlQuery, function (error, results, fields) {
				// And done with the database connection.
					connection.release();

					if (error) { 
						throw error; 
					} else {
						
						if(!results) {
							return callback(null, null);
						} else {						
							var feedback_id = results.insertId;
							
							return callback(null, feedback_id);
						}
					}
					// Don't use the connection here, it has been returned to the pool.
				});
			});								
		},	
		//==============================================================		
		//==============================================================		
		//==============================================================		
		//==============================================================		
		//==============================================================		
	
	};	
	module.exports = FeedbackModel;