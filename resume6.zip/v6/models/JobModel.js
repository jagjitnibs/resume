	var nodeDateTime 			= 	require('node-datetime');
	var async      				= 	require('async');
	
	var helpers 				= 	require('../common/components/helpers');
	var ProjectModel 			=	require('../models/ProjectModel');
	var JobSkillModel 			=	require('../models/JobSkillModel');
	var JobInviteModel 			=	require('../models/JobInviteModel');
	var JobFilterModel 			=	require('../models/JobFilterModel');
	var SectorRoleModel 		=	require('../models/SectorRoleModel');
	var JobApplyModel 			=	require('../models/JobApplyModel');
	
	var JobModel	=	{
		//=================================================================
		/* 
		Function to create new job.
		*/
		createJob: function(user, postData, callback) {
			
			var reference_number			=	helpers.getJobReferenceNumber();
			var user_id 					=	user.id;
			var user_role_id 				=	user.role;
			var industry_sector_id 			=	user.industry_sector_id;
			
			var project_id					=	postData.project_id;
			var hiring_manager_name			=	postData.hiring_manager_name;
			var hiring_manager_email		=	postData.hiring_manager_email;
			var hiring_manager_mobile		=	postData.hiring_manager_mobile;
			var sector_role_id				=	postData.sector_role_id;
			var start_date					=	postData.start_date;
			var job_type					=	postData.job_type;
			var title						=	postData.title;
			var rate						=	postData.rate;
			var currency_id					=	postData.currency_id;
			var rate_type_id				=	postData.rate_type_id;
			var contract_duration			=	postData.contract_duration;
			var duration_type_id			=	postData.duration_type_id;
			var job_skill					=	postData.job_skill;
			var other_skill					=	postData.other_skill;
			var description					=	postData.description;
			var expiry_time_dropdown		=	postData.expiry_time;
			//var expiry_time				=	postData.expiry_time;
			var filedata					=	postData.attachment;			
			var invite_to					=	postData.job_invite;			

			//console.log('invite_to = '+invite_to);
			//TIMESTAMPADD(MONTH,2,'2009-05-18');  
			
			if (typeof filedata !== 'undefined' && filedata !== null) {				
				var filesize_kb				 	=	helpers.sizeOfBase64EncodedString(filedata);
				//console.log('filesize_kb = '+filesize_kb);
				var filename				 	=	helpers.getRandomStringAlphaNumeric();
				var filetype				 	=	helpers.decodeBase64ImageType(filedata);				
				var image						=	filename+'.'+filetype;
				//console.log('filename = '+filename);
				//console.log('image = '+image);
				
				helpers.uploadJobAttachmentFile(filename, filedata);			
			}
			//console.log('sector_role_id = '+sector_role_id);
			SectorRoleModel.getSectorRoleTitleInShortById(sector_role_id, function(error, results) {  
				if (error) {    
					throw error;
				} else { 
					if(results) {
						//console.log('results = '+results);
						
						var sector_role_title	=	results;						
						var reference_number	=	helpers.getJobReferenceNumber(sector_role_title);
						
						var dateTime 	=	nodeDateTime.create();
						var todayDate	=	dateTime.format('Y-m-d');
						//console.log('todayDate = '+todayDate);
			
						var sqlQueryInsertColumnArray	= 	[];	
						var sqlQueryWhereArray 			= 	[];		
						var sqlQueryUpdateTable		 	= 	'';
						var sqlQueryUpdateColumn		= 	'';
						var sqlQueryWhere				=	'';
						var sqlQuery					=	'';
						
						sqlQueryInsertTable				=	" INSERT INTO job SET ";
						
						sqlQueryInsertColumnArray.push("job.user_role_id = "+pool.escape(user_role_id));
						sqlQueryInsertColumnArray.push("job.created_by = "+pool.escape(user_id));
						sqlQueryInsertColumnArray.push("job.created_at = UNIX_TIMESTAMP()");
						//sqlQueryInsertColumnArray.push("job.status_delete = "+config.job.STATUS_DELETE.NO);
						
						sqlQueryInsertColumnArray.push("job.reference_number = "+pool.escape(reference_number));
						sqlQueryInsertColumnArray.push("job.project_id = "+pool.escape(project_id));
						sqlQueryInsertColumnArray.push("job.industry_sector_id = "+pool.escape(industry_sector_id));
						sqlQueryInsertColumnArray.push("job.hiring_manager_name = "+pool.escape(hiring_manager_name));
						sqlQueryInsertColumnArray.push("job.hiring_manager_email = "+pool.escape(hiring_manager_email));
						sqlQueryInsertColumnArray.push("job.hiring_manager_mobile = "+pool.escape(hiring_manager_mobile));
						sqlQueryInsertColumnArray.push("job.sector_role_id = "+pool.escape(sector_role_id));
						sqlQueryInsertColumnArray.push("job.start_date = UNIX_TIMESTAMP("+pool.escape(start_date)+")");
						sqlQueryInsertColumnArray.push("job.end_date = UNIX_TIMESTAMP("+pool.escape(config.JOB.END_DATE_MAX)+")");
						sqlQueryInsertColumnArray.push("job.job_type = "+pool.escape(job_type));
						sqlQueryInsertColumnArray.push("job.title = "+pool.escape(title));
						sqlQueryInsertColumnArray.push("job.rate = "+pool.escape(rate));
						sqlQueryInsertColumnArray.push("job.currency_id = "+pool.escape(currency_id));
						sqlQueryInsertColumnArray.push("job.rate_type_id = "+pool.escape(rate_type_id));
						sqlQueryInsertColumnArray.push("job.contract_duration = "+pool.escape(contract_duration));
						sqlQueryInsertColumnArray.push("job.duration_type_id = "+pool.escape(duration_type_id));
						//sqlQueryInsertColumnArray.push("job.job_skill = "+pool.escape(job_skill));
						//sqlQueryInsertColumnArray.push("job.other_skill = "+pool.escape(other_skill));
						sqlQueryInsertColumnArray.push("job.description = "+pool.escape(description));
						sqlQueryInsertColumnArray.push("job.expiry_time_dropdown = "+pool.escape(expiry_time_dropdown));		
						sqlQueryInsertColumnArray.push("job.expiry_time = UNIX_TIMESTAMP(TIMESTAMPADD(DAY,"+pool.escape(expiry_time_dropdown)+",'"+todayDate+"'))");		
						
						sqlQueryInsertColumnArray.push("job.publish_type = "+pool.escape(config.JOB.PUBLISH_TYPE.INVITE));
						sqlQueryInsertColumnArray.push("job.status = "+pool.escape(config.JOB.STATUS.ACTIVE));
						sqlQueryInsertColumnArray.push("job.status_delete = "+pool.escape(config.JOB.STATUS_DELETE.NO));
						
						sqlQueryInsertColumn		=	sqlQueryInsertColumnArray.join(', ');			
						sqlQueryWhere				=	sqlQueryWhereArray.join(' AND ');		
						sqlQuery					=	sqlQueryInsertTable + sqlQueryInsertColumn;
						
						//console.log('sqlQuery = '+sqlQuery);
			
						pool.getConnection(function(error, connection) {									
							// Use the database connection
							connection.query(sqlQuery, function (error, results, fields) {
							// And done with the database connection.
								connection.release();

								if (error) { 
									throw error; 
								} else {
									
									if(!results) {
										return callback(null, null);
									} else {						
										
										var job_id = results.insertId;
										
										if(invite_to) {
											//JobSkillModel.createJobSkill(user, job_id, job_skill, other_skill, function(error, results) {
											JobInviteModel.createJobInvites(project_id, job_id, user_id, invite_to, function(error, results) {
												
												if (error) {    
													throw error;
												} else {
													if(!results) {
														return callback(null, null);
													} else {
														return callback(null, job_id);
													}
												}								
											});
										}
										/* if(job_skill || other_skill) {
											JobSkillModel.createJobSkill(user, job_id, job_skill, other_skill, function(error, results) {
												
												if (error) {    
													throw error;
												} else {
													if(!results) {
														return callback(null, null);
													} else {
														return callback(null, job_id);
													}
												}								
											});
										} */ else {
											return callback(null, job_id);
										}
									}
								}
								// Don't use the connection here, it has been returned to the pool.
							});
						});
					}
				}
			});
			
			
		},
		
		//=================================================================
		/* 
		Function to get job details by id.
		*/
		/*
		getJobDetailById________20170907: function(job_id, callback) {
			
			var sqlSelectArray 		= 	[];			
			var sqlJoinArray 		= 	[];
			var sqlQueryWhereArray 	= 	[];
			
			var sqlSelect		 	= 	'';
			var sqlFromTable		= 	'';
			var sqlJoin		 		= 	'';			
			var sqlQueryWhere		=	'';
			var sqlOrderBy			=	'';
			
			sqlFromTable			=	" FROM job ";
			sqlOrderBy				=	" ORDER BY job.id DESC ";
			
			sqlSelectArray.push("SELECT  job.* ");	
			sqlSelectArray.push("project.* ");
			sqlSelectArray.push("industry_sector.title");
			sqlSelectArray.push("sub_industry_sector.title");
			sqlSelectArray.push("sector_role.title");
			sqlSelectArray.push("currency.title, currency.symbol");
			sqlSelectArray.push("rate_type.title");
			sqlSelectArray.push("duration_type.title");
			//sqlSelectArray.push("invite.invite_to");
			//sqlSelectArray.push("aaaaaa.bbbbb");
			//sqlSelectArray.push("aaaaaa.bbbbb");

			sqlJoinArray.push("LEFT JOIN project ON project.id = job.project_id");
			sqlJoinArray.push("LEFT JOIN industry_sector ON industry_sector.id = job.industry_sector_id");
			sqlJoinArray.push("LEFT JOIN sub_industry_sector ON sub_industry_sector.id = job.sub_industry_sector_id");
			sqlJoinArray.push("LEFT JOIN sector_role ON sector_role.id = job.sector_role_id");
			sqlJoinArray.push("LEFT JOIN currency ON currency.id = job.currency_id");
			sqlJoinArray.push("LEFT JOIN rate_type ON rate_type.id = job.rate_type_id");
			sqlJoinArray.push("LEFT JOIN duration_type ON duration_type.id = job.duration_type_id");
			//sqlJoinArray.push("LEFT JOIN invite ON invite.job_id = job.id");
			
			sqlQueryWhereArray.push(" WHERE job.id = "+pool.escape(job_id));
			//sqlQueryWhereArray.push(" job.status = "+config.PROJECT.STATUS.ACTIVE);
			
			sqlSelect		=	sqlSelectArray.join(', ');			
			sqlJoin			=	sqlJoinArray.join(' ');			
			sqlQueryWhere	=	sqlQueryWhereArray.join(' AND ');	
			
			var sqlQuery	=	sqlSelect + sqlFromTable + sqlJoin + sqlQueryWhere + sqlOrderBy;		
			
			console.log('sqlQuery = '+sqlQuery);
				
			pool.getConnection(function(error, connection) {									
				// Use the database connection
				var options = {sql: sqlQuery, nestTables: true};
				connection.query(options, function (error, results, fields) { 
				// And done with the database connection.
					connection.release();

					if (error) { 
						throw error; 
					} else {

						if(!results) {
							return callback(null, null);
						} else {
							return callback(null, results);
						}			
						return callback(null, null);
					}
					// Don't use the connection here, it has been returned to the pool.
				});
			});
		},
		*/
		
		//=================================================================
		/* 
		Function to get job details by id.
		*/
		getJobDetailById: function(job_id, callback) {
			
			var user_id 			= 	AuthenticUser.id;
			
			var sqlSelectArray 		= 	[];			
			var sqlJoinArray 		= 	[];
			var sqlQueryWhereArray 	= 	[];
			
			var sqlSelect		 	= 	'';
			var sqlFromTable		= 	'';
			var sqlJoin		 		= 	'';			
			var sqlQueryWhere		=	'';
			var sqlOrderBy			=	'';
			
			sqlFromTable			=	" FROM job ";
			sqlOrderBy				=	" ORDER BY job.id DESC ";
			
			//sqlSelectArray.push("SELECT  job.* ");	
			sqlSelectArray.push("SELECT  job.*");
			sqlSelectArray.push("createdBy.id, createdBy.username, createdBy.mobile, createdBy.first_name, createdBy.last_name, createdBy.full_name");
			sqlSelectArray.push("createdByFromContact.id, createdByFromContact.user_id_contact, createdByFromContact.first_name, createdByFromContact.last_name, createdByFromContact.full_name");
			sqlSelectArray.push("project.*");
			sqlSelectArray.push("industry_sector.title");
			sqlSelectArray.push("sub_industry_sector.title");
			sqlSelectArray.push("sector_role.title");
			sqlSelectArray.push("currency.title, currency.symbol");
			sqlSelectArray.push("rate_type.title");
			sqlSelectArray.push("duration_type.title");
			//sqlSelectArray.push("(SELECT GROUP_CONCAT(invite.id, 'invite_to', invite.invite_to) FROM invite WHERE invite.job_id = "+pool.escape(job_id)+") AS PhoneNumbers");
			//sqlSelectArray.push("aaaaaa.bbbbb");
			//sqlSelectArray.push("aaaaaa.bbbbb");

			sqlJoinArray.push("LEFT JOIN user AS createdBy ON createdBy.id = job.created_by");
			sqlJoinArray.push("LEFT JOIN contact AS createdByFromContact ON createdByFromContact.user_id_contact = job.created_by AND (createdByFromContact.user_id ="+pool.escape(user_id)+" )");
			sqlJoinArray.push("LEFT JOIN project ON project.id = job.project_id");
			sqlJoinArray.push("LEFT JOIN industry_sector ON industry_sector.id = job.industry_sector_id");
			sqlJoinArray.push("LEFT JOIN sub_industry_sector ON sub_industry_sector.id = job.sub_industry_sector_id");
			sqlJoinArray.push("LEFT JOIN sector_role ON sector_role.id = job.sector_role_id");
			sqlJoinArray.push("LEFT JOIN currency ON currency.id = job.currency_id");
			sqlJoinArray.push("LEFT JOIN rate_type ON rate_type.id = job.rate_type_id");
			sqlJoinArray.push("LEFT JOIN duration_type ON duration_type.id = job.duration_type_id");
			//sqlJoinArray.push("LEFT OUTER JOIN invite ON invite.job_id = job.id");
			
			sqlQueryWhereArray.push(" WHERE job.id = "+pool.escape(job_id));
			//sqlQueryWhereArray.push(" job.status = "+config.PROJECT.STATUS.ACTIVE);
			
			sqlSelect		=	sqlSelectArray.join(', ');			
			sqlJoin			=	sqlJoinArray.join(' ');			
			sqlQueryWhere	=	sqlQueryWhereArray.join(' AND ');	
			
			var sqlQuery	=	sqlSelect + sqlFromTable + sqlJoin + sqlQueryWhere + sqlOrderBy;		
			
			//console.log('sqlQuery = '+sqlQuery);
				
			pool.getConnection(function(error, connection) {									
				// Use the database connection
				var options = {sql: sqlQuery, nestTables: '_'};
				connection.query(options, function (error, results, fields) { 
				// And done with the database connection.
					connection.release();

					if (error) { 
						throw error; 
					} else {

						if(!results) {
							return callback(null, null);
						} else {
							//console.log(results);
							return callback(null, results);
						}			
						return callback(null, null);
					}
					// Don't use the connection here, it has been returned to the pool.
				});
			});
		},
		
		//=================================================================
		/* 
		Function to get job details by id.
		*/
		getComprehensiveJobDetailById: function(job_id, callback) {
			
			var return_data 					= 	[];

			async.parallel([
			
				function(parallel_done) {
					
					JobModel.getJobDetailById(job_id, function(error, results) {  
											
						if (error) {    
							return parallel_done(error);
						} else {  
							//console.log(results);
							if(results) {
								return_data.job	=	results;
								//countJobPublishTypeContacts			=	results.length;
							} 		
							parallel_done();	
						}  
					});					
				},
				function(parallel_done) {				   
					
					JobInviteModel.getJobInviteByJodIds([job_id], function(error, results) {
						
						if (error) {    
							return parallel_done(error);
						} else {  
							if(results) {
								return_data.invite	=	results;
								//countJobPublishTypeBroadcast		=	results.length;
							} 	
							parallel_done();							
						}  
					});
				} 
			], function(error) {
				
				if (error) { 
						throw error; 
					} else {

						//if(!results) {
						if(!return_data) {
							return callback(null, null);
						} else {
							//console.log("1111111111"+return_data.job);
							//console.log("2222222222"+JSON.stringify(return_data.job,0,2));
							//return callback(null, results);
							return callback(null, return_data);
						}			
						return callback(null, null);
					}			
			});
			
		},
		
		//=================================================================
		/* 
		Function to get list of invited jobs by user ID
		*/
		getJobListPublishTypeContactByUserId: function(callback) {			
			
			var user_id 			= 	AuthenticUser.id;
			
			if (typeof user_id === 'undefined' || user_id === null || parseInt(user_id)<=0) {
				user_id	=	0;
			} else {
				user_id = parseInt(user_id);
			}
			
			JobInviteModel.getJobInviteByUserId(function(error, results) {
				
				if (error) {    
					throw error;
				} else { 
					if(!results) {
						return callback(null, null);
					} else {
						
						var invitedJobIds 		= 	results;
						//console.log('invitedJobIds = '+invitedJobIds);
						//JobApplyModel.getAppliedJobIds(function(error, results) {
						JobApplyModel.getDirectAppliedJobIds(function(error, results) {
					
							if (error) {    
								throw error;
							} else {
								var appliedJobIds		= 	results;
								//console.log('appliedJobIds = '+appliedJobIds);
								JobModel.getSharedJobIds(invitedJobIds, function(error, results) {  
						
									if (error) {    
										throw error;
									} else {
										var sharedJobIds		= 	results;
										//console.log('sharedJobIds = '+sharedJobIds);
										
										var sqlSelectArray 		= 	[];			
										var sqlJoinArray 		= 	[];
										var sqlQueryWhereArray 	= 	[];
										
										var sqlSelect		 	= 	'';
										var sqlFromTable		= 	'';
										var sqlJoin		 		= 	'';			
										var sqlQueryWhere		=	'';
										var sqlOrderBy			=	'';
										
										sqlFromTable			=	" FROM job ";
										sqlOrderBy				=	" ORDER BY job.id DESC ";
							
										sqlSelectArray.push("SELECT job.id, job.job_type, job.created_by, job.user_role_id, job.job_share_level, job.job_copy_id, job.reference_number, job.job_L0_id, job.job_L0_reference_number, job.project_id, job.industry_sector_id, job.sub_industry_sector_id, job.sector_role_id, job.hiring_manager_name, job.hiring_manager_email, job.hiring_manager_mobile, job.start_date, job.end_date, job.expiry_time, job.title, job.expiry_time, job.contract_duration, job.duration_type_id, job.rate, job.currency_id, job.rate_type_id, job.description, job.attachment, job.invite_message, job.status_authentic, job.publish_type, job.status_delete");
										//sqlSelectArray.push("user.id, user.full_name");
										sqlSelectArray.push("createdBy.id, createdBy.username, createdBy.mobile, createdBy.first_name, createdBy.last_name, createdBy.full_name");
										sqlSelectArray.push("createdByFromContact.id, createdByFromContact.user_id_contact, createdByFromContact.first_name, createdByFromContact.last_name, createdByFromContact.full_name");

										//sqlSelectArray.push("contact.id, contact.full_name");
										sqlSelectArray.push("project.title, project.organistion, project.location, project.latitude, project.longitude, project.start_date, project.end_date");
										sqlSelectArray.push("sector_role.title");
										sqlSelectArray.push("currency.title, currency.symbol");
										sqlSelectArray.push("rate_type.title");
										sqlSelectArray.push("duration_type.title");						
										sqlSelectArray.push("jobL0.id, jobL0.user_role_id");						
										
										//sqlJoinArray.push("LEFT JOIN user ON job.created_by = user.id");
										sqlJoinArray.push("LEFT JOIN user AS createdBy ON createdBy.id = job.created_by");
										sqlJoinArray.push("LEFT JOIN contact AS createdByFromContact ON createdByFromContact.user_id_contact = job.created_by AND (createdByFromContact.user_id ="+pool.escape(user_id)+" )");

										//sqlJoinArray.push("LEFT JOIN contact ON user.id = contact.user_id_contact AND contact.user_id = "+pool.escape(user_id));
										sqlJoinArray.push("LEFT JOIN project ON job.project_id = project.id");
										sqlJoinArray.push("LEFT JOIN sector_role ON sector_role.id = job.sector_role_id");
										sqlJoinArray.push("LEFT JOIN currency ON job.currency_id = currency.id");
										sqlJoinArray.push("LEFT JOIN rate_type ON job.rate_type_id = rate_type.id");
										sqlJoinArray.push("LEFT JOIN duration_type ON job.duration_type_id = duration_type.id");						
										
										sqlJoinArray.push("LEFT JOIN job AS jobL0 ON jobL0.id = job.job_L0_id");						
										
										sqlQueryWhereArray.push(" WHERE job.id IN ("+pool.escape(invitedJobIds)+")");
										if(appliedJobIds.length){
											sqlQueryWhereArray.push(" job.id NOT IN ("+pool.escape(appliedJobIds)+")");
										}
										if(sharedJobIds.length){
											sqlQueryWhereArray.push(" job.id NOT IN ("+pool.escape(sharedJobIds)+")");
										}	
										sqlQueryWhereArray.push("job.publish_type = "+pool.escape(config.JOB.PUBLISH_TYPE.INVITE));
										sqlQueryWhereArray.push("job.expiry_time > UNIX_TIMESTAMP()");
										sqlQueryWhereArray.push("job.status_delete IS "+pool.escape(config.JOB.STATUS_DELETE.NO));
										sqlQueryWhereArray.push("job.status_delete_parent_job IS "+pool.escape(config.JOB.STATUS_DELETE_PARENT_JOB.NO));
										sqlQueryWhereArray.push("job.status_close_by_admin IS "+pool.escape(config.JOB.STATUS_CLOSE_BY_ADMIN.NO));
										sqlQueryWhereArray.push("job.status_close_by_admin_parent_job IS "+pool.escape(config.JOB.STATUS_CLOSE_BY_ADMIN_PARENT_JOB.NO));
										//sqlQueryWhereArray.push("job.user_role_id = "+pool.escape(config.USER.ROLE_AGENT));
										sqlQueryWhereArray.push("job.user_role_id IN ("+pool.escape(config.USER.ROLE_SUPERADMIN)+","+pool.escape(config.USER.ROLE_ADMIN)+","+pool.escape(config.USER.ROLE_AGENT)+")");
										
										sqlQueryWhere 	= 	sqlQueryWhereArray.join(' AND ');						
										sqlSelect		=	sqlSelectArray.join(', ');			
										sqlJoin			=	sqlJoinArray.join(' ');			
										sqlQueryWhere	=	sqlQueryWhereArray.join(' AND ');

										var sqlQuery	=	sqlSelect + sqlFromTable + sqlJoin + sqlQueryWhere + sqlOrderBy;		

										//console.log('sqlQuery = '+sqlQuery);					
										
										pool.getConnection(function(error, connection) {									
											// Use the database connection
											var options = {sql: sqlQuery, nestTables: '_'};
											connection.query(options, function (error, results, fields) {
											// And done with the database connection.
												connection.release();

												if (error) { 
													throw error; 
												} else {

													if(!results) {
														return callback(null, null);
													} else {
														return callback(null, results);
													}			
													return callback(null, null);
												}

												// Don't use the connection here, it has been returned to the pool.
											});
										});
									}
								});
							}
						});						
					}
				}
			});
		},	
		//=================================================================
		/* 
		Function to get list of broadcasted jobs by user ID
		*/
		/*
		getJobListPublishTypeBroadcastByUserId_________________20180320: function(offset, callback) {
			
			var user_id 			= 	AuthenticUser.id;
			//console.log('user_id = '+user_id);
			if (typeof user_id === 'undefined' || user_id === null || parseInt(user_id)<=0) {
				user_id	=	0;
			} else {
				user_id = parseInt(user_id);
			}
			
			if (typeof offset === 'undefined' || offset === null || parseInt(offset)<=0) {
				offset	=	0;
			} else {
				offset = parseInt(offset);
			}

			JobFilterModel.getJobFilterByUserId(function(error, results) {  
				if (error) {    
					throw error;
				} else { 
					if(results) {
						job_filter	=	results;
						
						//console.log('Job Filter = '+ JSON.stringify(results, null, 2));
						//console.log('Job Filter job_type = '+ job_filter[0]['job_type']);
						
						var user_id				=	job_filter[0]['job_filter']['user_id'];
						var industry_sector_id	=	job_filter[0]['job_filter']['industry_sector_id'];
						var job_type			=	job_filter[0]['job_filter']['job_type'];
						var keyword				=	job_filter[0]['job_filter']['keyword'];
						var rate_min			=	job_filter[0]['job_filter']['rate_min'];
						var rate_max			=	job_filter[0]['job_filter']['rate_max'];
						var location			=	job_filter[0]['job_filter']['location'];
						var latitude			=	job_filter[0]['job_filter']['latitude'];
						var longitude			=	job_filter[0]['job_filter']['longitude'];			
						var distance			=	job_filter[0]['job_filter']['distance'];
						var filter_invite_jobs	=	job_filter[0]['job_filter']['filter_invite_jobs'];
						
						//console.log('Job Filter user_id = '+ user_id);
						//console.log('Job Filter industry_sector_id = '+ industry_sector_id);
						//console.log('Job Filter rate_min = '+ rate_min);
						//console.log('Job Filter rate_max = '+ rate_max);
						
						ProjectModel.getProjectByJobFilter(job_filter, function(error, results) {				
				
							if (error) {    
								throw error;
							} else {
								
								//console.log('project ids = '+results);
								
								var project_ids			=	results;
								
								var sqlSelectArray 		= 	[];			
								var sqlJoinArray 		= 	[];
								var sqlQueryWhereArray 	= 	[];
								
								var sqlSelect		 	= 	'';
								var sqlFromTable		= 	'';
								var sqlJoin		 		= 	'';			
								var sqlQueryWhere		=	'';
								var sqlOrderBy			=	'';
								var sqlLimit			=	' LIMIT '+config.params.SQL_LIMIT_JOB;
								var sqlOffset			=	' OFFSET '+offset;
								
								sqlFromTable			=	' FROM job ';
								sqlOrderBy				=	' ORDER BY job.id DESC ';
								
								sqlSelectArray.push("SELECT job.id, job.job_type, job.created_by, job.job_share_level, job.job_copy_id, job.reference_number, job.job_L0_id, job.job_L0_reference_number, job.project_id, job.industry_sector_id, job.sub_industry_sector_id, job.sector_role_id, job.hiring_manager_name, job.hiring_manager_email, job.hiring_manager_mobile, job.start_date, job.end_date, job.expiry_time, job.title, job.expiry_time, job.contract_duration, job.duration_type_id, job.rate, job.currency_id, job.rate_type_id, job.description, job.attachment, job.invite_message, job.status_authentic, job.publish_type, job.status_delete");
								//sqlSelectArray.push("user.id, user.full_name");
								sqlSelectArray.push("createdBy.id, createdBy.username, createdBy.mobile, createdBy.first_name, createdBy.last_name, createdBy.full_name");
								sqlSelectArray.push("createdByFromContact.id, createdByFromContact.user_id_contact, createdByFromContact.first_name, createdByFromContact.last_name, createdByFromContact.full_name");
								//sqlSelectArray.push("contact.id, contact.full_name");
								sqlSelectArray.push("project.title, project.organistion, project.location, project.latitude, project.longitude, project.start_date, project.end_date");
								sqlSelectArray.push("sector_role.title");
								sqlSelectArray.push("currency.title, currency.symbol");
								sqlSelectArray.push("rate_type.title");
								sqlSelectArray.push("duration_type.title");						
								
								//sqlJoinArray.push("LEFT JOIN user ON job.created_by = user.id");
								sqlJoinArray.push("LEFT JOIN user AS createdBy ON createdBy.id = job.created_by");
								sqlJoinArray.push("LEFT JOIN contact AS createdByFromContact ON createdByFromContact.user_id_contact = job.created_by AND (createdByFromContact.user_id ="+pool.escape(user_id)+" )");

								//sqlJoinArray.push("LEFT JOIN contact ON user.id = contact.user_id_contact AND contact.user_id = "+pool.escape(user_id));
								sqlJoinArray.push("LEFT JOIN project ON job.project_id = project.id");
								sqlJoinArray.push("LEFT JOIN sector_role ON sector_role.id = job.sector_role_id");
								sqlJoinArray.push("LEFT JOIN currency ON job.currency_id = currency.id");
								sqlJoinArray.push("LEFT JOIN rate_type ON job.rate_type_id = rate_type.id");
								sqlJoinArray.push("LEFT JOIN duration_type ON job.duration_type_id = duration_type.id");						
										
								sqlQueryWhereArray.push(" WHERE job.publish_type = "+pool.escape(config.JOB.PUBLISH_TYPE.BROADCAST));
								sqlQueryWhereArray.push("job.expiry_time > UNIX_TIMESTAMP()");
								sqlQueryWhereArray.push("job.status_delete IS "+pool.escape(config.JOB.STATUS_DELETE_NO));
								//sqlQueryWhereArray.push("job.user_role_id = "+pool.escape(config.USER.ROLE_AGENT));
								sqlQueryWhereArray.push("job.user_role_id IN ("+pool.escape(config.USER.ROLE_SUPERADMIN)+","+pool.escape(config.USER.ROLE_ADMIN)+","+pool.escape(config.USER.ROLE_AGENT)+")");
								
								if (typeof project_ids !== 'undefined' && project_ids !== null) {
									sqlQueryWhereArray.push("job.project_id IN ("+pool.escape(project_ids)+")");			
								}						
								if (typeof industry_sector_id !== 'undefined' && industry_sector_id !== null) {
									sqlQueryWhereArray.push("job.industry_sector_id = "+pool.escape(industry_sector_id));				
								}  
								if (typeof job_type !== 'undefined' && job_type !== null) {
									sqlQueryWhereArray.push("job.job_type = "+pool.escape(job_type));
								}
								if (typeof rate_min !== 'undefined' && rate_min !== null) {
									sqlQueryWhereArray.push("job.rate >= "+pool.escape(rate_min));
								}
								if (typeof rate_max !== 'undefined' && rate_max !== null) {
									sqlQueryWhereArray.push("job.rate <= "+pool.escape(rate_max));
								}
								if (typeof keyword !== 'undefined' && keyword !== null && keyword.length>0) {
									//sqlQueryWhereArray.push("MATCH (job.description) AGAINST ('"+keyword+"' IN NATURAL LANGUAGE MODE)");
									//sqlQueryWhereArray.push("MATCH (job.description) AGAINST ("+dbConnection.escape(keyword)+" IN NATURAL LANGUAGE MODE)");
									sqlQueryWhereArray.push("MATCH (job.description) AGAINST ("+pool.escape(keyword)+" IN BOOLEAN  MODE)");
								}
								
								sqlQueryWhere 	= 	sqlQueryWhereArray.join(' AND ');						
								sqlSelect		=	sqlSelectArray.join(', ');			
								sqlJoin			=	sqlJoinArray.join(' ');			
								sqlQueryWhere	=	sqlQueryWhereArray.join(' AND ');

								var sqlQuery	=	sqlSelect + sqlFromTable + sqlJoin + sqlQueryWhere + sqlOrderBy + sqlLimit + sqlOffset;		
								
								//console.log('sqlQuery = '+sqlQuery);	
								
								pool.getConnection(function(error, connection) {									
									// Use the database connection
									var options = {sql: sqlQuery, nestTables: '_'};
									connection.query(options, function (error, results, fields) {
									// And done with the database connection.
										connection.release();

										if (error) { 
											throw error; 
										} else {
											if(!results) {
												return callback(null, null);
											} else {
												//console.log('Broadcast Jobs = '+ JSON.stringify(results, null, 2));
												return callback(null, results);
											}			
											return callback(null, null);
										}

										// Don't use the connection here, it has been returned to the pool.
									});
								});
							}
						});
					}
				}
			});			
			
					
		},	
		*/
		
		
		//=================================================================
		/* 
		Function to get list of broadcasted jobs by user ID
		*/
		
		/*
		getJobListPublishTypeBroadcastByUserId______________20180328: function(offset, callback) {
			
			var user_id 			= 	AuthenticUser.id;
			//console.log('user_id = '+user_id);
			if (typeof user_id === 'undefined' || user_id === null || parseInt(user_id)<=0) {
				user_id	=	0;
			} else {
				user_id = parseInt(user_id);
			}
			
			if (typeof offset === 'undefined' || offset === null || parseInt(offset)<=0) {
				offset	=	0;
			} else {
				offset = parseInt(offset);
			}

			JobFilterModel.getJobFilterByUserId(function(error, results) {  
				if (error) {    
					throw error;
				} else { 
					if(results) {
						job_filter	=	results;
						
						//console.log('Job Filter = '+ JSON.stringify(results, null, 2));
						//console.log('Job Filter job_type = '+ job_filter[0]['job_type']);
						
						var user_id				=	job_filter[0]['job_filter']['user_id'];
						var industry_sector_id	=	job_filter[0]['job_filter']['industry_sector_id'];
						var job_type			=	job_filter[0]['job_filter']['job_type'];
						var keyword				=	job_filter[0]['job_filter']['keyword'];
						var rate_min			=	job_filter[0]['job_filter']['rate_min'];
						var rate_max			=	job_filter[0]['job_filter']['rate_max'];
						var location			=	job_filter[0]['job_filter']['location'];
						var latitude			=	job_filter[0]['job_filter']['latitude'];
						var longitude			=	job_filter[0]['job_filter']['longitude'];			
						var distance			=	job_filter[0]['job_filter']['distance'];
						var filter_invite_jobs	=	job_filter[0]['job_filter']['filter_invite_jobs'];
						
						//console.log('Job Filter user_id = '+ user_id);
						//console.log('Job Filter industry_sector_id = '+ industry_sector_id);
						//console.log('Job Filter rate_min = '+ rate_min);
						//console.log('Job Filter rate_max = '+ rate_max);
						
						ProjectModel.getProjectByJobFilter(job_filter, function(error, results) {				
				
							if (error) {    
								throw error;
							} else {
								
								//console.log('project ids = '+results);
								
								var project_ids			=	results;
								
								var sqlSelectArray 		= 	[];			
								var sqlJoinArray 		= 	[];
								var sqlQueryWhereArray 	= 	[];
								
								var sqlSelect		 	= 	'';
								var sqlFromTable		= 	'';
								var sqlJoin		 		= 	'';			
								var sqlQueryWhere		=	'';
								var sqlOrderBy			=	'';
								var sqlLimit			=	' LIMIT '+config.params.SQL_LIMIT_JOB;
								var sqlOffset			=	' OFFSET '+offset;
								
								sqlFromTable			=	' FROM job ';
								sqlOrderBy				=	' ORDER BY job.id DESC ';
								
								sqlSelectArray.push("SELECT job.id, job.job_type, job.created_by, job.job_share_level, job.job_copy_id, job.reference_number, job.job_L0_id, job.job_L0_reference_number, job.project_id, job.industry_sector_id, job.sub_industry_sector_id, job.sector_role_id, job.hiring_manager_name, job.hiring_manager_email, job.hiring_manager_mobile, job.start_date, job.end_date, job.expiry_time, job.title, job.expiry_time, job.contract_duration, job.duration_type_id, job.rate, job.currency_id, job.rate_type_id, job.description, job.attachment, job.invite_message, job.status_authentic, job.publish_type, job.status_delete");
								sqlSelectArray.push("createdBy.id, createdBy.username, createdBy.mobile, createdBy.first_name, createdBy.last_name, createdBy.full_name");
								sqlSelectArray.push("createdByFromContact.id, createdByFromContact.user_id_contact, createdByFromContact.first_name, createdByFromContact.last_name, createdByFromContact.full_name");
								sqlSelectArray.push("project.title, project.organistion, project.location, project.latitude, project.longitude, project.start_date, project.end_date");
								sqlSelectArray.push("sector_role.title");
								sqlSelectArray.push("currency.title, currency.symbol");
								sqlSelectArray.push("rate_type.title");
								sqlSelectArray.push("duration_type.title");						
								
								sqlJoinArray.push("LEFT JOIN user AS createdBy ON createdBy.id = job.created_by");
								sqlJoinArray.push("LEFT JOIN contact AS createdByFromContact ON createdByFromContact.user_id_contact = job.created_by AND (createdByFromContact.user_id ="+pool.escape(user_id)+" )");
								sqlJoinArray.push("LEFT JOIN project ON job.project_id = project.id");
								sqlJoinArray.push("LEFT JOIN sector_role ON sector_role.id = job.sector_role_id");
								sqlJoinArray.push("LEFT JOIN currency ON job.currency_id = currency.id");
								sqlJoinArray.push("LEFT JOIN rate_type ON job.rate_type_id = rate_type.id");
								sqlJoinArray.push("LEFT JOIN duration_type ON job.duration_type_id = duration_type.id");						
										
								sqlQueryWhereArray.push(" WHERE job.publish_type = "+pool.escape(config.JOB.PUBLISH_TYPE.BROADCAST));
								sqlQueryWhereArray.push("job.expiry_time > UNIX_TIMESTAMP()");
								sqlQueryWhereArray.push("job.status_delete IS "+pool.escape(config.JOB.STATUS_DELETE_NO));
								
								sqlQueryWhereArray.push("job.user_role_id IN ("+pool.escape(config.USER.ROLE_SUPERADMIN)+","+pool.escape(config.USER.ROLE_ADMIN)+","+pool.escape(config.USER.ROLE_AGENT)+")");
								
								sqlQueryWhere 	= 	sqlQueryWhereArray.join(' AND ');						
								sqlSelect		=	sqlSelectArray.join(', ');			
								sqlJoin			=	sqlJoinArray.join(' ');			
								sqlQueryWhere	=	sqlQueryWhereArray.join(' AND ');

								var sqlQuery	=	sqlSelect + sqlFromTable + sqlJoin + sqlQueryWhere + sqlOrderBy + sqlLimit + sqlOffset;		
								
								//console.log('sqlQuery = '+sqlQuery);	
								
								pool.getConnection(function(error, connection) {									
									// Use the database connection
									var options = {sql: sqlQuery, nestTables: '_'};
									connection.query(options, function (error, results, fields) {
									// And done with the database connection.
										connection.release();

										if (error) { 
											throw error; 
										} else {
											if(!results) {
												return callback(null, null);
											} else {
												//console.log('Broadcast Jobs = '+ JSON.stringify(results, null, 2));
												return callback(null, results);
											}			
											return callback(null, null);
										}

										// Don't use the connection here, it has been returned to the pool.
									});
								});
							}
						});
					}
				}
			});			
			
					
		},
		*/
		//=================================================================
		/* 
		Function to get list of broadcasted jobs by user ID
		*/
		getJobListPublishTypeBroadcastByUserId: function(offset, callback) {
			
			var user_id 			= 	AuthenticUser.id;
			//console.log('user_id = '+user_id);
			if (typeof user_id === 'undefined' || user_id === null || parseInt(user_id)<=0) {
				user_id	=	0;
			} else {
				user_id = parseInt(user_id);
			}
			
			if (typeof offset === 'undefined' || offset === null || parseInt(offset)<=0) {
				offset	=	0;
			} else {
				offset = parseInt(offset);
			}

			JobFilterModel.getJobFilterByUserId(function(error, results) {  
				if (error) {    
					throw error;
				} else { 
					if(results) {
						job_filter	=	results;
						
						//console.log('Job Filter = '+ JSON.stringify(results, null, 2));
						//console.log('Job Filter job_type = '+ job_filter[0]['job_type']);
						
						var user_id				=	job_filter[0]['job_filter']['user_id'];
						var industry_sector_id	=	job_filter[0]['job_filter']['industry_sector_id'];
						var job_type			=	job_filter[0]['job_filter']['job_type'];
						var keyword				=	job_filter[0]['job_filter']['keyword'];
						var rate_min			=	job_filter[0]['job_filter']['rate_min'];
						var rate_max			=	job_filter[0]['job_filter']['rate_max'];
						var location			=	job_filter[0]['job_filter']['location'];
						var latitude			=	job_filter[0]['job_filter']['latitude'];
						var longitude			=	job_filter[0]['job_filter']['longitude'];			
						var distance			=	job_filter[0]['job_filter']['distance'];
						var filter_invite_jobs	=	job_filter[0]['job_filter']['filter_invite_jobs'];
						
						//console.log('Job Filter user_id = '+ user_id);
						//console.log('Job Filter industry_sector_id = '+ industry_sector_id);
						//console.log('Job Filter rate_min = '+ rate_min);
						//console.log('Job Filter rate_max = '+ rate_max);
						
						ProjectModel.getProjectByJobFilter(job_filter, function(error, results) {				
				
							if (error) {    
								throw error;
							} else {
								
								var project_ids			=	results;
								
								//console.log('project ids = '+results);
								
								JobApplyModel.getAppliedJobIds(function(error, results) {
									
									var job_apply_ids	=	results;
									
									//console.log('job_apply_ids = '+results);
									//console.log('job_apply_ids.length = '+results.length);							
								
									var sqlSelectArray 		= 	[];			
									var sqlJoinArray 		= 	[];
									var sqlQueryWhereArray 	= 	[];
									
									var sqlSelect		 	= 	'';
									var sqlFromTable		= 	'';
									var sqlJoin		 		= 	'';			
									var sqlQueryWhere		=	'';
									var sqlOrderBy			=	'';
									var sqlLimit			=	' LIMIT '+config.params.SQL_LIMIT_JOB;
									var sqlOffset			=	' OFFSET '+offset;
									
									sqlFromTable			=	' FROM job ';
									//sqlOrderBy				=	' ORDER BY job.id DESC ';
									sqlOrderBy				=	' ORDER BY job.expiry_time DESC ';
									
									sqlSelectArray.push("SELECT job.id, job.job_type, job.created_by, job.user_role_id, job.job_share_level, job.job_copy_id, job.reference_number, job.job_L0_id, job.job_L0_reference_number, job.project_id, job.industry_sector_id, job.sub_industry_sector_id, job.sector_role_id, job.hiring_manager_name, job.hiring_manager_email, job.hiring_manager_mobile, job.start_date, job.end_date, job.expiry_time, job.title, job.expiry_time, job.contract_duration, job.duration_type_id, job.rate, job.currency_id, job.rate_type_id, job.description, job.attachment, job.invite_message, job.status_authentic, job.publish_type, job.status_delete");
									sqlSelectArray.push("createdBy.id, createdBy.username, createdBy.mobile, createdBy.first_name, createdBy.last_name, createdBy.full_name");
									sqlSelectArray.push("createdByFromContact.id, createdByFromContact.user_id_contact, createdByFromContact.first_name, createdByFromContact.last_name, createdByFromContact.full_name");
									sqlSelectArray.push("project.title, project.organistion, project.location, project.latitude, project.longitude, project.start_date, project.end_date");
									sqlSelectArray.push("sector_role.title");
									sqlSelectArray.push("currency.title, currency.symbol");
									sqlSelectArray.push("rate_type.title");
									sqlSelectArray.push("duration_type.title");						
									
									sqlJoinArray.push("LEFT JOIN user AS createdBy ON createdBy.id = job.created_by");
									sqlJoinArray.push("LEFT JOIN contact AS createdByFromContact ON createdByFromContact.user_id_contact = job.created_by AND (createdByFromContact.user_id ="+pool.escape(user_id)+" )");
									sqlJoinArray.push("LEFT JOIN project ON job.project_id = project.id");
									sqlJoinArray.push("LEFT JOIN sector_role ON sector_role.id = job.sector_role_id");
									sqlJoinArray.push("LEFT JOIN currency ON job.currency_id = currency.id");
									sqlJoinArray.push("LEFT JOIN rate_type ON job.rate_type_id = rate_type.id");
									sqlJoinArray.push("LEFT JOIN duration_type ON job.duration_type_id = duration_type.id");						
											
									sqlQueryWhereArray.push(" WHERE job.publish_type = "+pool.escape(config.JOB.PUBLISH_TYPE.BROADCAST));
									sqlQueryWhereArray.push("job.expiry_time > UNIX_TIMESTAMP()");
									sqlQueryWhereArray.push("job.status_delete IS "+pool.escape(config.JOB.STATUS_DELETE_NO));
									sqlQueryWhereArray.push("job.status_close_by_admin IS "+pool.escape(config.JOB.STATUS_CLOSE_BY_ADMIN.NO));
									sqlQueryWhereArray.push("job.status_close_by_admin_parent_job IS "+pool.escape(config.JOB.STATUS_CLOSE_BY_ADMIN_PARENT_JOB.NO));
									sqlQueryWhereArray.push("job.user_role_id IN ("+pool.escape(config.USER.ROLE_SUPERADMIN)+","+pool.escape(config.USER.ROLE_ADMIN)+","+pool.escape(config.USER.ROLE_AGENT)+")");
									
									if (typeof job_apply_ids !== 'undefined' && job_apply_ids !== null && job_apply_ids.length>0) {
										sqlQueryWhereArray.push("job.id NOT IN ("+job_apply_ids+")");
									}
									
									/*
									if (typeof project_ids !== 'undefined' && project_ids !== null) {
										sqlQueryWhereArray.push("job.project_id IN ("+pool.escape(project_ids)+")");			
									}						
									if (typeof industry_sector_id !== 'undefined' && industry_sector_id !== null) {
										sqlQueryWhereArray.push("job.industry_sector_id = "+pool.escape(industry_sector_id));				
									}  
									if (typeof job_type !== 'undefined' && job_type !== null) {
										sqlQueryWhereArray.push("job.job_type = "+pool.escape(job_type));
									}
									if (typeof rate_min !== 'undefined' && rate_min !== null) {
										sqlQueryWhereArray.push("job.rate >= "+pool.escape(rate_min));
									}
									if (typeof rate_max !== 'undefined' && rate_max !== null) {
										sqlQueryWhereArray.push("job.rate <= "+pool.escape(rate_max));
									}
									if (typeof keyword !== 'undefined' && keyword !== null && keyword.length>0) {
										sqlQueryWhereArray.push("MATCH (job.description) AGAINST ("+pool.escape(keyword)+" IN BOOLEAN  MODE)");
									}
									*/
									sqlQueryWhere 	= 	sqlQueryWhereArray.join(' AND ');						
									sqlSelect		=	sqlSelectArray.join(', ');			
									sqlJoin			=	sqlJoinArray.join(' ');			
									sqlQueryWhere	=	sqlQueryWhereArray.join(' AND ');

									var sqlQuery	=	sqlSelect + sqlFromTable + sqlJoin + sqlQueryWhere + sqlOrderBy + sqlLimit + sqlOffset;		
									
									//console.log('sqlQuery = '+sqlQuery);	
									
									pool.getConnection(function(error, connection) {									
										// Use the database connection
										var options = {sql: sqlQuery, nestTables: '_'};
										connection.query(options, function (error, results, fields) {
										// And done with the database connection.
											connection.release();

											if (error) { 
												throw error; 
											} else {
												if(!results) {
													return callback(null, null);
												} else {
													//console.log('Broadcast Jobs = '+ JSON.stringify(results, null, 2));
													return callback(null, results);
												}			
												return callback(null, null);
											}

											// Don't use the connection here, it has been returned to the pool.
										});
									});
									
								});
								
								
							}
						});
					}
				}
			});			
			
					
		},
		//=================================================================
		/* 
		Function to get count of available broadcasted jobs by user ID
		*/
		/*
		getCountAvailableBroadcastedJobsByUserId_______________20180320: function(callback) {
			
			//console.log('getCountAvailableBroadcastedJobsByUserId');
			
			var user_id 			= 	AuthenticUser.id;
			
			if (typeof user_id === 'undefined' || user_id === null || parseInt(user_id)<=0) {
				user_id	=	0;
			} else {
				user_id = parseInt(user_id);
			}
			
			//console.log('user_id = '+ user_id);

			JobFilterModel.getJobFilterByUserId(function(error, results) {  
				if (error) {    
					throw error;
				} else { 
					if(results) {
						job_filter	=	results;
						
						//console.log('Job Filter = '+ JSON.stringify(results, null, 2));
						//console.log('Job Filter job_type = '+ job_filter[0]['job_type']);
						
						var user_id				=	job_filter[0]['job_filter']['user_id'];
						var industry_sector_id	=	job_filter[0]['job_filter']['industry_sector_id'];
						var job_type			=	job_filter[0]['job_filter']['job_type'];
						var keyword				=	job_filter[0]['job_filter']['keyword'];
						var rate_min			=	job_filter[0]['job_filter']['rate_min'];
						var rate_max			=	job_filter[0]['job_filter']['rate_max'];
						var location			=	job_filter[0]['job_filter']['location'];
						var latitude			=	job_filter[0]['job_filter']['latitude'];
						var longitude			=	job_filter[0]['job_filter']['longitude'];			
						var distance			=	job_filter[0]['job_filter']['distance'];
						var filter_invite_jobs	=	job_filter[0]['job_filter']['filter_invite_jobs'];
						
						//console.log('Job Filter user_id = '+ user_id);
						//console.log('Job Filter industry_sector_id = '+ industry_sector_id);
						
						ProjectModel.getProjectByJobFilter(job_filter, function(error, results) {				
				
							if (error) {    
								throw error;
							} else {
								
								//console.log('project ids = '+results);
								
								var project_ids			=	results;
								
								var sqlSelectArray 		= 	[];			
								var sqlJoinArray 		= 	[];
								var sqlQueryWhereArray 	= 	[];
								
								var sqlSelect		 	= 	'';
								var sqlFromTable		= 	'';
								var sqlJoin		 		= 	'';			
								var sqlQueryWhere		=	'';
								var sqlOrderBy			=	'';
								var sqlLimit			=	'';
								var sqlOffset			=	'';
								
								sqlFromTable			=	' FROM job ';
								sqlOrderBy				=	' ORDER BY job.id DESC ';
								
								sqlSelectArray.push("SELECT COUNT(job.id) AS count_broadcast_job");
								
								
								
								
								sqlQueryWhereArray.push(" WHERE job.publish_type = "+pool.escape(config.JOB.PUBLISH_TYPE.BROADCAST));
								sqlQueryWhereArray.push("job.expiry_time > UNIX_TIMESTAMP()");
								sqlQueryWhereArray.push("job.status_delete IS "+pool.escape(config.JOB.STATUS_DELETE_NO));
								sqlQueryWhereArray.push("job.user_role_id = "+pool.escape(config.USER.ROLE_AGENT));

								if (typeof project_ids !== 'undefined' && project_ids !== null) {
									sqlQueryWhereArray.push("job.project_id IN ("+pool.escape(project_ids)+")");			
								}						
								if (typeof industry_sector_id !== 'undefined' && industry_sector_id !== null) {
									sqlQueryWhereArray.push("job.industry_sector_id = "+pool.escape(industry_sector_id));				
								}  
								if (typeof job_type !== 'undefined' && job_type !== null) {
									sqlQueryWhereArray.push("job.job_type = "+pool.escape(job_type));
								}
								if (typeof rate_min !== 'undefined' && rate_min !== null) {
									sqlQueryWhereArray.push("job.rate >= "+pool.escape(rate_min));
								}
								if (typeof rate_max !== 'undefined' && rate_max !== null) {
									sqlQueryWhereArray.push("job.rate <= "+pool.escape(rate_max));
								}
								if (typeof keyword !== 'undefined' && keyword !== null && keyword.length>0) {
									//sqlQueryWhereArray.push("MATCH (job.description) AGAINST ('"+keyword+"' IN NATURAL LANGUAGE MODE)");
									//sqlQueryWhereArray.push("MATCH (job.description) AGAINST ("+dbConnection.escape(keyword)+" IN NATURAL LANGUAGE MODE)");
									sqlQueryWhereArray.push("MATCH (job.description) AGAINST ("+pool.escape(keyword)+" IN BOOLEAN  MODE)");
								}
								sqlQueryWhere 	= 	sqlQueryWhereArray.join(' AND ');						
								sqlSelect		=	sqlSelectArray.join(', ');			
								sqlJoin			=	sqlJoinArray.join(' ');			
								sqlQueryWhere	=	sqlQueryWhereArray.join(' AND ');

								var sqlQuery	=	sqlSelect + sqlFromTable + sqlJoin + sqlQueryWhere + sqlOrderBy + sqlLimit + sqlOffset;		
							
								//console.log('sqlQuery = '+sqlQuery);	
							
								pool.getConnection(function(error, connection) {									
									// Use the database connection
									var options = {sql: sqlQuery, nestTables: false};
									connection.query(options, function (error, results, fields) {
									// And done with the database connection.
										connection.release();

										if (error) { 
											throw error; 
										} else {
											if(!results) {
												return callback(null, null);
											} else {
												return callback(null, results);
											}			
											return callback(null, null);
										}

										// Don't use the connection here, it has been returned to the pool.
									});
								});
							}
						});
					}
				}
			});			
			
					
		},
		*/
		//=================================================================
		/* 
		Function to get count of available broadcasted jobs by user ID
		*/
		/*
		getCountAvailableBroadcastedJobsByUserId_______________20180328: function(callback) {
			
			//console.log('getCountAvailableBroadcastedJobsByUserId');
			
			var user_id 			= 	AuthenticUser.id;
			
			if (typeof user_id === 'undefined' || user_id === null || parseInt(user_id)<=0) {
				user_id	=	0;
			} else {
				user_id = parseInt(user_id);
			}
			
			//console.log('user_id = '+ user_id);

			JobFilterModel.getJobFilterByUserId(function(error, results) {  
				if (error) {    
					throw error;
				} else { 
					if(results) {
						job_filter	=	results;
						
						//console.log('Job Filter = '+ JSON.stringify(results, null, 2));
						//console.log('Job Filter job_type = '+ job_filter[0]['job_type']);
						
						var user_id				=	job_filter[0]['job_filter']['user_id'];
						var industry_sector_id	=	job_filter[0]['job_filter']['industry_sector_id'];
						var job_type			=	job_filter[0]['job_filter']['job_type'];
						var keyword				=	job_filter[0]['job_filter']['keyword'];
						var rate_min			=	job_filter[0]['job_filter']['rate_min'];
						var rate_max			=	job_filter[0]['job_filter']['rate_max'];
						var location			=	job_filter[0]['job_filter']['location'];
						var latitude			=	job_filter[0]['job_filter']['latitude'];
						var longitude			=	job_filter[0]['job_filter']['longitude'];			
						var distance			=	job_filter[0]['job_filter']['distance'];
						var filter_invite_jobs	=	job_filter[0]['job_filter']['filter_invite_jobs'];
						
						//console.log('Job Filter user_id = '+ user_id);
						//console.log('Job Filter industry_sector_id = '+ industry_sector_id);
						
						ProjectModel.getProjectByJobFilter(job_filter, function(error, results) {				
				
							if (error) {    
								throw error;
							} else {
								
								//console.log('project ids = '+results);
								
								var project_ids			=	results;
								
								var sqlSelectArray 		= 	[];			
								var sqlJoinArray 		= 	[];
								var sqlQueryWhereArray 	= 	[];
								
								var sqlSelect		 	= 	'';
								var sqlFromTable		= 	'';
								var sqlJoin		 		= 	'';			
								var sqlQueryWhere		=	'';
								var sqlOrderBy			=	'';
								var sqlLimit			=	'';
								var sqlOffset			=	'';
								
								sqlFromTable			=	' FROM job ';
								sqlOrderBy				=	' ORDER BY job.id DESC ';
								
								sqlSelectArray.push("SELECT COUNT(job.id) AS count_broadcast_job");
																
								sqlQueryWhereArray.push(" WHERE job.publish_type = "+pool.escape(config.JOB.PUBLISH_TYPE.BROADCAST));
								sqlQueryWhereArray.push("job.expiry_time > UNIX_TIMESTAMP()");
								sqlQueryWhereArray.push("job.status_delete IS "+pool.escape(config.JOB.STATUS_DELETE_NO));
								sqlQueryWhereArray.push("job.user_role_id IN ("+pool.escape(config.USER.ROLE_SUPERADMIN)+","+pool.escape(config.USER.ROLE_ADMIN)+","+pool.escape(config.USER.ROLE_AGENT)+")");
								
								
								sqlQueryWhere 	= 	sqlQueryWhereArray.join(' AND ');						
								sqlSelect		=	sqlSelectArray.join(', ');			
								sqlJoin			=	sqlJoinArray.join(' ');			
								sqlQueryWhere	=	sqlQueryWhereArray.join(' AND ');

								var sqlQuery	=	sqlSelect + sqlFromTable + sqlJoin + sqlQueryWhere + sqlOrderBy + sqlLimit + sqlOffset;		
							
								//console.log('sqlQuery = '+sqlQuery);	
							
								pool.getConnection(function(error, connection) {									
									// Use the database connection
									var options = {sql: sqlQuery, nestTables: false};
									connection.query(options, function (error, results, fields) {
									// And done with the database connection.
										connection.release();

										if (error) { 
											throw error; 
										} else {
											if(!results) {
												return callback(null, null);
											} else {
												return callback(null, results);
											}			
											return callback(null, null);
										}

										// Don't use the connection here, it has been returned to the pool.
									});
								});
							}
						});
					}
				}
			});			
			
					
		},
		*/
		//=================================================================
		/* 
		Function to get count of available broadcasted jobs by user ID
		*/
		getCountAvailableBroadcastedJobsByUserId: function(callback) {
			
			//console.log('getCountAvailableBroadcastedJobsByUserId');
			
			var user_id 			= 	AuthenticUser.id;
			
			if (typeof user_id === 'undefined' || user_id === null || parseInt(user_id)<=0) {
				user_id	=	0;
			} else {
				user_id = parseInt(user_id);
			}
			
			//console.log('user_id = '+ user_id);

			JobFilterModel.getJobFilterByUserId(function(error, results) {  
				if (error) {    
					throw error;
				} else { 
					if(results) {
						job_filter	=	results;
						
						//console.log('Job Filter = '+ JSON.stringify(results, null, 2));
						//console.log('Job Filter job_type = '+ job_filter[0]['job_type']);
						
						var user_id				=	job_filter[0]['job_filter']['user_id'];
						var industry_sector_id	=	job_filter[0]['job_filter']['industry_sector_id'];
						var job_type			=	job_filter[0]['job_filter']['job_type'];
						var keyword				=	job_filter[0]['job_filter']['keyword'];
						var rate_min			=	job_filter[0]['job_filter']['rate_min'];
						var rate_max			=	job_filter[0]['job_filter']['rate_max'];
						var location			=	job_filter[0]['job_filter']['location'];
						var latitude			=	job_filter[0]['job_filter']['latitude'];
						var longitude			=	job_filter[0]['job_filter']['longitude'];			
						var distance			=	job_filter[0]['job_filter']['distance'];
						var filter_invite_jobs	=	job_filter[0]['job_filter']['filter_invite_jobs'];
						
						//console.log('Job Filter user_id = '+ user_id);
						//console.log('Job Filter industry_sector_id = '+ industry_sector_id);
						
						ProjectModel.getProjectByJobFilter(job_filter, function(error, results) {				
				
							if (error) {    
								throw error;
							} else {
								
								//console.log('project ids = '+results);
								
								var project_ids			=	results;
								
								JobApplyModel.getAppliedJobIds(function(error, results) {
									
									var job_apply_ids		=	results;
									
									var sqlSelectArray 		= 	[];			
									var sqlJoinArray 		= 	[];
									var sqlQueryWhereArray 	= 	[];
									
									var sqlSelect		 	= 	'';
									var sqlFromTable		= 	'';
									var sqlJoin		 		= 	'';
									var sqlQueryWhere		=	'';
									var sqlOrderBy			=	'';
									var sqlLimit			=	'';
									var sqlOffset			=	'';
									
									sqlFromTable			=	' FROM job ';
									sqlOrderBy				=	' ORDER BY job.id DESC ';
									
									sqlSelectArray.push("SELECT COUNT(job.id) AS count_broadcast_job");
																	
									sqlQueryWhereArray.push(" WHERE job.publish_type = "+pool.escape(config.JOB.PUBLISH_TYPE.BROADCAST));
									sqlQueryWhereArray.push("job.expiry_time > UNIX_TIMESTAMP()");
									sqlQueryWhereArray.push("job.status_delete IS "+pool.escape(config.JOB.STATUS_DELETE_NO));
									sqlQueryWhereArray.push("job.status_close_by_admin IS "+pool.escape(config.JOB.STATUS_CLOSE_BY_ADMIN.NO));
									sqlQueryWhereArray.push("job.status_close_by_admin_parent_job IS "+pool.escape(config.JOB.STATUS_CLOSE_BY_ADMIN_PARENT_JOB.NO));
									sqlQueryWhereArray.push("job.user_role_id IN ("+pool.escape(config.USER.ROLE_SUPERADMIN)+","+pool.escape(config.USER.ROLE_ADMIN)+","+pool.escape(config.USER.ROLE_AGENT)+")");
									
									if (typeof job_apply_ids !== 'undefined' && job_apply_ids !== null && job_apply_ids.length>0) {
										sqlQueryWhereArray.push("job.id NOT IN ("+job_apply_ids+")");
									}
									
									/*
									if (typeof project_ids !== 'undefined' && project_ids !== null) {
										sqlQueryWhereArray.push("job.project_id IN ("+pool.escape(project_ids)+")");			
									}						
									if (typeof industry_sector_id !== 'undefined' && industry_sector_id !== null) {
										sqlQueryWhereArray.push("job.industry_sector_id = "+pool.escape(industry_sector_id));				
									}  
									if (typeof job_type !== 'undefined' && job_type !== null) {
										sqlQueryWhereArray.push("job.job_type = "+pool.escape(job_type));
									}
									if (typeof rate_min !== 'undefined' && rate_min !== null) {
										sqlQueryWhereArray.push("job.rate >= "+pool.escape(rate_min));
									}
									if (typeof rate_max !== 'undefined' && rate_max !== null) {
										sqlQueryWhereArray.push("job.rate <= "+pool.escape(rate_max));
									}
									if (typeof keyword !== 'undefined' && keyword !== null && keyword.length>0) {
										sqlQueryWhereArray.push("MATCH (job.description) AGAINST ("+pool.escape(keyword)+" IN BOOLEAN  MODE)");
									}
									*/
									sqlQueryWhere 	= 	sqlQueryWhereArray.join(' AND ');						
									sqlSelect		=	sqlSelectArray.join(', ');			
									sqlJoin			=	sqlJoinArray.join(' ');			
									sqlQueryWhere	=	sqlQueryWhereArray.join(' AND ');

									var sqlQuery	=	sqlSelect + sqlFromTable + sqlJoin + sqlQueryWhere + sqlOrderBy + sqlLimit + sqlOffset;		
								
									//console.log('sqlQuery = '+sqlQuery);	
								
									pool.getConnection(function(error, connection) {									
										// Use the database connection
										var options = {sql: sqlQuery, nestTables: false};
										connection.query(options, function (error, results, fields) {
										// And done with the database connection.
											connection.release();

											if (error) { 
												throw error; 
											} else {
												if(!results) {
													return callback(null, null);
												} else {
													return callback(null, results);
												}			
												return callback(null, null);
											}

											// Don't use the connection here, it has been returned to the pool.
										});
									});
								});
								
								
							}
						});
					}
				}
			});			
			
					
		},
		//=================================================================
		/* 
		Function to get count of available broadcasted jobs by user ID
		*/
		/*
		getCountUnreadExclusiveJobsByUserId: function(callback) {
			
			//console.log('getCountUnreadExclusiveJobsByUserId');
			
			var user_id 			= 	AuthenticUser.id;
			
			if (typeof user_id === 'undefined' || user_id === null || parseInt(user_id)<=0) {
				user_id	=	0;
			} else {
				user_id = parseInt(user_id);
			}
			
			//console.log('user_id = '+ user_id);
			
			
			
			var sqlSelectArray 		= 	[];			
			var sqlJoinArray 		= 	[];
			var sqlQueryWhereArray 	= 	[];
			
			var sqlSelect		 	= 	'';
			var sqlFromTable		= 	'';
			var sqlJoin		 		= 	'';			
			var sqlQueryWhere		=	'';
			var sqlOrderBy			=	'';
			var sqlLimit			=	'';
			var sqlOffset			=	'';
			
			sqlFromTable			=	' FROM invite ';
			sqlOrderBy				=	'';
			
			sqlSelectArray.push("SELECT COUNT(invite.id) AS count_exclusive_job");
						
			sqlJoinArray.push("INNER JOIN job ON job.id = invite.job_id");
			
			sqlQueryWhereArray.push(" WHERE invite.invite_to = "+pool.escape(user_id));
			//sqlQueryWhereArray.push("invite.status_job_view_by_invited_user is null");
			sqlQueryWhereArray.push("invite.status_job_view_by_invited_user is "+pool.escape(config.INVITE.STATUS_JOB_VIEW_BY_INVITED_USER_PENDING));
			sqlQueryWhereArray.push("job.publish_type = "+pool.escape(config.JOB.PUBLISH_TYPE.INVITE));
			sqlQueryWhereArray.push("job.expiry_time > UNIX_TIMESTAMP()");
			sqlQueryWhereArray.push("job.status_delete IS "+pool.escape(config.JOB.STATUS_DELETE_NO));
			sqlQueryWhereArray.push("job.user_role_id = "+pool.escape(config.USER.ROLE_AGENT));
						
			sqlQueryWhere 	= 	sqlQueryWhereArray.join(' AND ');						
			sqlSelect		=	sqlSelectArray.join(', ');			
			sqlJoin			=	sqlJoinArray.join(' ');			
			sqlQueryWhere	=	sqlQueryWhereArray.join(' AND ');

			var sqlQuery	=	sqlSelect + sqlFromTable + sqlJoin + sqlQueryWhere + sqlOrderBy + sqlLimit + sqlOffset;		
		
		
			//console.log('sqlQuery = '+sqlQuery);	
		
			pool.getConnection(function(error, connection) {									
				// Use the database connection
				var options = {sql: sqlQuery, nestTables: false};
				connection.query(options, function (error, results, fields) {
				// And done with the database connection.
					connection.release();

					if (error) { 
						throw error; 
					} else {
						if(!results) {
							return callback(null, null);
						} else {
							return callback(null, results);
						}			
						return callback(null, null);
					}

					// Don't use the connection here, it has been returned to the pool.
				});
			});
				
					
		},
		*/
		
		
		//=================================================================
		/* 
		Function to get count of available broadcasted jobs by user ID
		*/
		getCountUnreadExclusiveJobsByUserId: function(postData, callback) {
			
			//console.log('getCountUnreadExclusiveJobsByUserId');
			
			var filter_type			=	postData.filter_type;
			
			//var user_role_id_include			=	postData.filter_type;	
			//var user_role_id_exclude			=	postData.user_role_id_exclude;	
			//console.log('user_role_id = '+user_role_id);
			//console.log('user_role_id = '+user_role_id.length);
			console.log('filter_type = '+filter_type);
			
			var user_id 			= 	AuthenticUser.id;
			
			if (typeof user_id === 'undefined' || user_id === null || parseInt(user_id)<=0) {
				user_id	=	0;
			} else {
				user_id = parseInt(user_id);
			}
			
			//console.log('user_id = '+ user_id);
			
			var invitedJobIds 		= 	[];
			var appliedJobIds 		= 	[];
			var sharedJobIds 		= 	[];
			var ignoreJobIds 		= 	[];
			
			JobInviteModel.getInvitedJobIdsByUserId(function(error, results) {  
						
				if (error) {    
					throw error;
				} else {
					//console.log('results = '+ results);
					if(!results) {										
						return callback(null, 0);									
					} else {
						
						//console.log(results);						
						
						invitedJobIds	=	results;
						
						//console.log('invitedJobIds = '+ invitedJobIds);
						
						JobApplyModel.getAppliedJobIds(function(error, results) {  
						
							if (error) {    
								throw error;
							} else {									
								if (typeof results === 'undefined' || results === null) {
									appliedJobIds.push(0);
								} else {
									appliedJobIds	=	results;
								}											
								
								//console.log('appliedJobIds = '+ appliedJobIds);
								
								JobModel.getSharedJobIds(invitedJobIds, function(error, results) {  
					
									if (error) {    
										throw error;
									} else {
										if (typeof results === 'undefined' || results === null) {
											sharedJobIds.push(0);
										} else {
											sharedJobIds	=	results;
										}
																						
										//console.log('invitedJobIds = '+ invitedJobIds);
										//console.log('appliedJobIds = '+ appliedJobIds);
										//console.log('sharedJobIds = '+ sharedJobIds);
										
										ignoreJobIds = appliedJobIds.concat(sharedJobIds);
										ignoreJobIds = ignoreJobIds.filter((v, i, a) => a.indexOf(v) === i); 
										
										//console.log('ignoreJobIds = '+ ignoreJobIds);
										
										var sqlSelectArray 		= 	[];			
										var sqlJoinArray 		= 	[];
										var sqlQueryWhereArray 	= 	[];
										
										var sqlSelect		 	= 	'';
										var sqlFromTable		= 	'';
										var sqlJoin		 		= 	'';			
										var sqlQueryWhere		=	'';
										var sqlOrderBy			=	'';
										var sqlLimit			=	'';
										var sqlOffset			=	'';
										
										sqlFromTable			=	' FROM invite ';
										sqlOrderBy				=	'';
										
										sqlSelectArray.push("SELECT COUNT(invite.id) AS count_exclusive_job");
													
										sqlJoinArray.push("INNER JOIN job ON job.id = invite.job_id");
										sqlJoinArray.push("INNER JOIN job AS jobL0 ON jobL0.id = job.job_L0_id");
										
										sqlQueryWhereArray.push(" WHERE invite.invite_to = "+pool.escape(user_id));
										//sqlQueryWhereArray.push("invite.status_job_view_by_invited_user is null");
										sqlQueryWhereArray.push("invite.status_job_view_by_invited_user is "+pool.escape(config.INVITE.STATUS_JOB_VIEW_BY_INVITED_USER_PENDING));
										sqlQueryWhereArray.push("job.publish_type = "+pool.escape(config.JOB.PUBLISH_TYPE.INVITE));
										sqlQueryWhereArray.push("job.expiry_time > UNIX_TIMESTAMP()");
										sqlQueryWhereArray.push("job.status_delete IS "+pool.escape(config.JOB.STATUS_DELETE_NO));
										sqlQueryWhereArray.push("job.status_close_by_admin IS "+pool.escape(config.JOB.STATUS_CLOSE_BY_ADMIN.NO));
										sqlQueryWhereArray.push("job.status_close_by_admin_parent_job IS "+pool.escape(config.JOB.STATUS_CLOSE_BY_ADMIN_PARENT_JOB.NO));
										//sqlQueryWhereArray.push("job.user_role_id = "+pool.escape(config.USER.ROLE_AGENT));
										//sqlQueryWhereArray.push("job.user_role_id IN ("+pool.escape(config.USER.ROLE_SUPERADMIN)+","+pool.escape(config.USER.ROLE_ADMIN)+","+pool.escape(config.USER.ROLE_AGENT)+")");
										
										if(filter_type=='AVOKO') {
											//sqlQueryWhereArray.push("job.user_role_id IN ("+pool.escape(config.USER.ROLE_SUPERADMIN)+","+pool.escape(config.USER.ROLE_ADMIN)+")");	
											sqlQueryWhereArray.push("jobL0.user_role_id IN ("+pool.escape(config.USER.ROLE_SUPERADMIN)+","+pool.escape(config.USER.ROLE_ADMIN)+")");
										}
										if(filter_type=='ASSOCIATE') {
											sqlQueryWhereArray.push("job.user_role_id = "+pool.escape(config.USER.ROLE_AGENT));
											sqlQueryWhereArray.push("jobL0.user_role_id NOT IN ("+pool.escape(config.USER.ROLE_SUPERADMIN)+","+pool.escape(config.USER.ROLE_ADMIN)+")");
										}
										//sqlQueryWhereArray.push("jobL0.user_role_id NOT IN ("+pool.escape(config.USER.ROLE_ADMIN)+","+pool.escape(config.USER.ROLE_AGENT)+")");										
										
										if(ignoreJobIds.length) {
											sqlQueryWhereArray.push("job.id NOT IN ("+pool.escape(ignoreJobIds)+")");
										}															
										sqlQueryWhere 	= 	sqlQueryWhereArray.join(' AND ');						
										sqlSelect		=	sqlSelectArray.join(', ');			
										sqlJoin			=	sqlJoinArray.join(' ');			
										sqlQueryWhere	=	sqlQueryWhereArray.join(' AND ');

										var sqlQuery	=	sqlSelect + sqlFromTable + sqlJoin + sqlQueryWhere + sqlOrderBy + sqlLimit + sqlOffset;		
																		
										console.log(filter_type+' --- sqlQuery = '+sqlQuery);	
									
										pool.getConnection(function(error, connection) {									
											// Use the database connection
											var options = {sql: sqlQuery, nestTables: false};
											connection.query(options, function (error, results, fields) {
											// And done with the database connection.
												connection.release();

												if (error) { 
													throw error; 
												} else {
													if(!results) {
														return callback(null, null);
													} else {
														//return callback(null, results);
														var count_exclusive_job = results[0]['count_exclusive_job'];
														return callback(null, count_exclusive_job);
													}			
													return callback(null, null);
												}
												// Don't use the connection here, it has been returned to the pool.
											});
										});															
									}  
								});												
							}  
						});
					}						
				}  
			});
			
			
			
			
				
					
		},
		//=================================================================
		/* 
		Function to get list of forwarded jobs by user ID
		*/
		getJobListSharedByUserId: function(user_id, job_id, callback) {
			
			var sqlSelectArray 		= 	[];			
			var sqlJoinArray 		= 	[];
			var sqlQueryWhereArray 	= 	[];
			
			var sqlSelect		 	= 	'';
			var sqlFromTable		= 	'';
			var sqlJoin		 		= 	'';			
			var sqlQueryWhere		=	'';
			var sqlOrderBy			=	'';
			
			sqlFromTable			=	" FROM job ";
			sqlOrderBy				=	" ORDER BY job.id DESC ";
			
			sqlSelectArray.push("SELECT job.id,  job.job_type, job.created_by, job.job_share_level, job.job_copy_id, job.reference_number, job.job_L0_reference_number, job.project_id, job.industry_sector_id, job.sub_industry_sector_id, job.sector_role_id, job.hiring_manager_name, job.hiring_manager_email, job.hiring_manager_mobile, job.start_date, job.end_date, job.expiry_time, job.title, job.expiry_time, job.contract_duration, job.duration_type_id, job.rate, job.currency_id, job.rate_type_id, job.attachment, job.invite_message, job.status_authentic, job.publish_type, job.status_delete");			
			sqlSelectArray.push("project.location AS project_location");
			sqlSelectArray.push("currency.title");
			sqlSelectArray.push("rate_type.title");
			sqlSelectArray.push("duration_type.title");						
			
			sqlJoinArray.push("LEFT JOIN project ON job.project_id = project.id");
			sqlJoinArray.push("LEFT JOIN currency ON job.currency_id = currency.id");
			sqlJoinArray.push("LEFT JOIN rate_type ON job.rate_type_id = rate_type.id");
			sqlJoinArray.push("LEFT JOIN duration_type ON job.duration_type_id = duration_type.id");			
						
			sqlQueryWhereArray.push(" WHERE job.created_by = "+pool.escape(user_id));
			sqlQueryWhereArray.push("job.id > "+pool.escape(job_id));
			sqlQueryWhereArray.push("job.job_share_level > "+pool.escape(config.JOB.JOB_SHARE_LEVEL_0));
			sqlQueryWhereArray.push("job.publish_type = "+pool.escape(config.JOB.PUBLISH_TYPE.INVITE));
			sqlQueryWhereArray.push("job.user_role_id = "+pool.escape(config.USER.ROLE_AGENT));
			
			sqlSelect		=	sqlSelectArray.join(', ');			
			sqlJoin			=	sqlJoinArray.join(' ');			
			sqlQueryWhere	=	sqlQueryWhereArray.join(' AND ');	
			
			var sqlQuery	=	sqlSelect + sqlFromTable + sqlJoin + sqlQueryWhere + sqlOrderBy;		
			
			//console.log('sqlQuery = '+sqlQuery);
			
			pool.getConnection(function(error, connection) {									
				// Use the database connection
				var options = {sql: sqlQuery, nestTables: true};
				connection.query(options, function (error, results, fields) {
				// And done with the database connection.
					connection.release();

					if (error) { 
						throw error; 
					} else {

						if(!results) {
							return callback(null, null);
						} else {
							return callback(null, results);
						}			
						return callback(null, null);
					}

					// Don't use the connection here, it has been returned to the pool.
				});
			});
		},
		
		//=================================================================
		/* 
		Function to get list of jobs under projects created by user
		*/
		getJobOfProjectByUserId: function(user_id, callback) {
			
			var sqlSelectArray 		= 	[];			
			var sqlJoinArray 		= 	[];
			var sqlQueryWhereArray 	= 	[];
			
			var sqlSelect		 	= 	'';
			var sqlFromTable		= 	'';
			var sqlJoin		 		= 	'';			
			var sqlQueryWhere		=	'';
			var sqlOrderBy			=	'';
			
			sqlFromTable			=	" FROM job ";
			sqlOrderBy				=	" ORDER BY job.id DESC ";
			
			sqlSelectArray.push("SELECT job.id, job.project_id, job.job_type, job.created_by, job.job_share_level, job.job_copy_id, job.reference_number, job.project_id, job.industry_sector_id, job.sub_industry_sector_id, job.sector_role_id, job.hiring_manager_name, job.hiring_manager_email, job.hiring_manager_mobile, job.start_date, job.end_date, job.expiry_time, job.title, job.expiry_time, job.contract_duration, job.duration_type_id, job.rate, job.currency_id, job.rate_type_id, job.attachment, job.invite_message, job.status_authentic, job.publish_type, job.status_delete");			
			sqlSelectArray.push("currency.id, currency.title");
			sqlSelectArray.push("rate_type.id, rate_type.title");
			sqlSelectArray.push("duration_type.id, duration_type.title");						
			
			sqlJoinArray.push("LEFT JOIN project ON job.project_id = project.id");
			sqlJoinArray.push("LEFT JOIN currency ON job.currency_id = currency.id");
			sqlJoinArray.push("LEFT JOIN rate_type ON job.rate_type_id = rate_type.id");
			sqlJoinArray.push("LEFT JOIN duration_type ON job.duration_type_id = duration_type.id");			

			sqlQueryWhereArray.push(" WHERE job.created_by = "+pool.escape(user_id));
			sqlQueryWhereArray.push(" project.created_by = "+pool.escape(user_id));
			sqlQueryWhereArray.push(" project.status = "+config.PROJECT.STATUS.ACTIVE);
						
			sqlSelect		=	sqlSelectArray.join(', ');			
			sqlJoin			=	sqlJoinArray.join(' ');			
			sqlQueryWhere	=	sqlQueryWhereArray.join(' AND ');	
			
			var sqlQuery	=	sqlSelect + sqlFromTable + sqlJoin + sqlQueryWhere + sqlOrderBy;		
			
			//console.log('sqlQuery = '+sqlQuery);
			
			pool.getConnection(function(error, connection) {									
				// Use the database connection
				var options = {sql: sqlQuery, nestTables: true};
				connection.query(options, function (error, results, fields) {
				// And done with the database connection.
					connection.release();

					if (error) { 
						throw error; 
					} else {

						if(!results) {
							return callback(null, null);
						} else {
							return callback(null, results);
						}			
						return callback(null, null);
					}

					// Don't use the connection here, it has been returned to the pool.
				});
			});
		},
		
		
		//=================================================================
		/* 
		Function to get applied job ids by user ID
		*/
		getSharedJobIds: function(invitedJobIds, callback) {
			
			//console.log('getSharedJobIds');
			//console.log(invitedJobIds.length);
			
			var user_id 			= 	AuthenticUser.id;
			
			if (typeof user_id === 'undefined' || user_id === null || parseInt(user_id)<=0) {
				user_id	=	0;
			} else {
				user_id = parseInt(user_id);
			}
			
			//console.log('user_id = '+ user_id);
			
			var shared_job_ids 		= 	[];
			
			var sqlSelectArray 		= 	[];			
			var sqlJoinArray 		= 	[];
			var sqlQueryWhereArray 	= 	[];
			
			var sqlSelect		 	= 	'';
			var sqlFromTable		= 	'';
			var sqlJoin		 		= 	'';			
			var sqlQueryWhere		=	'';
			var sqlOrderBy			=	'';
			var sqlLimit			=	'';
			var sqlOffset			=	'';
			
			sqlFromTable			=	' FROM job ';
			sqlOrderBy				=	'';
			
			sqlSelectArray.push("SELECT job.job_copy_id");		
			
			sqlQueryWhereArray.push(" WHERE job.created_by = "+pool.escape(user_id));
			sqlQueryWhereArray.push("job.job_share_level > 0");
			sqlQueryWhereArray.push("job.job_copy_id IN("+invitedJobIds+")");
						
			sqlQueryWhere 	= 	sqlQueryWhereArray.join(' AND ');						
			sqlSelect		=	sqlSelectArray.join(', ');			
			sqlJoin			=	sqlJoinArray.join(' ');			
			sqlQueryWhere	=	sqlQueryWhereArray.join(' AND ');

			var sqlQuery	=	sqlSelect + sqlFromTable + sqlJoin + sqlQueryWhere + sqlOrderBy + sqlLimit + sqlOffset;		
		
			//console.log('sqlQuery = '+sqlQuery);	
		
			pool.getConnection(function(error, connection) {									
				// Use the database connection
				var options = {sql: sqlQuery, nestTables: false};
				connection.query(options, function (error, results, fields) {
				// And done with the database connection.
					connection.release();

					if (error) { 
						throw error; 
					} else {
						if(!results.length) {
							//return callback(null, null);
							return callback(null, []);
						} else {						
							for (var i=0;i<results.length;i++) {
								shared_job_ids.push(results[i].job_copy_id);							
							}
							return callback(null, shared_job_ids);
						}			
						//return callback(null, null);
						return callback(null, []);
					}

					// Don't use the connection here, it has been returned to the pool.
				});
			});					
		},
		//=================================================================
		
		/* 
		Function to get list of job type
		*/
		getJobType: function(callback) {
			
			var results 	= 	[];
			
			var list_data	=	{
									1 : 'Contractor', 
									2 : 'Permanent',
								};
		
			for (var key in list_data) {
				//console.log("key " + key + " has value " + list_data[key]);
				results.push({id:key, title:list_data[key]});
			}
			
			if(results.length){
				return callback(null, results);
			}
			return callback(null, null);
		},
		//=================================================================
		/* 
		Function to get list of job publish type
		*/
		getJobPublishType: function(callback) {
			
			var results 	= 	[];
			
			var list_data	=	{
									0 : 'Pending', 
									1 : 'Invite',
									2 : 'Broadcast',
								};
		
			for (var key in list_data) {
				//console.log("key " + key + " has value " + list_data[key]);
				results.push({id:key, title:list_data[key]});
			}
			
			if(results.length){
				return callback(null, results);
			}
			return callback(null, null);
		},
		//=================================================================
		/* 
		Function to get list of job expiry time options
		*/
		getJobExpiryTime: function(callback) {
			
			var results 	= 	[];
			
			var list_data	=	{
									72:		'3 days',
									96:		'4 days',
									120:	'5 days',
								};
		
			for (var key in list_data) {
				//console.log("key " + key + " has value " + list_data[key]);
				results.push({id:key, title:list_data[key]});
			}
			
			if(results.length){
				return callback(null, results);
			}
			return callback(null, null);
		},
		//=================================================================
		//=================================================================
		//=================================================================
		//=================================================================
		//=================================================================
		
		
		
	};
	
	module.exports = JobModel;
	