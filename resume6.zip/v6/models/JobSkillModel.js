	/*
	var helpers 				= 	require('../common/components/helpers');
	var ProjectModel 			=	require('../models/ProjectModel');
	var JobInviteModel 			=	require('../models/JobInviteModel');
	var JobFilterModel 			=	require('../models/JobFilterModel');
	*/
	var JobSkillModel	=	{
		
		/* 
		Function to save job skills while creating new job.
		*/
		createJobSkill: function(user, job_id, job_skill, other_skill, callback) {
			
			var user_id		=	user.id;
			var job_id 		=	parseInt(job_id);
			
			//console.log('job_skill = '+job_skill);
			//console.log('other_skill = '+other_skill);
			
			/*
			var sql = "INSERT INTO Test (name, email, n) VALUES ?";
			var values = [
				['demian', 'demian@gmail.com', 1],
				['john', 'john@gmail.com', 2],
				['mark', 'mark@gmail.com', 3],
				['pete', 'pete@gmail.com', 4]
			];
			conn.query(sql, [values], function(err) {
				if (err) throw err;
				conn.end();
			});
			*/
			var values 		= 	[];		
			
			if(job_skill) {
				var job_skill_ids = job_skill.split(",");
				for (var i=0;i<job_skill_ids.length;i++) {
					var skill_id = parseInt(job_skill_ids[i]);
					if(skill_id>0) {
						values.push([user_id, job_id, skill_id, null]);	
					}
				}
			}	
			
			if(other_skill) {
				var other_skills = other_skill.split(",");
				for (var i=0;i<other_skills.length;i++) {
					var others = other_skills[i];
					values.push([user_id, job_id, null, others]);	
					
				}
			}
			
			//console.log('values length = '+values.length);	
			if(values.length) {
				
				var sqlQuery	=	"INSERT INTO job_skill (created_by, job_id, skill_id, others) VALUES ?";
				
				/*
				var values		= 	[
										[user_id, job_id, 1],
										[user_id, job_id, 2],
										[user_id, job_id, 3],
										[user_id, job_id, 4]
									];
				*/
								
				/* 
				pool.getConnection(function(error, connection) {									
					// Use the database connection
					connection.query(sqlQuery, [values], function (error, results, fields) {
					// And done with the database connection.
						connection.release();
					});
				}); 
				*/
				
				pool.getConnection(function(error, connection) {									
					// Use the database connection
					//var options = {sql: sqlQuery, nestTables: true};
					connection.query(sqlQuery, [values], function (error, results, fields) {
					// And done with the database connection.
						connection.release();

						if (error) { 
							throw error; 
						} else {
							if(!results) {
								return callback(null, null);
							} else {						
								return callback(null, results);
							}			
							return callback(null, null);
						}

						// Don't use the connection here, it has been returned to the pool.
					});
				});
			}					
		},		
		
	};
	
	module.exports = JobSkillModel;
	