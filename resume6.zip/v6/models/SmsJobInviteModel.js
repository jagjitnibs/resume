	var SmsJobInviteModel	=	{
		
		//=================================================================
		/* 
		Function to get list of invited jobs by user ID
		*/
		createRealJobInviteFromSMS: function (callback) {
			
			var user_id 			= 	AuthenticUser.id;
			var mobile	 			= 	AuthenticUser.mobile;
			
			SmsJobInviteModel.getSmsJobInvite(function (error, results) {
				
				if (error) {    
					throw error;
				} else {
					if (results) {
						//console.log(results);	
						if(results.length){
							//return callback(null, results);	
							SmsJobInviteModel.createJobInviteData(results, function (error, results) {
				
								if (error) {    
									throw error;
								} else {
									if (results) {
										//console.log(results);	
										if(results.length){
											return callback(null, results);	
										}
															
														
									} else {
										return callback(null, null);	
									}
								}
							});
						}
											
						 				
					} else {
						return callback(null, null);	
					}
				}
			});
			
		},		
		//=================================================================
		/* 
		Function to get list of SMS job invites by user mobile number.
		*/
		getSmsJobInvite: function (callback) {
			
			var user_id 			= 	AuthenticUser.id;
			var mobile	 			= 	AuthenticUser.mobile;
			
			var sqlSelectArray 		= 	[];			
			var sqlJoinArray 		= 	[];
			var sqlQueryWhereArray 	= 	[];
			var sqlGroupByArray 	= 	[];
			
			var sqlSelect		 	= 	'';
			var sqlFromTable		= 	'';
			var sqlJoin		 		= 	'';			
			var sqlQueryWhere		=	'';
			var sqlGroupBy			=	'';
			var sqlOrderBy			=	'';			
			
			sqlFromTable			=	" FROM sms_job_invite ";
			
			sqlSelectArray.push("SELECT sms_job_invite.*");
			sqlSelectArray.push("job.*");			
				
			sqlJoinArray.push("LEFT JOIN job ON job.id = sms_job_invite.job_id AND job.expiry_time > UNIX_TIMESTAMP() AND (job.publish_type ="+pool.escape(config.JOB.PUBLISH_TYPE.INVITE)+" ) AND job.user_role_id = "+pool.escape(config.USER.ROLE_AGENT)+" AND job.status_delete IS "+pool.escape(config.JOB.STATUS_DELETE_NO));
							
			sqlQueryWhereArray.push(" WHERE sms_job_invite.receiver_mobile_refined="+pool.escape(mobile));
			
			sqlGroupByArray.push(" GROUP BY sms_job_invite.job_L0_id ");
			
			sqlSelect		=	sqlSelectArray.join(', ');
			sqlJoin			=	sqlJoinArray.join(' ');
			sqlQueryWhere	=	sqlQueryWhereArray.join(' AND ');
			sqlGroupBy		=	sqlGroupByArray.join(' ');
			
			//var sqlQuery	=	sqlSelect + sqlFromTable + sqlJoin + sqlQueryWhere + sqlOrderBy;		
			var sqlQuery	=	sqlSelect + sqlFromTable + sqlJoin + sqlQueryWhere + sqlGroupBy + sqlOrderBy;		
				
			console.log('sqlQuery = '+sqlQuery);
			
			pool.getConnection(function(error, connection) {									
				// Use the database connection

				var options = {sql: sqlQuery, nestTables: '_'};
				connection.query(options, function (error, results, fields) {
					
				// And done with the database connection.
					connection.release();

					if (error) { 
						throw error; 
					} else {
						if(!results) {
							return callback(null, null);
						} else {
							return callback(null, results);
						}			
						return callback(null, null);
					}

					// Don't use the connection here, it has been returned to the pool.
				});
			});
		},  
		//=================================================================
		/* 
		Function to create job invites data.
		*/
		createJobInviteData: function (data, callback) {
			
			console.log('createJobInviteData');	
			console.log(data);	
			console.log(data.length);

			var user_id 			= 	AuthenticUser.id;
			var mobile	 			= 	AuthenticUser.mobile;
			
			
			// for (var sms_job_invite in data) {
				// var a = data[sms_job_invite];
				// console.log('sms_job_invite = '+data[sms_job_invite].sms_job_invite_receiver_mobile_refined);
			// }
			
			for (var i = 0; i < data.length; i++) {
				
				/*
				sms_job_invite_id: 6,
				sms_job_invite_job_id: 6,
				sms_job_invite_job_L0_id: 6,
				sms_job_invite_sender_user_id: 2,
				sms_job_invite_receiver_user_id: null,
				sms_job_invite_receiver_mobile_original: '1234500127',
				sms_job_invite_receiver_mobile_refined: 441234500127,
				sms_job_invite_reminder_0_time: 1516694100,
				sms_job_invite_reminder_1_time: 1516953300,
				sms_job_invite_reminder_2_time: 1517298900,
				sms_job_invite_reminder_0_action_time: null,
				sms_job_invite_reminder_1_action_time: null,
				sms_job_invite_reminder_2_action_time: null,
				sms_job_invite_sid: null,
				sms_job_invite_body: null,
				sms_job_invite_status: null,
				sms_job_invite_errorCode: null,
				sms_job_invite_errorMessage: null,
				
				job_id: 6,
				job_reference_number: 'JT-817571DF26',
				job_job_share_level: 0,
				job_job_copy_id: null,
				job_job_L0_id: null,
				job_job_L0_reference_number: null,
				job_job_type: 1,
				job_user_role_id: 3,
				job_created_by: 2,
				job_updated_by: null,
				job_created_at: 1516694099,
				job_updated_at: null,
				job_project_id: 1,
				job_industry_sector_id: 1,
				job_sub_industry_sector_id: null,
				job_sector_role_id: 2,
				job_hiring_manager_name: 'evelyn taylor',
				job_hiring_manager_email: 'hm1@gmail.com',
				job_hiring_manager_mobile: '1234567890123456',
				job_start_date: 1517443200,
				job_end_date: 1522454400,
				job_expiry_time_dropdown: 72,
				job_expiry_time: 1516953299,
				job_title: 'job title',
				job_contract_duration: 4,
				job_duration_type_id: 4,
				job_rate: 1,
				job_currency_id: 1,
				job_rate_type_id: 2,
				job_description: 'Job description text',
				job_attachment: null,
				job_invite_message: 'invite message',
				job_status_authentic: 1,
				job_publish_type: 1,
				job_status: 2,
				job_status_job_broadcast_by_admin: null,
				job_status_cronjob_job_invite_to_broadcast_convert_notification: null,
				job_status_delete: null,
				job_job_copy_share_level: null
				*/

				var sms_job_invite 							= 	data[i];
				
				var sms_job_invite_id						=	sms_job_invite.sms_job_invite_id;
				var invite_from								=	sms_job_invite.sms_job_invite_sender_user_id;
				var sms_job_invite_receiver_mobile_refined	=	sms_job_invite.sms_job_invite_receiver_mobile_refined;
				var job_id									=	sms_job_invite.job_id;
				var project_id								=	sms_job_invite.job_project_id;
				var invite_to								=	user_id;
				
				console.log('\n');
				console.log('sms_job_invite_id = '+sms_job_invite_id);
				console.log('sms_job_invite_sender_user_id = '+sms_job_invite_sender_user_id);
				console.log('sms_job_invite_receiver_mobile_refined = '+sms_job_invite_receiver_mobile_refined);
				console.log('job_id = '+job_id);
				console.log('job_project_id = '+job_project_id);
				
			}

			
			
			return callback(null, null);		
		},
		//=================================================================
		//=================================================================
		//=================================================================
		//=================================================================
		//=================================================================
	};
	
	module.exports = SmsJobInviteModel;
	