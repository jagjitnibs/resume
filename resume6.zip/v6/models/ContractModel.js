	var ContractModel = {  
		
		/*	
		getContractorPlacedByUserId: function(callback) {
			
			//console.log('getContractsPlacedByUserId');			
			var user_id 			= 	AuthenticUser.id;
			//console.log('user_id = '+user_id);			
				
			if((typeof user_id !== 'undefined' && user_id !== null && user_id>0)) {
				
				var sqlSelectArray 		= 	[];			
				var sqlJoinArray 		= 	[];
				var sqlGroupByArray 	= 	[];
				var sqlQueryWhereArray 	= 	[];
				
				var sqlSelect		 	= 	'';
				var sqlFromTable		= 	'';
				var sqlJoin		 		= 	'';			
				var sqlQueryWhere		=	'';
				var sqlGroupBy			=	'';
				var sqlOrderBy			=	'';

				sqlFromTable			=	" FROM contract_commission_share_holder ";
				
				sqlSelectArray.push("SELECT COUNT(contract_commission_share_holder.id) AS total");
				
				sqlQueryWhereArray.push(" WHERE contract_commission_share_holder.agent_id = "+pool.escape(user_id));
									
				sqlQueryWhere 	= 	sqlQueryWhereArray.join(' AND ');						
				sqlSelect		=	sqlSelectArray.join(', ');			
				sqlJoin			=	sqlJoinArray.join(' ');			
				sqlQueryWhere	=	sqlQueryWhereArray.join(' AND ');
				sqlGroupBy		=	sqlGroupByArray.join(' ');

				var sqlQuery	=	sqlSelect + sqlFromTable + sqlJoin + sqlQueryWhere + sqlGroupBy + sqlOrderBy;		
				
				//console.log('--------------------------------');
				//console.log('sqlQuery = '+sqlQuery);
							
				pool.getConnection(function(error, connection) {									
					// Use the database connection
					var options = {sql: sqlQuery, nestTables: false};
					connection.query(options, function (error, results, fields) {
					// And done with the database connection.
						connection.release();

						if (error) { 
							throw error; 
						} else {
							if(!results.length) {
								return callback(null, null);
							} else {
								//console.log(JSON.stringify(results, null, 2))
								return callback(null, results);
							}			
							return callback(null, null);
						}

						// Don't use the connection here, it has been returned to the pool.
					});
				});
				
			} else {
				return callback(null, null);
			}		 
		},
		*/
		getContractorPlacedByUserId: function(callback) {
			
			//console.log('getContractsPlacedByUserId');			
			var user_id 			= 	AuthenticUser.id;
			//console.log('user_id = '+user_id);			
				
			if((typeof user_id !== 'undefined' && user_id !== null && user_id>0)) {
				
				var sqlSelectArray 		= 	[];			
				var sqlJoinArray 		= 	[];
				var sqlGroupByArray 	= 	[];
				var sqlQueryWhereArray 	= 	[];
				
				var sqlSelect		 	= 	'';
				var sqlFromTable		= 	'';
				var sqlJoin		 		= 	'';			
				var sqlQueryWhere		=	'';
				var sqlGroupBy			=	'';
				var sqlOrderBy			=	'';
				/*
				sqlFromTable			=	" FROM contract_commission_share_holder ";
				
				sqlSelectArray.push("SELECT COUNT(contract_commission_share_holder.id) AS total");
				
				sqlQueryWhereArray.push(" WHERE contract_commission_share_holder.agent_id = "+pool.escape(user_id));
				*/
				
				sqlFromTable			=	" FROM contract ";
				
				sqlSelectArray.push("SELECT COUNT(contract.id) AS total");
				
				
				//sqlQueryWhereArray.push(" WHERE contract.id IN (SELECT GROUP_CONCAT(contract_commission_share_holder.contract_id) FROM contract_commission_share_holder WHERE contract_commission_share_holder.agent_id = "+pool.escape(user_id)+")");
				
				// Use this 'WHERE' condition.
				sqlQueryWhereArray.push(" WHERE contract.id IN (SELECT contract_commission_share_holder.contract_id FROM contract_commission_share_holder WHERE contract_commission_share_holder.agent_id = "+pool.escape(user_id)+")");
				
				sqlQueryWhereArray.push("contract.status = "+pool.escape(config.CONTRACT.STATUS_ADMIN_SIGNED));		
				
				
				sqlQueryWhere 	= 	sqlQueryWhereArray.join(' AND ');						
				sqlSelect		=	sqlSelectArray.join(', ');			
				sqlJoin			=	sqlJoinArray.join(' ');			
				sqlQueryWhere	=	sqlQueryWhereArray.join(' AND ');
				sqlGroupBy		=	sqlGroupByArray.join(' ');

				var sqlQuery	=	sqlSelect + sqlFromTable + sqlJoin + sqlQueryWhere + sqlGroupBy + sqlOrderBy;		
				
				//console.log('--------------------------------');
				//console.log('sqlQuery = '+sqlQuery);
							
				pool.getConnection(function(error, connection) {									
					// Use the database connection
					var options = {sql: sqlQuery, nestTables: false};
					connection.query(options, function (error, results, fields) {
					// And done with the database connection.
						connection.release();

						if (error) { 
							throw error; 
						} else {
							if(!results.length) {
								return callback(null, null);
							} else {
								//console.log(JSON.stringify(results, null, 2))
								return callback(null, results);
							}			
							return callback(null, null);
						}

						// Don't use the connection here, it has been returned to the pool.
					});
				});
				
			} else {
				return callback(null, null);
			}		 
		},	
	
	
	};	
	
	module.exports = ContractModel;  


