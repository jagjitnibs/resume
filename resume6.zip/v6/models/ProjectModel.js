	var ProjectModel	=	{  
		 
		
		/* 
		Function to create new project.
		*/
		createProject: function(user, postData, callback) {
			
			var user_id 				=	user.id;
			var user_role_id 			=	user.role;
				
			var title					=	postData.title;	
			var location				=	postData.location;	
			var latitude				=	postData.latitude;	
			var longitude				=	postData.longitude;	
			var organistion				=	postData.organistion;	
			
			var sqlQueryInsertColumnArray	= 	[];			
			var sqlQueryWhereArray 			= 	[];			
			var sqlQueryUpdateTable		 	= 	'';
			var sqlQueryUpdateColumn		= 	'';
			var sqlQueryWhere				=	'';
			var sqlQuery					=	'';
			
			sqlQueryInsertTable				=	" INSERT INTO project SET ";
			
			sqlQueryInsertColumnArray.push("project.user_role_id = "+user_role_id);
			sqlQueryInsertColumnArray.push("project.created_by = "+pool.escape(user_id));
			sqlQueryInsertColumnArray.push("project.status = "+config.PROJECT.STATUS.ACTIVE);
			
			sqlQueryInsertColumnArray.push("project.title = "+pool.escape(title));
			sqlQueryInsertColumnArray.push("project.location = "+pool.escape(location));
			sqlQueryInsertColumnArray.push("project.latitude = "+pool.escape(latitude));
			sqlQueryInsertColumnArray.push("project.longitude = "+pool.escape(longitude));
			sqlQueryInsertColumnArray.push("project.organistion = "+pool.escape(organistion));
			
			sqlQueryInsertColumnArray.push("project.created_at = UNIX_TIMESTAMP()");
			
			sqlQueryInsertColumn		=	sqlQueryInsertColumnArray.join(', ');			
			sqlQueryWhere				=	sqlQueryWhereArray.join(' AND ');		
			sqlQuery					=	sqlQueryInsertTable + sqlQueryInsertColumn;
			
			//console.log('sqlQuery = '+sqlQuery);
			
			pool.getConnection(function(error, connection) {									
				// Use the database connection
				connection.query(sqlQuery, function (error, results, fields) {
				// And done with the database connection.
					connection.release();

					if (error) { 
						throw error; 
					} else {
						
						if(!results) {
							return callback(null, null);
						} else {						
							
							var project_id = results.insertId;
							
							ProjectModel.getProjectById(project_id, function(error, results) {
								
								if (error) {    
									throw error;
								} else {
									if(!results) {
										return callback(null, null);
									} else {
										return callback(null, results);
									}
								}								
							});
						}
					}
					// Don't use the connection here, it has been returned to the pool.
				});
			});
		},

		/* 
		Function to get project details by id.
		*/
		getProjectById: function(project_id, callback) {
			
			var sqlSelectArray 		= 	[];			
			var sqlJoinArray 		= 	[];
			var sqlQueryWhereArray 	= 	[];
			
			var sqlSelect		 	= 	'';
			var sqlFromTable		= 	'';
			var sqlJoin		 		= 	'';			
			var sqlQueryWhere		=	'';
			var sqlOrderBy			=	'';
			
			sqlFromTable			=	" FROM project ";
			sqlOrderBy				=	" ORDER BY project.id DESC ";
			
			sqlSelectArray.push(" SELECT  project.id, project.created_at, project.updated_at, project.title, project.organistion, project.company_id, project.location, project.latitude, project.longitude, project.start_date, project.end_date, project.status ");	
			
			sqlQueryWhereArray.push(" WHERE project.id = "+pool.escape(project_id));
			sqlQueryWhereArray.push(" project.status = "+config.PROJECT.STATUS.ACTIVE);
			
			sqlSelect		=	sqlSelectArray.join(', ');			
			sqlJoin			=	sqlJoinArray.join(' ');			
			sqlQueryWhere	=	sqlQueryWhereArray.join(' AND ');	
			
			var sqlQuery	=	sqlSelect + sqlFromTable + sqlJoin + sqlQueryWhere + sqlOrderBy;		
			
			//console.log('sqlQuery = '+sqlQuery);
				
			pool.getConnection(function(error, connection) {									
				// Use the database connection
				var options = {sql: sqlQuery, nestTables: true};
				connection.query(options, function (error, results, fields) {
				// And done with the database connection.
					connection.release();

					if (error) { 
						throw error; 
					} else {

						if(!results) {
							return callback(null, null);
						} else {
							return callback(null, results);
						}			
						return callback(null, null);
					}
					// Don't use the connection here, it has been returned to the pool.
				});
			});
		},
		
		
		/* 
		Function to get list of projects by user ID
		*/
		getProjectByUserId: function(user_id, callback) {
			
			var sqlSelectArray 		= 	[];			
			var sqlJoinArray 		= 	[];
			var sqlQueryWhereArray 	= 	[];
			
			var sqlSelect		 	= 	'';
			var sqlFromTable		= 	'';
			var sqlJoin		 		= 	'';			
			var sqlQueryWhere		=	'';
			var sqlOrderBy			=	'';
			
			sqlFromTable			=	" FROM project ";
			sqlOrderBy				=	" ORDER BY project.id DESC ";
			
			sqlSelectArray.push(" SELECT  project.id, project.created_at, project.updated_at, project.title, project.organistion, project.company_id, project.location, project.latitude, project.longitude, project.start_date, project.end_date, project.status ");	
			
			//sqlSelectArray.push("job.*");
			//sqlSelectArray.push("currency.title AS currency_title");
			//sqlSelectArray.push("rate_type.title AS rate_type_title");
			//sqlSelectArray.push("duration_type.title AS duration_type_title");						
			
			//sqlJoinArray.push("LEFT JOIN job ON job.project_id = project.id");
			//sqlJoinArray.push("LEFT JOIN currency ON job.currency_id = currency.id");
			//sqlJoinArray.push("LEFT JOIN rate_type ON job.rate_type_id = rate_type.id");
			//sqlJoinArray.push("LEFT JOIN duration_type ON job.duration_type_id = duration_type.id");
			
			sqlQueryWhereArray.push(" WHERE project.created_by = "+pool.escape(user_id));
			sqlQueryWhereArray.push(" project.status = "+config.PROJECT.STATUS.ACTIVE);
			//sqlQueryWhereArray.push("job.id > "+pool.escape(job_id));
			//sqlQueryWhereArray.push("job.job_share_level > "+pool.escape(config.JOB.JOB_SHARE_LEVEL_0));
			//sqlQueryWhereArray.push("job.publish_type = "+pool.escape(config.JOB.PUBLISH_TYPE.INVITE));
			//sqlQueryWhereArray.push("job.user_role_id = "+pool.escape(config.USER.ROLE_AGENT));
			
			sqlSelect		=	sqlSelectArray.join(', ');			
			sqlJoin			=	sqlJoinArray.join(' ');			
			sqlQueryWhere	=	sqlQueryWhereArray.join(' AND ');	
			
			var sqlQuery	=	sqlSelect + sqlFromTable + sqlJoin + sqlQueryWhere + sqlOrderBy;		
			
			//console.log('sqlQuery = '+sqlQuery);
				
			pool.getConnection(function(error, connection) {									
				// Use the database connection
				var options = {sql: sqlQuery, nestTables: true};
				connection.query(options, function (error, results, fields) {
				// And done with the database connection.
					connection.release();

					if (error) { 
						throw error; 
					} else {

						if(!results) {
							return callback(null, null);
						} else {
							return callback(null, results);
						}			
						return callback(null, null);
					}

					// Don't use the connection here, it has been returned to the pool.
				});
			});
		},
		
		/* 
		Function to get list of projects by job filter.
		*/
		getProjectByJobFilter: function(job_filter, callback) {
			
			//console.log('getProjectByJobFilter');
			
			var user_id				=	job_filter[0]['user_id'];
			var industry_sector_id	=	job_filter[0]['industry_sector_id'];
			var job_type			=	job_filter[0]['job_type'];
			var keyword				=	job_filter[0]['keyword'];
			var rate_min			=	job_filter[0]['rate_min'];
			var rate_max			=	job_filter[0]['rate_max'];
			var location			=	job_filter[0]['location'];
			var latitude			=	job_filter[0]['latitude'];
			var longitude			=	job_filter[0]['longitude'];			
			var distance			=	job_filter[0]['distance'];
			var filter_invite_jobs	=	job_filter[0]['filter_invite_jobs'];
			
			var project_ids 		= 	[];
				
			if ((typeof location !== 'undefined' && location !== null && location.length>0) && (typeof latitude !== 'undefined' && latitude !== null && latitude!==0) && (typeof longitude !== 'undefined' && longitude !== null && longitude!==0)) {
				
				var sqlQuery	=	 "SELECT id, ( 3959 * acos( cos( radians("+dbConnection.escape(latitude)+") ) * cos( radians( project.latitude ) ) * cos( radians( project.longitude ) - radians("+dbConnection.escape(longitude)+") ) + sin( radians("+dbConnection.escape(latitude)+") ) * sin( radians( project.latitude ) ) ) ) AS distance FROM project HAVING distance < "+dbConnection.escape(distance)+" ORDER BY distance"; 
				
				//console.log('sqlQuery = '+sqlQuery);
				
				pool.getConnection(function(error, connection) {									
					// Use the database connection
					var options = {sql: sqlQuery, nestTables: true};
					connection.query(options, function (error, results, fields) {
					// And done with the database connection.
						connection.release();

						if (error) { 
							throw error; 
						} else {
							if(!results.length) {
								return callback(null, null);
							} else {							
								for (var i=0;i<results.length;i++) {
									project_ids.push(results[i].id);							
								}
								return callback(null, project_ids);
							}			
							return callback(null, null);
						}

						// Don't use the connection here, it has been returned to the pool.
					});
				});
			
			} else {
				return callback(null, null);
			}		 
		},	  
	
	
	};	
	module.exports = ProjectModel;