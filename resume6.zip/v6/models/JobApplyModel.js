	var JobApplyModel	=	{
		
		//=================================================================
		/* 
		Function to get list of applied jobs by user id.
		*/
		getJobApplyByUserIdNewApi: function (user_id, offset, callback) {
			//console.log('getJobApplyByUserIdNewApi');
			
			if (typeof offset === 'undefined' || offset === null || parseInt(offset)<=0) {
				offset	=	0;
			} else {
				offset = parseInt(offset);
			}
			
			var sqlSelectArray 		= 	[];			
			var sqlJoinArray 		= 	[];
			var sqlQueryWhereArray 	= 	[];
			
			var sqlSelect		 	= 	'';
			var sqlFromTable		= 	'';
			var sqlJoin		 		= 	'';			
			var sqlQueryWhere		=	'';
			var sqlOrderBy			=	'';	
			var sqlLimit			=	' LIMIT '+config.params.SQL_LIMIT_JOB;
			var sqlOffset			=	' OFFSET '+offset;			
			
			sqlFromTable			=	" FROM job_apply ";
			sqlOrderBy				=	" ORDER BY job_apply.id DESC ";
			
			sqlSelectArray.push("SELECT job_apply.id, job_apply.job_id,job_apply.status_cv,job_apply.cv_forward_date");
			sqlSelectArray.push("job.id, job.job_type, job.job_share_level, job.reference_number, job.job_L0_reference_number, job.title, job.rate, job.contract_duration, job.duration_type_id, job.description, job.start_date");					
			sqlSelectArray.push("currency.title, currency.symbol");	
			sqlSelectArray.push("rate_type.title");			
			sqlSelectArray.push("duration_type.title");			
			sqlSelectArray.push("project.location");
			sqlSelectArray.push("contract.id, contract.status");
			
			//sqlSelectArray.push('(CASE WHEN job_apply.status_cv = '+config.JOB_APPLY.STATUS_CV_SUBMITTED_TO_HIRING_MANAGER+' then "'+config.apiResponseMessage.JOB_APPLY.SENT_TO_HR+'" WHEN job_apply.cv_forward_date >0  then "'+config.apiResponseMessage.JOB_APPLY.SENT_TO_AVOKO+'"   ELSE "'+config.apiResponseMessage.JOB_APPLY.CV_APPLY+'" END) as CV_STATUS_TITLE ');
			
			// Date :: April-17-2018
			//sqlSelectArray.push('(CASE WHEN job_apply.status_cv = '+config.JOB_APPLY.STATUS_CV_SUBMITTED_TO_HIRING_MANAGER+' then "'+config.apiResponseMessage.JOB_APPLY.SENT_TO_HR+'" WHEN (job_apply.cv_forward_date >0 OR job_apply.status_cv = '+config.JOB_APPLY.STATUS_CV_SENT_TO_EXPERT+' OR job_apply.status_cv = '+config.JOB_APPLY.STATUS_CV_REJECTED_BY_EXPERT+' OR job_apply.status_cv = '+config.JOB_APPLY.STATUS_CV_ACCEPTED_BY_EXPERT+')  then "'+config.apiResponseMessage.JOB_APPLY.SENT_TO_AVOKO+'"   ELSE "'+config.apiResponseMessage.JOB_APPLY.CV_APPLY+'" END) as CV_STATUS_TITLE ');
			sqlSelectArray.push('(CASE WHEN contract.status = '+config.CONTRACT.STATUS_ADMIN_SIGNED+' then "'+config.apiResponseMessage.CONTRACT[101]+'" WHEN job_apply.status_cv = '+config.JOB_APPLY.STATUS_CV_SUBMITTED_TO_HIRING_MANAGER+' then "'+config.apiResponseMessage.JOB_APPLY.SENT_TO_HR+'" WHEN (job_apply.cv_forward_date >0 OR job_apply.status_cv = '+config.JOB_APPLY.STATUS_CV_SENT_TO_EXPERT+' OR job_apply.status_cv = '+config.JOB_APPLY.STATUS_CV_REJECTED_BY_EXPERT+' OR job_apply.status_cv = '+config.JOB_APPLY.STATUS_CV_ACCEPTED_BY_EXPERT+')  then "'+config.apiResponseMessage.JOB_APPLY.SENT_TO_AVOKO+'"   ELSE "'+config.apiResponseMessage.JOB_APPLY.CV_APPLY+'" END) as CV_STATUS_TITLE ');
			
			sqlJoinArray.push("LEFT JOIN job ON job.id = job_apply.job_id");
			sqlJoinArray.push("LEFT JOIN currency ON currency.id = job.currency_id");
			sqlJoinArray.push("LEFT JOIN rate_type ON rate_type.id = job.rate_type_id");
			sqlJoinArray.push("LEFT JOIN duration_type ON duration_type.id = job.duration_type_id");
			sqlJoinArray.push("LEFT JOIN project ON project.id = job.project_id");
			sqlJoinArray.push("LEFT JOIN contract ON contract.job_id = job_apply.job_L0_id AND contract.contractor_id = job_apply.user_id AND contract.status="+config.CONTRACT.STATUS_ADMIN_SIGNED);
				
			sqlQueryWhereArray.push(" WHERE job_apply.id IN (SELECT max(job_apply.id) FROM job_apply WHERE job_apply.user_id="+pool.escape(user_id)+" AND job_apply.status_delete = "+config.JOB_APPLY.STATUS_DELETE_NO+" AND job_apply.status_hide_by_applicant = "+config.JOB_APPLY.STATUS_HIDE_BY_APPLICANT_NO+" GROUP BY job_L0_id)");
			
			//sqlQueryWhereArray.push(" WHERE job_apply.user_id="+pool.escape(user_id));
			//sqlQueryWhereArray.push("job_apply.status_cv_direct_receive = "+config.JOB_APPLY.STATUS_CV_DIRECT_RECEIVE_YES);
			//sqlQueryWhereArray.push("job_apply.status_delete = "+config.JOB_APPLY.STATUS_DELETE_NO);
			//sqlQueryWhereArray.push("job_apply.status_hide_by_applicant = "+config.JOB_APPLY.STATUS_HIDE_BY_APPLICANT_NO);
						
			sqlSelect		=	sqlSelectArray.join(', ');			
			sqlJoin			=	sqlJoinArray.join(' ');			
			sqlQueryWhere	=	sqlQueryWhereArray.join(' AND ');				
			var sqlQuery	=	sqlSelect + sqlFromTable + sqlJoin + sqlQueryWhere + sqlOrderBy + sqlLimit + sqlOffset;					
			
			console.log('sqlQuery = '+sqlQuery);			
			
			pool.getConnection(function(error, connection) {									
				// Use the database connection

				var options = {sql: sqlQuery, nestTables: '_'};
				connection.query(options, function (error, results, fields) {
					
					// And done with the database connection.
					connection.release();

					if (error) { 
						throw error; 
					} else {

						if(!results) {
							return callback(null, null);
						} else {
							return callback(null, results);
						}			
						return callback(null, null);
					}

					// Don't use the connection here, it has been returned to the pool.
				});
			});
		},
		
		
		
		//=================================================================
		/* 
		Function to get list of applied jobs by user id.
		*/
		
		/*
		// Commented on May-07-2018
		
		getJobApplyByUserId: function (user_id, offset, callback) {
			//console.log('getJobApplyByUserIdNewApi');
			
			if (typeof offset === 'undefined' || offset === null || parseInt(offset)<=0) {
				offset	=	0;
			} else {
				offset = parseInt(offset);
			}
			
			var sqlSelectArray 		= 	[];			
			var sqlJoinArray 		= 	[];
			var sqlQueryWhereArray 	= 	[];
			
			var sqlSelect		 	= 	'';
			var sqlFromTable		= 	'';
			var sqlJoin		 		= 	'';			
			var sqlQueryWhere		=	'';
			var sqlOrderBy			=	'';	
			var sqlLimit			=	' LIMIT '+config.params.SQL_LIMIT_JOB;
			var sqlOffset			=	' OFFSET '+offset;			
			
			sqlFromTable			=	" FROM job_apply ";
			sqlOrderBy				=	" ORDER BY job_apply.id DESC ";
			
			sqlSelectArray.push("SELECT job_apply.id, job_apply.job_id,job_apply.status_cv,job_apply.cv_forward_date");
			sqlSelectArray.push("job.id, job.job_type, job.job_share_level, job.reference_number, job.job_L0_reference_number, job.title, job.rate, job.contract_duration, job.duration_type_id, job.description, job.start_date");					
			sqlSelectArray.push("currency.title, currency.symbol");	
			sqlSelectArray.push("rate_type.title");			
			sqlSelectArray.push("duration_type.title");			
			sqlSelectArray.push("project.location");
			
			sqlSelectArray.push('(CASE WHEN job_apply.status_cv = '+config.JOB_APPLY.STATUS_CV_SUBMITTED_TO_HIRING_MANAGER+' then "'+config.apiResponseMessage.JOB_APPLY.SENT_TO_HR+'" WHEN job_apply.cv_forward_date >0  then "'+config.apiResponseMessage.JOB_APPLY.SENT_TO_AVOKO+'"   ELSE "'+config.apiResponseMessage.JOB_APPLY.CV_APPLY+'" END) as CV_STATUS_TITLE ');
			
			// Date :: April-17-2018
			//sqlSelectArray.push('(CASE WHEN job_apply.status_cv = '+config.JOB_APPLY.STATUS_CV_SUBMITTED_TO_HIRING_MANAGER+' then "'+config.apiResponseMessage.JOB_APPLY.SENT_TO_HR+'" WHEN (job_apply.status_cv = '+config.JOB_APPLY.STATUS_CV_SENT_TO_EXPERT+' OR job_apply.status_cv = '+config.JOB_APPLY.STATUS_CV_REJECTED_BY_EXPERT+' OR job_apply.status_cv = '+config.JOB_APPLY.STATUS_CV_ACCEPTED_BY_EXPERT+')  then "'+config.apiResponseMessage.JOB_APPLY.SENT_TO_AVOKO+'"   ELSE "'+config.apiResponseMessage.JOB_APPLY.CV_APPLY+'" END) as CV_STATUS_TITLE ');
			
			sqlJoinArray.push("LEFT JOIN job ON job.id = job_apply.job_id");
			sqlJoinArray.push("LEFT JOIN currency ON currency.id = job.currency_id");
			sqlJoinArray.push("LEFT JOIN rate_type ON rate_type.id = job.rate_type_id");
			sqlJoinArray.push("LEFT JOIN duration_type ON duration_type.id = job.duration_type_id");
			sqlJoinArray.push("LEFT JOIN project ON project.id = job.project_id");
				
			sqlQueryWhereArray.push(" WHERE job_apply.user_id="+pool.escape(user_id));
			sqlQueryWhereArray.push("job_apply.status_cv_direct_receive = "+config.JOB_APPLY.STATUS_CV_DIRECT_RECEIVE_YES);
			sqlQueryWhereArray.push("job_apply.status_delete = "+config.JOB_APPLY.STATUS_DELETE_NO);
			sqlQueryWhereArray.push("job_apply.status_hide_by_applicant = "+config.JOB_APPLY.STATUS_HIDE_BY_APPLICANT_NO);
			
			sqlSelect		=	sqlSelectArray.join(', ');			
			sqlJoin			=	sqlJoinArray.join(' ');			
			sqlQueryWhere	=	sqlQueryWhereArray.join(' AND ');				
			var sqlQuery	=	sqlSelect + sqlFromTable + sqlJoin + sqlQueryWhere + sqlOrderBy + sqlLimit + sqlOffset;					
			
			console.log('sqlQuery = '+sqlQuery);			
			
			pool.getConnection(function(error, connection) {									
				// Use the database connection

				var options = {sql: sqlQuery, nestTables: '_'};
				connection.query(options, function (error, results, fields) {
					
					// And done with the database connection.
					connection.release();

					if (error) { 
						throw error; 
					} else {

						if(!results) {
							return callback(null, null);
						} else {
							return callback(null, results);
						}			
						return callback(null, null);
					}

					// Don't use the connection here, it has been returned to the pool.
				});
			});
		},
		*/	
		//=================================================================
		/* 
		Function to update the status of credit entries as PAYMENT REQUEST SENT by ids.
		*/
		setStatusCvViewByAgent: function(jobApplyData, callback) {
						
			var user_id 			= 	AuthenticUser.id;
			var id 					=	parseInt(jobApplyData.id);
			var job_id 				=	parseInt(jobApplyData.job_id);
			
			if((typeof user_id !== 'undefined' && user_id !== null && user_id>0)) {
				
				var sqlQueryUpdateColumnArray	= 	[];			
				var sqlQueryWhereArray 			= 	[];			
				var sqlQueryUpdateTable		 	= 	'';
				var sqlQueryUpdateColumn		= 	'';
				var sqlQueryWhere				=	'';
				var sqlQuery					=	'';											
											
				sqlQueryUpdateTable				=	" UPDATE job_apply SET ";
							
				sqlQueryUpdateColumnArray.push("job_apply.status_cv_view_by_agent = "+pool.escape(config.JOB_APPLY.STATUS_CV_VIEW_BY_AGENT_YES));
				
								
				sqlQueryWhereArray.push(" WHERE job_apply.id = "+pool.escape(id));		
				sqlQueryWhereArray.push("job_apply.job_id = "+pool.escape(job_id));		
				sqlQueryWhereArray.push("job_apply.status_cv_direct_receive = "+pool.escape(config.JOB_APPLY.STATUS_CV_DIRECT_RECEIVE_YES));
								
				
				sqlQueryUpdateColumn		=	sqlQueryUpdateColumnArray.join(', ');			
				sqlQueryWhere				=	sqlQueryWhereArray.join(' AND ');		
				sqlQuery					=	sqlQueryUpdateTable + sqlQueryUpdateColumn + sqlQueryWhere;
				
				//console.log('sqlQuery = '+sqlQuery);
							
				pool.getConnection(function(error, connection) {									
					// Use the database connection
					connection.query(sqlQuery, function (error, results, fields) {
					// And done with the database connection.
						connection.release();

						if (error) { 
							throw error; 
						} else {							
							if(!results) {
								return callback(null, null);
							} else {
								//console.log(results);								
								//return callback(null, results.affectedRows);
								//return callback(null, results.changedRows);
								return callback(null, results);
							}			
							//return callback(null, null);
						}

						// Don't use the connection here, it has been returned to the pool.
					});
				});
			}	
			else {
				return callback(null, null);
			}		
		},
		//=================================================================
		/* 
		Function to update the status of credit entries as PAYMENT REQUEST SENT by ids.
		*/
		setStatusHideByApplicant: function(jobApplyData, callback) {
						
			var user_id 			= 	AuthenticUser.id;
			var id 					=	parseInt(jobApplyData.id);
			var job_id 				=	parseInt(jobApplyData.job_id);
			
			if((typeof user_id !== 'undefined' && user_id !== null && user_id>0)) {
				
				var sqlQueryUpdateColumnArray	= 	[];			
				var sqlQueryWhereArray 			= 	[];			
				var sqlQueryUpdateTable		 	= 	'';
				var sqlQueryUpdateColumn		= 	'';
				var sqlQueryWhere				=	'';
				var sqlQuery					=	'';											
											
				sqlQueryUpdateTable				=	" UPDATE job_apply SET ";
							
				sqlQueryUpdateColumnArray.push("job_apply.status_hide_by_applicant = "+pool.escape(config.JOB_APPLY.STATUS_HIDE_BY_APPLICANT_YES));
				
								
				sqlQueryWhereArray.push(" WHERE job_apply.id = "+pool.escape(id));		
				//sqlQueryWhereArray.push("job_apply.job_id = "+pool.escape(job_id));		
				sqlQueryWhereArray.push("job_apply.user_id = "+pool.escape(user_id));		
								
				
				sqlQueryUpdateColumn		=	sqlQueryUpdateColumnArray.join(', ');			
				sqlQueryWhere				=	sqlQueryWhereArray.join(' AND ');		
				sqlQuery					=	sqlQueryUpdateTable + sqlQueryUpdateColumn + sqlQueryWhere;
				
				console.log('sqlQuery = '+sqlQuery);
							
				pool.getConnection(function(error, connection) {									
					// Use the database connection
					connection.query(sqlQuery, function (error, results, fields) {
					// And done with the database connection.
						connection.release();

						if (error) { 
							throw error; 
						} else {							
							if(!results) {
								return callback(null, null);
							} else {
								//console.log(results);								
								//return callback(null, results.affectedRows);
								//return callback(null, results.changedRows);
								return callback(null, results);
							}			
							//return callback(null, null);
						}

						// Don't use the connection here, it has been returned to the pool.
					});
				});
			}	
			else {
				return callback(null, null);
			}		
		},
		//=================================================================
		/* 
		Function to get count of available broadcasted jobs by user ID
		*/
		getCountCvNotViewByAgentByUserId: function(callback) {
			
			//console.log('getCountCvNotViewByAgentByUserId');
			
			var user_id 			= 	AuthenticUser.id;
			
			if (typeof user_id === 'undefined' || user_id === null || parseInt(user_id)<=0) {
				user_id	=	0;
			} else {
				user_id = parseInt(user_id);
			}
			
			//console.log('user_id = '+ user_id);
			
			var sqlSelectArray 		= 	[];			
			var sqlJoinArray 		= 	[];
			var sqlQueryWhereArray 	= 	[];
			
			var sqlSelect		 	= 	'';
			var sqlFromTable		= 	'';
			var sqlJoin		 		= 	'';			
			var sqlQueryWhere		=	'';
			var sqlOrderBy			=	'';
			var sqlLimit			=	'';
			var sqlOffset			=	'';
			
			sqlFromTable			=	' FROM job_apply ';
			sqlOrderBy				=	'';
			
			sqlSelectArray.push("SELECT COUNT(job_apply.id) AS count_cv_review");
						
			
			
			sqlQueryWhereArray.push(" WHERE job_apply.status_cv_view_by_agent IS "+pool.escape(config.JOB_APPLY.STATUS_CV_VIEW_BY_AGENT_NO) + " AND job_apply.status_cv_direct_receive = "+pool.escape(config.JOB_APPLY.STATUS_CV_DIRECT_RECEIVE_YES));
			//sqlQueryWhereArray.push("job_apply.job_id IN ( SELECT job.id FROM job WHERE  job.job_share_level = "+pool.escape(config.JOB.JOB_SHARE_LEVEL_0)+" AND job.user_role_id = "+pool.escape(config.USER.ROLE_AGENT)+" AND  job.created_by = "+pool.escape(user_id)+" AND status_delete IS "+pool.escape(config.JOB.STATUS_DELETE.NO)+" AND expiry_time > UNIX_TIMESTAMP() )");
			sqlQueryWhereArray.push("job_apply.job_id IN ( SELECT job.id FROM job WHERE job.user_role_id = "+pool.escape(config.USER.ROLE_AGENT)+" AND  job.created_by = "+pool.escape(user_id)+" AND status_delete IS "+pool.escape(config.JOB.STATUS_DELETE.NO)+" AND expiry_time > UNIX_TIMESTAMP() )");
						
			sqlQueryWhere 	= 	sqlQueryWhereArray.join(' AND ');						
			sqlSelect		=	sqlSelectArray.join(', ');			
			sqlJoin			=	sqlJoinArray.join(' ');			
			sqlQueryWhere	=	sqlQueryWhereArray.join(' AND ');

			var sqlQuery	=	sqlSelect + sqlFromTable + sqlJoin + sqlQueryWhere + sqlOrderBy + sqlLimit + sqlOffset;		
		
			//console.log('sqlQuery = '+sqlQuery);	
		
			pool.getConnection(function(error, connection) {									
				// Use the database connection
				var options = {sql: sqlQuery, nestTables: false};
				connection.query(options, function (error, results, fields) {
				// And done with the database connection.
					connection.release();

					if (error) { 
						throw error; 
					} else {
						if(!results) {
							return callback(null, null);
						} else {
							return callback(null, results);
						}			
						return callback(null, null);
					}

					// Don't use the connection here, it has been returned to the pool.
				});
			});
				
					
		},
		//=================================================================
		/* 
		Function to get applied job ids by user ID
		*/
		getAppliedJobIds: function(callback) {
			
			//console.log('getCountCvNotViewByAgentByUserId');
			
			var user_id 			= 	AuthenticUser.id;
			
			if (typeof user_id === 'undefined' || user_id === null || parseInt(user_id)<=0) {
				user_id	=	0;
			} else {
				user_id = parseInt(user_id);
			}
			
			var applied_job_ids 		= 	[];
			
			//console.log('user_id = '+ user_id);
			
			var sqlSelectArray 		= 	[];			
			var sqlJoinArray 		= 	[];
			var sqlQueryWhereArray 	= 	[];
			
			var sqlSelect		 	= 	'';
			var sqlFromTable		= 	'';
			var sqlJoin		 		= 	'';			
			var sqlQueryWhere		=	'';
			var sqlOrderBy			=	'';
			var sqlLimit			=	'';
			var sqlOffset			=	'';
			
			sqlFromTable			=	' FROM job_apply ';
			sqlOrderBy				=	'';
			
			sqlSelectArray.push("SELECT job_apply.job_id");		
			
			sqlQueryWhereArray.push(" WHERE job_apply.user_id = "+pool.escape(user_id));
						
			sqlQueryWhere 	= 	sqlQueryWhereArray.join(' AND ');						
			sqlSelect		=	sqlSelectArray.join(', ');			
			sqlJoin			=	sqlJoinArray.join(' ');			
			sqlQueryWhere	=	sqlQueryWhereArray.join(' AND ');

			var sqlQuery	=	sqlSelect + sqlFromTable + sqlJoin + sqlQueryWhere + sqlOrderBy + sqlLimit + sqlOffset;		
		
			//console.log('sqlQuery = '+sqlQuery);	
		
			pool.getConnection(function(error, connection) {									
				// Use the database connection
				var options = {sql: sqlQuery, nestTables: false};
				connection.query(options, function (error, results, fields) {
				// And done with the database connection.
					connection.release();

					if (error) { 
						throw error; 
					} else {
						if(!results.length) {
							//return callback(null, null);
							return callback(null, []);
						} else {						
							for (var i=0;i<results.length;i++) {
								applied_job_ids.push(results[i].job_id);							
							}
							return callback(null, applied_job_ids);
						}			
						//return callback(null, null);
						return callback(null, []);
					}

					// Don't use the connection here, it has been returned to the pool.
				});
			});
				
					
		},
		//=================================================================
		/* 
		Function to get direct applied job ids by user ID
		*/
		getDirectAppliedJobIds: function(callback) {
			
			//console.log('getCountCvNotViewByAgentByUserId');
			
			var user_id 			= 	AuthenticUser.id;
			
			if (typeof user_id === 'undefined' || user_id === null || parseInt(user_id)<=0) {
				user_id	=	0;
			} else {
				user_id = parseInt(user_id);
			}
			
			var applied_job_ids 		= 	[];
			
			//console.log('user_id = '+ user_id);
			
			var sqlSelectArray 		= 	[];			
			var sqlJoinArray 		= 	[];
			var sqlQueryWhereArray 	= 	[];
			
			var sqlSelect		 	= 	'';
			var sqlFromTable		= 	'';
			var sqlJoin		 		= 	'';			
			var sqlQueryWhere		=	'';
			var sqlOrderBy			=	'';
			var sqlLimit			=	'';
			var sqlOffset			=	'';
			
			sqlFromTable			=	' FROM job_apply ';
			sqlOrderBy				=	'';
			
			sqlSelectArray.push("SELECT job_apply.job_id");		
			
			sqlQueryWhereArray.push(" WHERE job_apply.user_id = "+pool.escape(user_id));
			sqlQueryWhereArray.push(" job_apply.status_cv_direct_receive = "+pool.escape(config.JOB_APPLY.STATUS_CV_DIRECT_RECEIVE_YES));
						
			sqlQueryWhere 	= 	sqlQueryWhereArray.join(' AND ');						
			sqlSelect		=	sqlSelectArray.join(', ');			
			sqlJoin			=	sqlJoinArray.join(' ');			
			sqlQueryWhere	=	sqlQueryWhereArray.join(' AND ');

			var sqlQuery	=	sqlSelect + sqlFromTable + sqlJoin + sqlQueryWhere + sqlOrderBy + sqlLimit + sqlOffset;		
		
			//console.log('sqlQuery = '+sqlQuery);	
		
			pool.getConnection(function(error, connection) {									
				// Use the database connection
				var options = {sql: sqlQuery, nestTables: false};
				connection.query(options, function (error, results, fields) {
				// And done with the database connection.
					connection.release();

					if (error) { 
						throw error; 
					} else {
						if(!results.length) {
							//return callback(null, null);
							return callback(null, []);
						} else {						
							for (var i=0;i<results.length;i++) {
								applied_job_ids.push(results[i].job_id);							
							}
							return callback(null, applied_job_ids);
						}			
						//return callback(null, null);
						return callback(null, []);
					}

					// Don't use the connection here, it has been returned to the pool.
				});
			});
				
					
		},
		//=================================================================
		//=================================================================
		//=================================================================
		//=================================================================
  
		/*	
		newFunction: function (req, res, next) {
			return self.foo();
		}
		*/
	};
	
	module.exports = JobApplyModel;
	