	var nodeDateTime 		= 	require('node-datetime');
	var unixTimestamp		=	require('unix-timestamp');
	unixTimestamp.round 	= 	true;
	var countDaysInMonth	=	require('count-days-in-month');
	var moment 				= 	require('moment');
	
	
	// Include the public functions from 'helpers.js'
	var helpers 								= 	require('../common/components/helpers');
	
	var DebitHistoryPaymentAgentModel 			=	require('../models/DebitHistoryPaymentAgentModel');
	var TaleModel 								=	require('../models/TaleModel');
	
	var PaymentAgentModel = {  
		  
		//=================================================================
		/* 
		Function to get earning history of an agent by user ID
		*/		
		getEarningHistoryByUserId: function(year, month, callback) {
			
			//console.log('getEarningHistoryByUserId');			
			var user_id 			= 	AuthenticUser.id;
			var commission_amount_total_history	=	0;			
			//console.log('user_id = '+user_id);	
			//var start_month	=	month;
			//var end_month	=	month;
			
			//console.log('days = '+days);
			
			if((typeof user_id !== 'undefined' && user_id !== null && user_id>0)) {
				
				var start_date				=	year+'-'+month+'-01';
				
				
				PaymentAgentModel.getEarningTotalofPastByUserId(start_date, function(error, results) {  
									
					if (error) {    
						throw error;
					} else {
						if(results)	{
							
							//console.log(results);
							//console.log(results[0].commission_amount_total_history);
							commission_amount_total_history	=	results[0].commission_amount_total_history;
							
							
							
							var sqlSelectArray 		= 	[];			
							var sqlJoinArray 		= 	[];
							var sqlGroupByArray 	= 	[];
							var sqlQueryWhereArray 	= 	[];
							
							var sqlSelect		 	= 	'';
							var sqlFromTable		= 	'';
							var sqlJoin		 		= 	'';
							var sqlQueryWhere		=	'';
							var sqlGroupBy			=	'';
							var sqlOrderBy			=	'';
							
							sqlFromTable			=	" FROM payment_agent ";
							sqlOrderBy				=	" ORDER BY payment_agent.timesheet_period_from ASC ";
							
							sqlSelectArray.push("SELECT payment_agent.agent_id, COUNT(payment_agent.id) AS timesheet_count, DATE_FORMAT(FROM_UNIXTIME(payment_agent.timesheet_period_from), '%Y') AS timesheet_year, DATE_FORMAT(FROM_UNIXTIME(payment_agent.timesheet_period_from), '%c') AS timesheet_month, ROUND(COALESCE(SUM(payment_agent.commission_amount),0),2) AS commission_amount_total");
							//sqlSelectArray.push("(SELECT ROUND(COALESCE(SUM(payment_agent.commission_amount),0),2) AS commission_amount_total FROM payment_agent WHERE payment_agent.agent_id = "+pool.escape(user_id)+" AND  payment_agent.debit_credit_agent = '"+config.params.DEBIT_CREDIT_C+"' AND  payment_agent.timesheet_period_from <=  UNIX_TIMESTAMP(STR_TO_DATE('"+start_date+"', '%Y-%m-%d'))) AS commission_amount_total_history  ");
							
							sqlQueryWhereArray.push(" WHERE payment_agent.agent_id = "+pool.escape(user_id));
							sqlQueryWhereArray.push(" payment_agent.debit_credit_agent = '"+config.params.DEBIT_CREDIT_C+"'");
							
							
							sqlQueryWhereArray.push(" payment_agent.timesheet_period_from >=  UNIX_TIMESTAMP(STR_TO_DATE('"+start_date+"', '%Y-%m-%d'))");
							
							sqlQueryWhereArray.push(" payment_agent.timesheet_period_to <= UNIX_TIMESTAMP(DATE_ADD(STR_TO_DATE('"+start_date+"', '%Y-%m-%d'), INTERVAL 6 MONTH))");
							
							sqlGroupByArray.push(" GROUP BY payment_agent.timesheet_period_from ");
								
							sqlQueryWhere 	= 	sqlQueryWhereArray.join(' AND ');						
							sqlSelect		=	sqlSelectArray.join(', ');			
							sqlJoin			=	sqlJoinArray.join(' ');			
							sqlQueryWhere	=	sqlQueryWhereArray.join(' AND ');
							sqlGroupBy		=	sqlGroupByArray.join(' ');

							var sqlQuery	=	sqlSelect + sqlFromTable + sqlJoin + sqlQueryWhere + sqlGroupBy + sqlOrderBy;		
							
							//console.log('==========================================');
							//console.log('sqlQuery = '+sqlQuery);
							//console.log('==========================================');
											
							pool.getConnection(function(error, connection) {									
								// Use the database connection
								var options = {sql: sqlQuery, nestTables: false};
								connection.query(options, function (error, results, fields) {
								// And done with the database connection.
									connection.release();

									if (error) { 
										throw error; 
									} else {
										if(!results) {
											return callback(null, null);
										} else {
											//console.log('1111111==========================================');
											//console.log(results.length);
											//console.log(results);
											var results				 	=	helpers.convertRewardDataToCumulativeData(commission_amount_total_history, year, month, results);
											//console.log(results);
											//console.log('11111111==========================================');
											return callback(null, results);
										}			
										
									}

									// Don't use the connection here, it has been returned to the pool.
								});
							});
							
						} else {
							return callback(null, null);
						}					
					}
				});	
					
				
				
			} else {
				return callback(null, null);
			}		 
		},	  
		//=================================================================
		
		
		//=================================================================
		/* 
		Function to get earning history forecast of an agent by user ID
		*/		
		getEarningForecastByUserId: function(year, month, callback) {
		
			
			//console.log('getEarningForecastByUserId');	
			
			var user_id 			= 	AuthenticUser.id;
			var commission_amount_total_history	=	0;			
			//console.log('user_id = '+user_id);	
			//var start_month	=	month;
			//var end_month	=	month;
			
			//console.log('days = '+days);
			
			if((typeof user_id !== 'undefined' && user_id !== null && user_id>0)) {
				
				var start_date				=	year+'-'+month+'-01';
				
				
				var sqlSelectArray 		= 	[];			
				var sqlJoinArray 		= 	[];
				var sqlGroupByArray 	= 	[];
				var sqlQueryWhereArray 	= 	[];
				
				var sqlSelect		 	= 	'';
				var sqlFromTable		= 	'';
				var sqlJoin		 		= 	'';
				var sqlQueryWhere		=	'';
				var sqlGroupBy			=	'';
				var sqlOrderBy			=	'';
				
				sqlFromTable			=	" FROM payment_agent_forecast ";
				sqlOrderBy				=	" ORDER BY payment_agent_forecast.timesheet_period_from ASC ";
				
				sqlSelectArray.push("SELECT payment_agent_forecast.agent_id, COUNT(payment_agent_forecast.id) AS timesheet_count, DATE_FORMAT(FROM_UNIXTIME(payment_agent_forecast.timesheet_period_from), '%Y') AS timesheet_year, DATE_FORMAT(FROM_UNIXTIME(payment_agent_forecast.timesheet_period_from), '%c') AS timesheet_month, ROUND(COALESCE(SUM(payment_agent_forecast.agent_commission_amount),0),2) AS commission_amount_total");
				
				sqlQueryWhereArray.push(" WHERE payment_agent_forecast.agent_id = "+pool.escape(user_id));
				sqlQueryWhereArray.push(" payment_agent_forecast.timesheet_period_from >=  UNIX_TIMESTAMP(STR_TO_DATE('"+start_date+"', '%Y-%m-%d'))");
				sqlQueryWhereArray.push(" payment_agent_forecast.timesheet_period_to <= UNIX_TIMESTAMP(DATE_ADD(STR_TO_DATE('"+start_date+"', '%Y-%m-%d'), INTERVAL 6 MONTH))");
				
				sqlGroupByArray.push(" GROUP BY payment_agent_forecast.timesheet_period_from ");
					
				sqlQueryWhere 	= 	sqlQueryWhereArray.join(' AND ');						
				sqlSelect		=	sqlSelectArray.join(', ');			
				sqlJoin			=	sqlJoinArray.join(' ');			
				sqlQueryWhere	=	sqlQueryWhereArray.join(' AND ');
				sqlGroupBy		=	sqlGroupByArray.join(' ');

				var sqlQuery	=	sqlSelect + sqlFromTable + sqlJoin + sqlQueryWhere + sqlGroupBy + sqlOrderBy;		
				
				//console.log('==========================================');
				//console.log('==========================================');
				//console.log('sqlQuery = '+sqlQuery);
				//console.log('==========================================');
				//console.log('==========================================');
								
				pool.getConnection(function(error, connection) {									
					// Use the database connection
					var options = {sql: sqlQuery, nestTables: false};
					connection.query(options, function (error, results, fields) {
					// And done with the database connection.
						connection.release();

						if (error) { 
							throw error; 
						} else {
							if(!results) {
								return callback(null, null);
							} else {
								//console.log('1111111==========================================');
								//console.log(results.length);
								//console.log(results);
								//var results				 	=	helpers.convertRewardDataToCumulativeData(year, month, results);
								
								PaymentAgentModel.processPaymentAgentForecastData(year, month, results, function(error, results) {
												
									if (error) {    
										throw error;
									} else {
										if(!results) {
											return callback(null, null);
										} else {
											if(results) {											
												return callback(null, results); 
											}											
										}
									}								
								});
																
								//console.log(results);
								//console.log('11111111==========================================');
								//return callback(null, results);
							}			
							
						}

						// Don't use the connection here, it has been returned to the pool.
					});
				});	
					
				
				
			} else {
				return callback(null, null);
			}		 
		},
		
		
		//=================================================================
		/* 
		Function to process forecast reward data step1.
		*/
		//paymentAgentForecastStep1: function(graphStartYear, graphStartMonth, callback) {		
		processPaymentAgentForecastData: function(graphStartYear, graphStartMonth, graphData, callback) {		
		
			//console.log('processPaymentAgentForecastData');
			
			var user_id 			= 	AuthenticUser.id;
			
			//console.log('convertRewardDataToCumulativeData');
			//console.log('graphStartYear = '+graphStartYear);
			//console.log('graphStartMonth = '+graphStartMonth);
			
			var firstMonthOfYear	=	1;
			var lastMonthOfYear		=	12;
			var totalMonthInYear	=	12;
			var showGarphMaxMonth	=	6;
			var yearIncrement		=	1;
			
			//console.log('.......1111111111111111111');
			//console.log(graphData);
			//console.log('.......1111111111111111111');
		
			var graphStartYear 		=  	parseInt(graphStartYear);
			var graphStartMonth		=	parseInt(graphStartMonth);
			
			var graphEndYear 		= 	graphStartYear;
			var graphEndMonth		=	graphStartMonth+showGarphMaxMonth;
			
			if(graphEndMonth > totalMonthInYear) {
				graphEndYear	=	graphStartYear+yearIncrement;
				graphEndMonth 	=	(graphEndMonth-totalMonthInYear)-1;				
			}
			
			//console.log('graphEndYear = '+graphEndYear);
			//console.log('graphEndMonth = '+graphEndMonth);
			
			var rewardCumulativeDataStep1 	= 	[];
			//var rewardCumulativeDataStep2 = 	[];
			var rewardCumulativeData 		= 	[];
			var rewardCumulativeDataFinal	=	[];
			
			var count = 0;
			
			//----------------------------------------------
			// CODE START :: STEP-1 :: CREATE BLANK ARRAY OF 6 MONTHS OF COMMISSION
			//----------------------------------------------
			if(graphStartYear == graphEndYear) {
				
				//console.log('graphStartYear = graphEndYear');
				
				for(i=graphStartMonth; i<graphStartMonth+showGarphMaxMonth; i++) {
					
					rewardCumulativeDataStep1[count] = {
						timesheet_year:   graphStartYear,
						timesheet_month: i,
						commission_amount_total: 0
					};
					count++;
				}				
				//console.log('rewardCumulativeDataStep1='+rewardCumulativeDataStep1);
				
				
			} else if (graphEndYear > graphStartYear) {
				
				//console.log('Graph data have 2 years...');
				
				for(i=graphStartMonth; i<=lastMonthOfYear; i++) {
					
					//console.log('graphStartYear - graphStartMonth - i  ='+i);
					
					rewardCumulativeDataStep1[count] = {
						timesheet_year:   graphStartYear,
						timesheet_month: i,
						commission_amount_total: 0
					};
					count++;
				}
				//console.log('rewardCumulativeDataStep1 2 ='+JSON.stringify(rewardCumulativeDataStep1));			
				//console.log('graphStartMonth ='+graphStartMonth);
				
				for(i=firstMonthOfYear; i<=graphEndMonth; i++) {
					
					//console.log('graphEndYear - graphEndMonth - i  ='+i);
					
					rewardCumulativeDataStep1[count] = {
						timesheet_year:   graphEndYear,
						timesheet_month: i,
						commission_amount_total: 0
					};
					count++;
				}
				//console.log('rewardCumulativeDataStep1 3 ='+JSON.stringify(rewardCumulativeDataStep1));
			}
			
			//----------------------------------------------
			// CODE END :: STEP-1 :: CREATE BLANK ARRAY OF 6 MONTHS OF COMMISSION
			//----------------------------------------------
			
			
			//----------------------------------------------
			// CODE START :: STEP-2 :: ASSIGN VALUES TO BLANK ARRAY OF 6 MONTHS COMMISSION
			//----------------------------------------------
			for (var i=0; i<rewardCumulativeDataStep1.length; i++) {
				
				var step1_timesheet_year 			= 	parseInt(rewardCumulativeDataStep1[i].timesheet_year);
				var step1_timesheet_month 			= 	parseInt(rewardCumulativeDataStep1[i].timesheet_month);
					
				for (var j=0; j<graphData.length; j++) {
										
					var timesheet_year 			= 	parseInt(graphData[j].timesheet_year);
					var timesheet_month 		= 	parseInt(graphData[j].timesheet_month);
					var commission_amount_total = 	parseFloat(graphData[j].commission_amount_total);
					
					if((step1_timesheet_year === timesheet_year) && (step1_timesheet_month===timesheet_month)) {
						
						rewardCumulativeDataStep1[i] = {
							commission_amount_total_history:   0,
							commission_amount:   0,
							timesheet_year:   timesheet_year,
							timesheet_month: timesheet_month,
							commission_amount_total: commission_amount_total
						};
					}										
				}				
			}
			//----------------------------------------------
			// CODE END :: STEP-2 :: ASSIGN VALUES TO BLANK ARRAY OF 6 MONTHS COMMISSION
			//----------------------------------------------
			
			
			
			
			//----------------------------------------------
			// CODE START :: STEP-3 :: CONVERT THE MONTHLY COMMISSION INTO CUMULATIVE COMMISSION.
			//----------------------------------------------
			/*
			for (var i=0; i<rewardCumulativeDataStep1.length; i++) {			
				
				if(i==0) {
					
					rewardCumulativeDataFinal[i] = {
						//commission_amount_total_history: parseFloat(commission_amount_total_history),
						commission_amount: parseFloat(rewardCumulativeDataStep1[i]['commission_amount_total']),
						timesheet_year: parseInt(rewardCumulativeDataStep1[i]['timesheet_year']),
						timesheet_month: parseInt(rewardCumulativeDataStep1[i]['timesheet_month']),
						commission_amount_total: parseFloat(rewardCumulativeDataStep1[i]['commission_amount_total'])
					};
							
				} else {
					
					var timesheet_year 			= 	rewardCumulativeDataFinal[i-1]['timesheet_year'];
					var timesheet_month 		=	rewardCumulativeDataFinal[i-1]['timesheet_month'];
					var commission_amount_total	=	rewardCumulativeDataFinal[i-1]['commission_amount_total'];					
									
					rewardCumulativeDataFinal[i] = {
						//commission_amount_total_history: parseFloat(commission_amount_total_history),
						commission_amount: parseFloat(rewardCumulativeDataStep1[i]['commission_amount_total']),
						timesheet_year: parseInt(rewardCumulativeDataStep1[i]['timesheet_year']),
						timesheet_month: parseInt(rewardCumulativeDataStep1[i]['timesheet_month']),
						commission_amount_total: parseFloat(rewardCumulativeDataStep1[i]['commission_amount_total'])+commission_amount_total
					};
				}
			}	
			*/	
			//----------------------------------------------
			// CODE END :: STEP-3 :: CONVERT THE MONTHLY COMMISSION INTO CUMULATIVE COMMISSION.
			//----------------------------------------------
			
			
			return callback(null, rewardCumulativeDataStep1);
			//return callback(null, rewardCumulativeDataFinal);
		},
		
		
		//=================================================================
		/* 
		Function to get earning history forecast of an agent by user ID
		*/		
		getEarningHistoryForecastByUserId: function(year, month, callback) {
			
			/*
			console.log('+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++');			
			console.log('+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++');			
			console.log('++++++++++++++++++++++++++++++++++++++++++');			
			console.log('++++++++++++++++++++++++++++++++++++++++++');			
			console.log('++++++++++++++++++++++++++++++++++++++++++');			
			console.log('++++++++++++++++++++++++++++++++++++++++++');			
			console.log('++++++++++++++++++++++++++++++++++++++++++');			
			console.log('getEarningHistoryForecastByUserId');	
			console.log('++++++++++++++++++++++++++++++++++++++++++');			
			console.log('++++++++++++++++++++++++++++++++++++++++++');			
			console.log('++++++++++++++++++++++++++++++++++++++++++');			
			console.log('++++++++++++++++++++++++++++++++++++++++++');	
			console.log('+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++');			
			console.log('+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++');			
			*/
			var user_id 								= 	AuthenticUser.id;	
			var payment_agent_forecast_past_months		=	0;			
			var payment_agent_forecast_future_months	=	0;			
			//console.log('user_id = '+user_id);			
				
			if((typeof user_id !== 'undefined' && user_id !== null && user_id>0)) {
				
				var start_date								=	year+'-'+month+'-01';
				var start_date								= 	moment(start_date, 'YYYY-MM-DD').format('YYYY-MM-DD'); 
				
				var cron_job_payment_agent_forecast_date	=	config.params.CRON_JOB_PAYMENT_AGENT_FORECAST_DATE;
				var today_date 								= 	moment().format('YYYY-MM-DD'); 
				var first_day_of_current_month 				= 	moment().format('YYYY-MM-01'); 
				var last_day_of_previous_month 				= 	moment(today_date).subtract(1, 'months').endOf('month').format('YYYY-MM-DD');
				
				//console.log('start_date = '+start_date);
				//console.log('today_date = '+today_date);
				//console.log('cron_job_payment_agent_forecast_date = '+cron_job_payment_agent_forecast_date);											
				//console.log('first_day_of_current_month = '+first_day_of_current_month);
				//console.log('last_day_of_previous_month = '+last_day_of_previous_month);

				var date1									= 	moment(last_day_of_previous_month, 'YYYY-MM-DD');
				var date2									=	moment(start_date, 'YYYY-MM-DD');
				//var payment_agent_forecast_past_months	=	date1.diff(date2,'months')+1;
				payment_agent_forecast_past_months			=	date1.diff(date2,'months', true);
				payment_agent_forecast_past_months			=	Math.round(payment_agent_forecast_past_months);
				
				if(payment_agent_forecast_past_months<=0){
					payment_agent_forecast_future_months	=	6;
					step2_start_date						=	start_date;	
				} else {
					payment_agent_forecast_future_months	=	6-payment_agent_forecast_past_months;
					var step2_start_date 					= 	moment(first_day_of_current_month).add(start_date, 'months').startOf('month').format('YYYY-MM-DD');
				}
				
				
				console.log('-----------------------------------------');
				console.log('----------------------------------------------------- payment_agent_forecast_past_months = '+payment_agent_forecast_past_months);
				console.log('----------------------------------------------------- payment_agent_forecast_future_months = '+payment_agent_forecast_future_months);
				console.log('----------------------------------------------------- step2_start_date = '+step2_start_date);
				console.log('-----------------------------------------');
				
				
				
				PaymentAgentModel.paymentAgentForecastStep1(start_date, payment_agent_forecast_past_months, function(error, results) {
												
					if (error) {    
						throw error;
					} else {
						if(!results) {
							return callback(null, null);
						} else {
							if(results) {
								var resultpaymentAgentForecastStep1	=	results;
								
								//console.log(results.length);
								//console.log(results);
								//console.log('+++++++++++++++++++++++++++++++++++++++++++++');
								//console.log('resultpaymentAgentForecastStep1 = '+JSON.stringify(resultpaymentAgentForecastStep1,null,2));
								//console.log('resultpaymentAgentForecastStep1.length = '+resultpaymentAgentForecastStep1.length);
								//console.log('+++++++++++++++++++++++++++++++++++++++++++++');
								
								PaymentAgentModel.paymentAgentForecastStep2(step2_start_date, payment_agent_forecast_future_months, function(error, results) {
												
									if (error) {    
										throw error;
									} else {
										if(!results) {
											return callback(null, null);
										} else {
											if(results) {
												var resultpaymentAgentForecastStep2	=	results;
												
												//console.log(results.length);
												//console.log(results);
												console.log('+++++++++++++++++++++++++++++++++++++++++++++');
												//console.log('resultpaymentAgentForecastStep2 = '+JSON.stringify(resultpaymentAgentForecastStep2,null,2));
												console.log('resultpaymentAgentForecastStep2.length = '+resultpaymentAgentForecastStep2.length);
												console.log('+++++++++++++++++++++++++++++++++++++++++++++');
												
												PaymentAgentModel.paymentAgentForecastStep3(step2_start_date, payment_agent_forecast_future_months, resultpaymentAgentForecastStep2, function(error, results, results2) {
												
													if (error) {    
														throw error;
													} else {
														if(!results) {
															return callback(null, null);
														} else {
															if(results) {
																var resultpaymentAgentForecastStep3					=	results;
																var resultPaymentAgentForecastStep3YearMonthKeyData	=	results2;
																
																//console.log(results.length);
																//console.log(results);
																console.log('+++++++++++++++++++++++++++++++++++++++++++++');
																//console.log('resultpaymentAgentForecastStep3 = '+JSON.stringify(resultpaymentAgentForecastStep3,null,2));
																console.log('resultpaymentAgentForecastStep3.length = '+resultpaymentAgentForecastStep3.length);
																console.log('+++++++++++++++++++++++++++++++++++++++++++++');
																
																PaymentAgentModel.paymentAgentForecastStep4(resultpaymentAgentForecastStep3, resultPaymentAgentForecastStep3YearMonthKeyData, function(error, results) {
												
																	if (error) {    
																		throw error;
																	} else {
																		if(!results) {
																			return callback(null, null);
																		} else {
																			if(results) {
																				var resultpaymentAgentForecastStep4	=	results;
																				
																				//console.log(results.length);
																				//console.log(results);
																				console.log('+++++++++++++++++++++++++++++++++++++++++++++');
																				//console.log('resultpaymentAgentForecastStep4 = '+JSON.stringify(resultpaymentAgentForecastStep4,null,2));
																				console.log('resultpaymentAgentForecastStep4.length = '+resultpaymentAgentForecastStep4.length);
																				console.log('+++++++++++++++++++++++++++++++++++++++++++++');

																				return callback(null, resultpaymentAgentForecastStep4); 
																			}											
																		}
																	}								
																});
																//return callback(null, resultpaymentAgentForecastStep3); 
															}											
														}
													}								
												});

												//return callback(null, resultpaymentAgentForecastStep1); 
											}											
										}
									}								
								});
								//return callback(null, resultpaymentAgentForecastStep1); 
								
							}
							
						}
					}								
				});
				
			} else {
				return callback(null, null);
			}		 
		},
		
		
		
		//=================================================================
		/* 
		Function to process forecast reward data step1.
		*/
		//paymentAgentForecastStep1: function(graphStartYear, graphStartMonth, callback) {		
		paymentAgentForecastStep1: function(start_date, monthCount, callback) {		
		
			console.log('paymentAgentForecastStep1');
			
			var user_id 				= 	AuthenticUser.id;
			monthCount					=	parseInt(monthCount);	
			
			if(monthCount>6) {
				monthCount	=	6;
			} else if(monthCount<=0) {
				monthCount	=	0;
				//return callback(null, null);
			}
			
			var sqlSelectArray 			= 	[];			
			var sqlJoinArray 			= 	[];
			var sqlGroupByArray 		= 	[];
			var sqlQueryWhereOrArray 	= 	[];
			var sqlQueryWhereArray 		= 	[];
			
			var sqlSelect		 		= 	'';
			var sqlFromTable			= 	'';
			var sqlJoin		 			= 	'';			
			var sqlQueryWhere			=	'';
			var sqlOrderBy				=	'';
			
			sqlFromTable				=	" FROM payment_agent_forecast ";
			sqlOrderBy					=	" ORDER BY payment_agent_forecast.id ASC ";
			
			sqlSelectArray.push("SELECT payment_agent_forecast.contract_id, payment_agent_forecast.timesheet_year, payment_agent_forecast.timesheet_month, payment_agent_forecast.timesheet_period_from, payment_agent_forecast.timesheet_period_to");
			sqlSelectArray.push("SUM(payment_agent_forecast.agent_commission_amount) AS AGENT_COMMISSION_AMOUNT_TOTAL");
						
			sqlQueryWhereArray.push(" WHERE payment_agent_forecast.agent_id = "+pool.escape(user_id));						
			sqlQueryWhereArray.push(" payment_agent_forecast.timesheet_period_from >= UNIX_TIMESTAMP(STR_TO_DATE("+pool.escape(start_date)+", '%Y-%m-%d'))");
			//sqlQueryWhereArray.push(" payment_agent_forecast.timesheet_period_to <= UNIX_TIMESTAMP(DATE_ADD(DATE_ADD(STR_TO_DATE("+pool.escape(start_date)+", '%Y-%m-%d'), INTERVAL 6 MONTH), INTERVAL -1 DAY))");
			sqlQueryWhereArray.push(" payment_agent_forecast.timesheet_period_to <= UNIX_TIMESTAMP(DATE_ADD(DATE_ADD(STR_TO_DATE("+pool.escape(start_date)+", '%Y-%m-%d'), INTERVAL "+monthCount+" MONTH), INTERVAL -1 DAY))");
						
			sqlGroupByArray.push(" GROUP BY payment_agent_forecast.timesheet_period_from ");
			
			sqlSelect		=	sqlSelectArray.join(', ');			
			sqlJoin			=	sqlJoinArray.join(' ');			
			sqlQueryWhere	=	sqlQueryWhereArray.join(' AND ');	
			sqlQueryWhereOr	=	sqlQueryWhereOrArray.join(' OR ');	
			sqlGroupBy		=	sqlGroupByArray.join(' ');

			var sqlQuery	=	sqlSelect + sqlFromTable + sqlJoin + sqlQueryWhere + sqlGroupBy + sqlOrderBy;		
							
			//var sqlQuery	=	sqlSelect + sqlFromTable + sqlJoin + sqlQueryWhere + sqlQueryWhereOr + sqlOrderBy;				
			
			//console.log('sqlQuery = '+sqlQuery);			
			
			pool.getConnection(function(error, connection) {									
				// Use the database connection

				var options = {sql: sqlQuery, nestTables: '_'};
				connection.query(options, function (error, results, fields) {
					
					// And done with the database connection.
					connection.release();

					if (error) { 
						throw error; 
					} else {

						if(!results) {
							return callback(null, null);
						} else {
							//console.log(results);
							return callback(null, results);
						}			
						return callback(null, null);
					}

					// Don't use the connection here, it has been returned to the pool.
				});
			});
		},
		//=================================================================
		/* 
		Function to process forecast reward data step1.
		*/
		//paymentAgentForecastStep1: function(graphStartYear, graphStartMonth, callback) {		
		paymentAgentForecastStep2: function(start_date, monthCount, callback) {		
		
			console.log('paymentAgentForecastStep2');
			
			var user_id 				= 	AuthenticUser.id;
			monthCount					=	parseInt(monthCount);	
			
			if(monthCount>6) {
				monthCount	=	6;
			} else if(monthCount<=0) {
				monthCount	=	0;
				//return callback(null, null);
			}
			
			var sqlSelectArray 			= 	[];			
			var sqlJoinArray 			= 	[];
			var sqlQueryWhereOrArray 	= 	[];
			var sqlQueryWhereArray 		= 	[];
			
			var sqlSelect		 		= 	'';
			var sqlFromTable			= 	'';
			var sqlJoin		 			= 	'';			
			var sqlQueryWhere			=	'';
			var sqlOrderBy				=	'';
			
			sqlFromTable				=	" FROM contract_commission_share_holder ";
			//sqlOrderBy					=	" ORDER BY contract_commission_share_holder.id DESC ";
			sqlOrderBy					=	" ORDER BY contract.start_date ASC ";
			
			//sqlSelectArray.push("SELECT  job.* ");	
			sqlSelectArray.push("SELECT contract_commission_share_holder.id, contract_commission_share_holder.contract_id, contract_commission_share_holder.agent_id, contract_commission_share_holder.job_share_level");
			sqlSelectArray.push("contract.id, contract.job_id, contract.company_id, contract.agent_id, contract.rate, contract.rate_type_id, contract.start_date, contract.end_date, contract.cv_shared_level");
			sqlSelectArray.push("FROM_UNIXTIME(contract.start_date, '%Y-%m-%d') AS contract_start_date_full");
			sqlSelectArray.push("FROM_UNIXTIME(contract.start_date, '%Y') AS contract_start_date_year");
			sqlSelectArray.push("FROM_UNIXTIME(contract.start_date, '%m') AS contract_start_date_month");
			sqlSelectArray.push("FROM_UNIXTIME(contract.start_date, '%d') AS contract_start_date_day");
			
			sqlSelectArray.push("FROM_UNIXTIME(contract.end_date, '%Y-%m-%d') AS contract_end_date_full");
			sqlSelectArray.push("FROM_UNIXTIME(contract.end_date, '%Y') AS contract_end_date_year");
			sqlSelectArray.push("FROM_UNIXTIME(contract.end_date, '%m') AS contract_end_date_month");
			sqlSelectArray.push("FROM_UNIXTIME(contract.end_date, '%d') AS contract_end_date_day");
			sqlSelectArray.push("company_commission.*");
			
			sqlSelectArray.push("FROM_UNIXTIME(company_commission.start_date, '%Y-%m-%d') AS company_commission_start_date_full"); 
			sqlSelectArray.push("FROM_UNIXTIME(company_commission.end_date, '%Y-%m-%d') AS company_commission_end_date_full");

			sqlJoinArray.push("LEFT JOIN contract ON contract.id = contract_commission_share_holder.contract_id");
			sqlJoinArray.push("LEFT JOIN company_commission ON company_commission.company_id = contract.company_id AND ((company_commission.start_date <= UNIX_TIMESTAMP(STR_TO_DATE("+pool.escape(start_date)+", '%Y-%m-%d'))) AND ((company_commission.end_date >= UNIX_TIMESTAMP(DATE_ADD(STR_TO_DATE("+pool.escape(start_date)+", '%Y-%m-%d'), INTERVAL "+pool.escape(monthCount)+" MONTH))) OR (company_commission.end_date IS NULL)))");
					
			sqlQueryWhereArray.push(" WHERE contract_commission_share_holder.agent_id = "+pool.escape(user_id));
			sqlQueryWhereArray.push(" contract.rate_type_id = 2");	//	SELECT ONLY PER DAY CONTRACTS.
			sqlQueryWhereArray.push("");			
			
			sqlQueryWhereOrArray.push("(((contract.start_date <= UNIX_TIMESTAMP(STR_TO_DATE("+pool.escape(start_date)+", '%Y-%m-%d'))) AND (contract.end_date >= UNIX_TIMESTAMP(DATE_ADD(STR_TO_DATE("+pool.escape(start_date)+", '%Y-%m-%d'), INTERVAL "+pool.escape(monthCount)+" MONTH))))");
			sqlQueryWhereOrArray.push(" ((contract.start_date >= UNIX_TIMESTAMP(STR_TO_DATE("+pool.escape(start_date)+", '%Y-%m-%d'))) AND (contract.end_date <= UNIX_TIMESTAMP(DATE_ADD(STR_TO_DATE("+pool.escape(start_date)+", '%Y-%m-%d'), INTERVAL "+pool.escape(monthCount)+" MONTH))))");
			sqlQueryWhereOrArray.push(" ((contract.start_date >= UNIX_TIMESTAMP(STR_TO_DATE("+pool.escape(start_date)+", '%Y-%m-%d'))) AND (contract.end_date >= UNIX_TIMESTAMP(DATE_ADD(STR_TO_DATE("+pool.escape(start_date)+", '%Y-%m-%d'), INTERVAL "+pool.escape(monthCount)+" MONTH))) AND (contract.start_date <= UNIX_TIMESTAMP(DATE_ADD(STR_TO_DATE("+pool.escape(start_date)+", '%Y-%m-%d'), INTERVAL "+pool.escape(monthCount)+" MONTH))))");
			sqlQueryWhereOrArray.push(" ((contract.start_date <= UNIX_TIMESTAMP(STR_TO_DATE("+pool.escape(start_date)+", '%Y-%m-%d'))) AND (contract.end_date <= UNIX_TIMESTAMP(DATE_ADD(STR_TO_DATE("+pool.escape(start_date)+", '%Y-%m-%d'), INTERVAL "+pool.escape(monthCount)+" MONTH))) AND (contract.end_date > UNIX_TIMESTAMP(STR_TO_DATE("+pool.escape(start_date)+", '%Y-%m-%d')))))");
							
			sqlSelect		=	sqlSelectArray.join(', ');			
			sqlJoin			=	sqlJoinArray.join(' ');			
			sqlQueryWhere	=	sqlQueryWhereArray.join(' AND ');	
			sqlQueryWhereOr	=	sqlQueryWhereOrArray.join(' OR ');	
			
			var sqlQuery	=	sqlSelect + sqlFromTable + sqlJoin + sqlQueryWhere + sqlQueryWhereOr + sqlOrderBy;					
			
			//console.log('sqlQuery = '+sqlQuery);			
			
			pool.getConnection(function(error, connection) {									
				// Use the database connection

				var options = {sql: sqlQuery, nestTables: '_'};
				connection.query(options, function (error, results, fields) {
					
					// And done with the database connection.
					connection.release();

					if (error) { 
						throw error; 
					} else {

						if(!results) {
							return callback(null, null);
						} else {
							//console.log(results);
							return callback(null, results);
						}			
						return callback(null, null);
					}

					// Don't use the connection here, it has been returned to the pool.
				});
			});
		},
		//=================================================================
		/* 
		Function to process forecast reward data step1.
		*/
		//paymentAgentForecastStep1: function(graphStartYear, graphStartMonth, callback) {		
		paymentAgentForecastStep3: function(step2_start_date, payment_agent_forecast_future_months, paymentAgentForecastStep2Data, callback) {		
		
			console.log('paymentAgentForecastStep3 - START');
			
			var paymentAgentForecastStep3Data			=	[];
			var paymentAgentForecastStep3YearMonthKeyData			=	[];
			var count									=	-1;				
			var default_working_days_in_month			=	config.params.DEFAULT_WORKING_DAYS_IN_MONTH;
			var payment_agent_forecast_future_months	=	parseInt(payment_agent_forecast_future_months);
			var step2_start_date						= 	moment(step2_start_date, 'YYYY-MM-DD').format('YYYY-MM-DD');
			var step2_start_date_year					=	moment(step2_start_date,"YYYY-MM-DD").year();
			var step2_start_date_month					=	moment(step2_start_date,"YYYY-MM-DD").month()+1;			
			var step2_start_date_days_in_month			=	moment(step2_start_date, "YYYY-MM-DD").daysInMonth();
			
			var step2_end_date 							= 	moment(step2_start_date).add(payment_agent_forecast_future_months, 'months').startOf('month').format('YYYY-MM-DD');
			var step2_end_date_year						=	moment(step2_end_date,"YYYY-MM-DD").year();
			var step2_end_date_month					=	moment(step2_end_date,"YYYY-MM-DD").month()+1;
			var step2_end_date_days_in_month			=	moment(step2_end_date, "YYYY-MM-DD").daysInMonth();
			
			/*
			console.log('payment_agent_forecast_future_months = '+payment_agent_forecast_future_months);
			console.log('step2_start_date = '+step2_start_date);
			console.log('step2_start_date_year = '+step2_start_date_year);
			console.log('step2_start_date_month = '+step2_start_date_month);
			console.log('step2_start_date_days_in_month = '+step2_start_date_days_in_month);
			console.log('step2_end_date = '+step2_end_date);
			console.log('step2_end_date_year = '+step2_end_date_year);
			console.log('step2_end_date_month = '+step2_end_date_month);
			console.log('step2_end_date_days_in_month = '+step2_end_date_days_in_month);
			*/
			
			var user_id 				= 	AuthenticUser.id;
			
			if(paymentAgentForecastStep2Data && paymentAgentForecastStep2Data.length){
				loopContract:
				for(i=0; i<paymentAgentForecastStep2Data.length; i++){
					
					var contract	=	paymentAgentForecastStep2Data[i];
					
					console.log('----------------------------');
					//console.log(contract);
					console.log('----------------------------');
  
					var contract_commission_share_holder_job_share_level	=	contract.contract_commission_share_holder_job_share_level;
					var contract_id											=	contract.contract_commission_share_holder_contract_id;
					var contract_cv_shared_level							=	contract.contract_cv_shared_level;
					var contract_rate										=	contract.contract_rate;
					var contract_rate_type_id								=	contract.contract_rate_type_id;
					
					var company_commission_level_0_agent_0					=	contract.company_commission_level_0_agent_0;
					var company_commission_level_1_agent_0					=	contract.company_commission_level_1_agent_0;
					var company_commission_level_1_agent_1					=	contract.company_commission_level_1_agent_1;
					var company_commission_level_2_agent_0					=	contract.company_commission_level_2_agent_0;
					var company_commission_level_2_agent_1					=	contract.company_commission_level_2_agent_1;
					var company_commission_level_2_agent_2					=	contract.company_commission_level_2_agent_2;
					
					var contract_start_date_full							=	contract._contract_start_date_full;					
					var contract_start_date_year							=	parseInt(contract._contract_start_date_year);
					var contract_start_date_month							=	parseInt(contract._contract_start_date_month);
					var contract_start_date_day								=	parseInt(contract._contract_start_date_day);
					var contract_end_date_full								=	parseInt(contract._contract_end_date_full);
					var contract_end_date_year								=	parseInt(contract._contract_end_date_year);
					var contract_end_date_month								=	parseInt(contract._contract_end_date_month);
					var contract_end_date_day								=	parseInt(contract._contract_end_date_day);
					
					/*
					console.log('contract_commission_share_holder_job_share_level = '+contract_commission_share_holder_job_share_level);
					console.log('contract_rate = '+contract_rate);
					console.log('contract_rate_type_id = '+contract_rate_type_id);
					console.log('company_commission_level_0_agent_0 = '+company_commission_level_0_agent_0);
					console.log('company_commission_level_1_agent_0 = '+company_commission_level_1_agent_0);
					console.log('company_commission_level_1_agent_1 = '+company_commission_level_1_agent_1);
					console.log('company_commission_level_2_agent_0 = '+company_commission_level_2_agent_0);
					console.log('company_commission_level_2_agent_1 = '+company_commission_level_2_agent_1);
					console.log('company_commission_level_2_agent_2 = '+company_commission_level_2_agent_2);					
					console.log('contract_start_date_full = '+contract_start_date_full);
					console.log('contract_start_date_year = '+contract_start_date_year);
					console.log('contract_start_date_month = '+contract_start_date_month);
					console.log('contract_start_date_day = '+contract_start_date_day);
					console.log('contract_end_date_full = '+contract_end_date_full);
					console.log('contract_end_date_year = '+contract_end_date_year);
					console.log('contract_end_date_month = '+contract_end_date_month);
					console.log('contract_end_date_day = '+contract_end_date_day);
					*/
					
					loopYear:
					for(y=step2_start_date_year; y<=step2_end_date_year; y++){
						
						var mStart	=	1;
						var mEnd	=	12;
						
						if(y==step2_start_date_year) {
							var mStart = step2_start_date_month;
						}
						
						if(y==step2_end_date_year) {
							var mEnd = step2_end_date_month;
						}
						
						//console.log('mStart = '+mStart);
						//console.log('mEnd = '+mEnd);
						
						
						loopMonth:
						for(m=mStart; m<=mEnd; m++){
							++count;
							//console.log('count = '+count+' y = '+y+' m = '+m);
							//console.log('m = '+m);
						
							var net_working_days_in_month	=	0;
							var contractor_amount			=	0;
							var agent_commission_percentage	=	0;
							var agent_commission_amount		=	0;
							
							if(y==step2_start_date_year && m==step2_start_date_month) {
								net_working_days_in_month	=	Number(((default_working_days_in_month/step2_start_date_days_in_month)*(step2_start_date_days_in_month - contract_start_date_day + 1)).toFixed(1));
							} else if(y==contract_end_date_year && m==contract_end_date_month) {
								net_working_days_in_month	=	Number(((default_working_days_in_month/step2_start_date_days_in_month)*(contract_end_date_day)).toFixed(1));
							} else {
								net_working_days_in_month	=	default_working_days_in_month;	
							}
							
							if(contract_cv_shared_level == config.JOB.JOB_SHARE_LEVEL_0){
								if(contract_commission_share_holder_job_share_level == config.JOB.JOB_SHARE_LEVEL_0){
									agent_commission_percentage	=	company_commission_level_0_agent_0;
								}
							} else if(contract_cv_shared_level == config.JOB.JOB_SHARE_LEVEL_1){								
								if(contract_commission_share_holder_job_share_level == config.JOB.JOB_SHARE_LEVEL_0){
									agent_commission_percentage	=	company_commission_level_1_agent_0;
								}else if(contract_commission_share_holder_job_share_level == config.JOB.JOB_SHARE_LEVEL_1){
									agent_commission_percentage	=	company_commission_level_1_agent_1;
								}						
							} else if(contract_cv_shared_level == config.JOB.JOB_SHARE_LEVEL_2){								
								if(contract_commission_share_holder_job_share_level == config.JOB.JOB_SHARE_LEVEL_0){
									agent_commission_percentage	=	company_commission_level_2_agent_0;
								}else if(contract_commission_share_holder_job_share_level == config.JOB.JOB_SHARE_LEVEL_1){
									agent_commission_percentage	=	company_commission_level_2_agent_1;
								}else if(contract_commission_share_holder_job_share_level == config.JOB.JOB_SHARE_LEVEL_2){
									agent_commission_percentage	=	company_commission_level_2_agent_2;
								}
							} 
							contractor_amount		=	contract_rate*net_working_days_in_month;					
							agent_commission_amount	=	(contractor_amount*agent_commission_percentage)/100;
							
							
							//paymentAgentForecastStep3YearMonthKeyData[count] = {
							//	key_year_month: y +"_"+ m,
							//}; 
							var key_year_month	=	y +"_"+ m;
							paymentAgentForecastStep3YearMonthKeyData.push(key_year_month);
							
							var paymentAgentForecastStep3YearMonthKeyData = paymentAgentForecastStep3YearMonthKeyData.filter(function(elem, index, self) {
								return index == self.indexOf(elem);
							})

							paymentAgentForecastStep3Data[count] = {
								key_year_month:key_year_month,
								contract_id: contract_id,
								payment_agent_forecast_timesheet_year: y,
								payment_agent_forecast_timesheet_month: m,
								contractor_amount: contractor_amount,
								working_days_in_month: net_working_days_in_month,
								agent_commission_percentage: agent_commission_percentage,
								agent_commission_amount: agent_commission_amount,
								//_AGENT_COMMISSION_AMOUNT_TOTAL: y,
							};
							if(y==contract_end_date_year && m==contract_end_date_month) {
								break loopYear;
							}
						}
					}					
				}
				//---------------------------------------------------------------
				console.log('paymentAgentForecastStep3Data.length ==== '+paymentAgentForecastStep3Data.length);
								
				//---------------------------------------------------------------
				console.log('paymentAgentForecastStep3 - END');
				console.log('paymentAgentForecastStep3Data');
				console.log('paymentAgentForecastStep3DataFinal');
				//console.log(paymentAgentForecastStep3DataFinal);
				//console.log(paymentAgentForecastStep3Data.length);
				//console.log(paymentAgentForecastStep3Data);
				
				return callback(null, paymentAgentForecastStep3Data, paymentAgentForecastStep3YearMonthKeyData);
			}
			
			return callback(null, null, null);
			
			
			
		},
		
		
		//=================================================================
		/* 
		Function to process forecast reward data step1.
		*/
		//paymentAgentForecastStep1: function(graphStartYear, graphStartMonth, callback) {		
		paymentAgentForecastStep4: function(paymentAgentForecastStep3Data, paymentAgentForecastStep3YearMonthKeyData, callback) {		
		
			
			console.log('----------------------------');
			console.log('----------------------------');
			console.log('----------------------------');
			console.log('----------------------------');
			console.log('----------------------------');
			console.log('----------------------------');
			console.log('----------------------------');
			console.log('----------------------------');
			console.log('----------------------------');
			console.log('START - paymentAgentForecastStep4 - START');
			console.log('START - paymentAgentForecastStep4 - START');
			console.log('START - paymentAgentForecastStep4 - START');
			console.log('----------------------------');
			console.log('----------------------------');
			console.log('----------------------------');
			console.log('----------------------------');
			console.log('----------------------------');
			console.log('----------------------------');
			console.log('----------------------------');
			console.log('----------------------------');
			console.log('----------------------------');
			
			var paymentAgentForecastStep4Data			=	[];
			//var count									=	-1;				
			
			var user_id 				= 	AuthenticUser.id;
			
			//---------------------------------------------------------------
			console.log('paymentAgentForecastStep3Data = '+JSON.stringify(paymentAgentForecastStep3Data,null,2));
			console.log('paymentAgentForecastStep3YearMonthKeyData = '+JSON.stringify(paymentAgentForecastStep3YearMonthKeyData,null,2));
			console.log('paymentAgentForecastStep3Data.length ==== '+paymentAgentForecastStep3Data.length);
			console.log('paymentAgentForecastStep4Data.length ==== '+paymentAgentForecastStep4Data.length);
			//console.log('paymentAgentForecastStep3Data = '+JSON.stringify(paymentAgentForecastStep3Data,null,2));
			//---------------------------------------------------------------
									
			
			if(paymentAgentForecastStep3Data.length) {
				var count = 0;
				
				for(i=0; i<paymentAgentForecastStep3Data.length; i++) {
					
					var match = false;
					var data 									=	paymentAgentForecastStep3Data[i];
					
					console.log('data = '+JSON.stringify(data,null,2));
					
					var key_year_month							=	data['key_year_month'];						
					var contract_id								=	data['contract_id'];	
					var payment_agent_forecast_timesheet_year	=	data['payment_agent_forecast_timesheet_year'];	
					var payment_agent_forecast_timesheet_month	=	data['payment_agent_forecast_timesheet_month'];	
					var agent_commission_amount					=	data['agent_commission_amount'];	
					
					
					if(i==0) {	
						
						paymentAgentForecastStep4Data[0] = {								
							key_year_month: key_year_month,
							payment_agent_forecast_timesheet_year: payment_agent_forecast_timesheet_year,
							payment_agent_forecast_timesheet_month: payment_agent_forecast_timesheet_month,
							agent_commission_amount: agent_commission_amount,								
						};
						
					} else {							
						
						for(var j = 0; j < paymentAgentForecastStep4Data.length; j++) {
							
							console.log('key_year_month = '+paymentAgentForecastStep4Data[j].key_year_month);
							
						   if(paymentAgentForecastStep4Data[j].key_year_month === key_year_month) {
							 console.log('yesssssssss');
							 match = true;
							 
							 paymentAgentForecastStep4Data[j] = {								
								key_year_month: key_year_month,
								payment_agent_forecast_timesheet_year: paymentAgentForecastStep4Data[j].payment_agent_forecast_timesheet_year,
								payment_agent_forecast_timesheet_month: paymentAgentForecastStep4Data[j].payment_agent_forecast_timesheet_month,
								agent_commission_amount: paymentAgentForecastStep4Data[j].agent_commission_amount+agent_commission_amount,	
							
							}; 
							break;
						   }
						}
						
						if(match===false) {
							paymentAgentForecastStep4Data[paymentAgentForecastStep4Data.length] = {								
								key_year_month: key_year_month,
								payment_agent_forecast_timesheet_year: payment_agent_forecast_timesheet_year,
								payment_agent_forecast_timesheet_month: payment_agent_forecast_timesheet_month,
								agent_commission_amount: agent_commission_amount,							
							};
						}		
					}					
					count++;
				}
				
				console.log('paymentAgentForecastStep4Data = '+JSON.stringify(paymentAgentForecastStep4Data,null,2));
								
				return callback(null, paymentAgentForecastStep4Data);
				
			}
					
					
					
					
				
					
					
					
					
					
					
					console.log('----------------------------');
					console.log('paymentAgentForecastStep3Data...');
					console.log(paymentAgentForecastStep3Data);
					console.log('paymentAgentForecastStep3Data.length = '+paymentAgentForecastStep3Data.length);
					
					console.log('paymentAgentForecastStep4Data...');
					console.log(paymentAgentForecastStep4Data);
					console.log('paymentAgentForecastStep4Data.length = '+paymentAgentForecastStep4Data.length);
					console.log('----------------------------');
					//return callback(null, paymentAgentForecastStep4Data);
				
			
			//return callback(null, null);		
		},
		//=================================================================
		/* 
		Function to process forecast reward data step1.
		*/
		processForecastRewardDataStep10: function(graphStartYear, graphStartMonth, graphData, callback) {
						
			//return callback(null, data);
			//console.log('==========================================');
			//console.log('convertForecastRewardDataToCumulativeData');
			//console.log('graphStartYear = '+graphStartYear);
			//console.log('graphStartMonth = '+graphStartMonth);
			//console.log('graphData = '+JSON.stringify(graphData,null,2));
			//console.log('==========================================');
						
			var firstMonthOfYear	=	1;
			var lastMonthOfYear		=	12;
			//var totalMonthInYear	=	12;
			var averageDaysInMonth	=	30;
			var showGarphMaxMonth	=	6;
			var yearIncrement		=	1;
			
			var defaultWorkingDays	=	19;
			
			//console.log('.......1111111111111111111');
			//console.log(graphData);
			//console.log('.......1111111111111111111');
		
			var graphStartYear 		=  	parseInt(graphStartYear);
			var graphStartMonth		=	parseInt(graphStartMonth);
			
			var graphEndYear 		= 	graphStartYear;
			var graphEndMonth		=	graphStartMonth+showGarphMaxMonth;
			
			if(graphEndMonth > lastMonthOfYear) {
				graphEndYear	=	graphStartYear+yearIncrement;
				graphEndMonth 	=	(graphEndMonth-lastMonthOfYear)-1;				
			}
			
			//console.log('graphEndYear = '+graphEndYear);
			//console.log('graphEndMonth = '+graphEndMonth);
			
			var rewardCumulativeDataStep1 	= 	[];
			//var rewardCumulativeDataStep2 = 	[];
			var rewardCumulativeData 		= 	[];
			var rewardCumulativeDataFinal	=	[];
			
			var count = 0;
			
			//----------------------------------------------
			// CODE START :: STEP-1 :: CREATE BLANK ARRAY OF 6 MONTHS OF COMMISSION
			//----------------------------------------------
			if(graphStartYear == graphEndYear) {
				
				//console.log('graphStartYear = graphEndYear');
				
				for(i=graphStartMonth; i<graphStartMonth+showGarphMaxMonth; i++) {
					
					rewardCumulativeDataStep1[count] = {
						timesheet_year:   graphStartYear,
						timesheet_month: i,
						commission_amount_total: 0
					};
					count++;
				}				
				//console.log('rewardCumulativeDataStep1='+rewardCumulativeDataStep1);
				
				
			} else if (graphEndYear > graphStartYear) {
				
				//console.log('Graph data have 2 years...');
				
				for(i=graphStartMonth; i<=lastMonthOfYear; i++) {
					
					//console.log('graphStartYear - graphStartMonth - i  ='+i);
					
					rewardCumulativeDataStep1[count] = {
						timesheet_year:   graphStartYear,
						timesheet_month: i,
						commission_amount_total: 0
					};
					count++;
				}
				//console.log('rewardCumulativeDataStep1 2 ='+JSON.stringify(rewardCumulativeDataStep1));			
				//console.log('graphStartMonth ='+graphStartMonth);
				
				for(i=firstMonthOfYear; i<=graphEndMonth; i++) {
					
					//console.log('graphEndYear - graphEndMonth - i  ='+i);
					
					rewardCumulativeDataStep1[count] = {
						timesheet_year:   graphEndYear,
						timesheet_month: i,
						commission_amount_total: 0
					};
					count++;
				}
				//console.log('rewardCumulativeDataStep1 3 ='+JSON.stringify(rewardCumulativeDataStep1));
			}
			
			//----------------------------------------------
			// CODE END :: STEP-1 :: CREATE BLANK ARRAY OF 6 MONTHS OF COMMISSION
			//----------------------------------------------
			
			
			
			
			//console.log('******************************************');
			//console.log('******************************************');
			//----------------------------------------------
			// CODE START :: STEP-2 :: CREATE ARRAY OF CONTRACTS FOR EVERY MONTH.
			//----------------------------------------------
			var contractStep1	=	[];
			var contractStep2	=	[];
			var contractStep3	=	[];
			
			if(graphData.length) {
				
				for(i=0; i<graphData.length; i++) {
					
					var job_share_level 			= 	parseInt(graphData[i]['contract_commission_share_holder_job_share_level']);
					var contract_id 				= 	parseInt(graphData[i]['contract_id']);
					var contract_company_id 		= 	parseInt(graphData[i]['contract_company_id']);
					var contract_start_date_year 	= 	parseInt(graphData[i]['_contract_start_date_year']);
					var contract_start_date_month	=	parseInt(graphData[i]['_contract_start_date_month']);
					var contract_start_date_day 	= 	parseInt(graphData[i]['_contract_start_date_day']);
					
					var contract_end_date_year 		= 	parseInt(graphData[i]['_contract_end_date_year']);
					var contract_end_date_month 	= 	parseInt(graphData[i]['_contract_end_date_month']);
					var contract_end_date_day 		= 	parseInt(graphData[i]['_contract_end_date_day']);
					
					
					var contract_rate 				= 	parseInt(graphData[i]['contract_rate']);
					var contract_rate_type_id 		= 	parseInt(graphData[i]['contract_rate_type_id']);
					var contract_cv_shared_level 	= 	parseInt(graphData[i]['contract_cv_shared_level']);
					
					/* 
					console.log('contract_start_date_year = '+contract_start_date_year);
					console.log('contract_start_date_month = '+contract_start_date_month);
					console.log('contract_start_date_day = '+contract_start_date_day);
					console.log('contract_end_date_year = '+contract_end_date_year);
					console.log('contract_end_date_month = '+contract_end_date_month);
					console.log('contract_end_date_day = '+contract_end_date_day);
					console.log('contract_cv_shared_level = '+contract_cv_shared_level);
					 */
					var count	=	0;
					if(contract_start_date_year==contract_end_date_year) {
					
						for(m=contract_start_date_month; m<=contract_end_date_month; m++) {
							
							if(m == contract_start_date_month){
								var working_days = (defaultWorkingDays*(averageDaysInMonth-contract_start_date_day+1))/averageDaysInMonth;
							} else if(m == contract_end_date_month){
								var working_days = Math.floor((defaultWorkingDays*contract_end_date_day)/averageDaysInMonth);
							} else {
								var working_days =	defaultWorkingDays;
							}
							contractStep1[count] = {
								job_share_level: job_share_level,
								contract_id: contract_id,
								contract_cv_shared_level: contract_cv_shared_level,
								contract_company_id: contract_company_id,
								contract_start_date_year: contract_start_date_year,
								contract_start_date_month: m,
								contract_start_date_day: contract_start_date_day,
								contract_end_date_year: contract_end_date_year,
								contract_end_date_month: contract_end_date_month,
								contract_end_date_day: contract_end_date_day,
								contract_rate_type_id: contract_rate_type_id,
								contract_rate: contract_rate,
								working_days: working_days,
							};
							count++;
						}
						
					} else if(contract_end_date_year > contract_start_date_year) {
						
						for(y=contract_start_date_year; y<=contract_end_date_year; y++) {
							
							if(y == contract_start_date_year) {
								
								for(m=contract_start_date_month; m<=lastMonthOfYear; m++) {
									
									if(m == contract_start_date_month){
										var working_days = (defaultWorkingDays*(averageDaysInMonth-contract_start_date_day+1))/averageDaysInMonth;
									} else {
										var working_days =	defaultWorkingDays;
									}
									contractStep1[count] = {
										job_share_level: job_share_level,
										contract_id: contract_id,
										contract_cv_shared_level: contract_cv_shared_level,
										contract_company_id: contract_company_id,
										contract_start_date_year: y,
										contract_start_date_month: m,
										contract_start_date_day: contract_start_date_day,
										contract_end_date_year: contract_end_date_year,
										contract_end_date_month: contract_end_date_month,
										contract_end_date_day: contract_end_date_day,
										contract_rate_type_id: contract_rate_type_id,
										contract_rate: contract_rate,
										working_days: defaultWorkingDays,
									};
									
									count++;
								}
							} else if((y > contract_start_date_year) && (y < contract_end_date_year))  {
								
								for(m=firstMonthOfYear; m<=lastMonthOfYear; m++) {
									
									contractStep1[count] = {
										job_share_level: job_share_level,
										contract_id: contract_id,
										contract_cv_shared_level: contract_cv_shared_level,
										contract_company_id: contract_company_id,
										contract_start_date_year: y,
										contract_start_date_month: m,
										contract_start_date_day: contract_start_date_day,
										contract_end_date_year: contract_end_date_year,
										contract_end_date_month: contract_end_date_month,
										contract_end_date_day: contract_end_date_day,
										contract_rate_type_id: contract_rate_type_id,
										contract_rate: contract_rate,
										working_days: defaultWorkingDays,
									};
									
									count++;
								}
							} else if(y == contract_end_date_year)  {
								
								for(m=firstMonthOfYear; m<=contract_end_date_month; m++) {
								
									if(m == contract_end_date_month){
										var working_days = Math.floor((defaultWorkingDays*contract_end_date_day)/averageDaysInMonth);
									} else {
										var working_days =	defaultWorkingDays;
									}
									
									contractStep1[count] = {
										job_share_level: job_share_level,
										contract_id: contract_id,
										contract_cv_shared_level: contract_cv_shared_level,
										contract_company_id: contract_company_id,
										contract_start_date_year: y,
										contract_start_date_month: m,
										contract_start_date_day: contract_start_date_day,
										contract_end_date_year: contract_end_date_year,
										contract_end_date_month: contract_end_date_month,
										contract_end_date_day: contract_end_date_day,
										contract_rate_type_id: contract_rate_type_id,
										contract_rate: contract_rate,
										working_days: working_days,
									};
									
									count++;
								}
							}
							
							
						}
					}
					//console.log('+++++++++++++++++++++++++++++++++++++++++++++');
					//console.log('contractStep1 = '+JSON.stringify(contractStep1,null,2));
					//console.log('contractStep1.length = '+contractStep1.length);
					//console.log('+++++++++++++++++++++++++++++++++++++++++++++');
				}
			}
			//----------------------------------------------
			// CODE END :: STEP-2 :: CREATE ARRAY OF CONTRACTS FOR EVERY MONTH.
			//----------------------------------------------
			
			
			
			
			//----------------------------------------------
			// CODE START :: STEP-3 :: REMOVE ENTRIES FROM CONTRACT ARRAY OTHER THAN GRAPH TIME RANGE.
			//----------------------------------------------
			
			if(contractStep1.length) {
				
				for (var c=0; c<contractStep1.length; c++) {
					
					var step1_contract_start_date_year 			= 	contractStep1[c].contract_start_date_year;
					var step1_contract_start_date_month 		= 	contractStep1[c].contract_start_date_month;
					
						
						for (var r=0; r<rewardCumulativeDataStep1.length; r++) {
				
							var step1_timesheet_year 			= 	parseInt(rewardCumulativeDataStep1[r].timesheet_year);
							var step1_timesheet_month 			= 	parseInt(rewardCumulativeDataStep1[r].timesheet_month);
							
							if((step1_contract_start_date_year == step1_timesheet_year) && (step1_contract_start_date_month == step1_timesheet_month)) {
								
								contractStep2[c] = {
									job_share_level: contractStep1[c].job_share_level,
									contract_id: contractStep1[c].contract_id,
									contract_cv_shared_level: contractStep1[c].contract_cv_shared_level,
									contract_company_id: contractStep1[c].contract_company_id, 
									contract_start_date_year: contractStep1[c].contract_start_date_year,
									contract_start_date_month: contractStep1[c].contract_start_date_month,
									contract_start_date_day: contractStep1[c].contract_start_date_day,
									contract_end_date_year: contractStep1[c].contract_end_date_year,
									contract_end_date_month: contractStep1[c].contract_end_date_month,
									contract_end_date_day: contractStep1[c].contract_end_date_day,
									contract_rate_type_id: contractStep1[c].contract_rate_type_id,
									contract_rate: contractStep1[c].contract_rate,
									working_days: contractStep1[c].working_days, 
									contractor_receivable_amount: (contractStep1[c].working_days*contractStep1[c].contract_rate), 
								};
							}
						}
						//console.log('+++++++++++++++++++++++++++++++++++++++++++++');
						//console.log('contractStep2 = '+JSON.stringify(contractStep2,null,2));
						//console.log('contractStep2.length = '+contractStep2.length);
						//console.log('+++++++++++++++++++++++++++++++++++++++++++++');	
				
						
						
						
					
				}
				
			}
			
			
			if(contractStep2.length) {
							
				for (var c=0; c<contractStep2.length; c++) {
					
					PaymentAgentModel.getForecastRewardDataCommission(contractStep2[c], function(error, results) {
												
						if (error) {    
							throw error;
						} else {
							if(!results) {
								return callback(null, null);
							} else {
								//var agent_commission	=	results;
								//console.log('START+++++++++++++++++++++++++++++++++++++++++++++&&&&&&&&&&&&&&&&&&&&&&&&');
								//console.log('getForecastRewardDataCommission');
								//console.log('agent_commission_results = '+results);
								//console.log('agent_commission = '+JSON.stringify(results,null,2));
								//console.log('results.agent_commission = '+results.agent_commission);
								//console.log('job_share_level = '+contractStep2[c].job_share_level);
								//console.log('c = '+c);
								//console.log('END+++++++++++++++++++++++++++++++++++++++++++++&&&&&&&&&&&&&&&&&&&&&&&&');
								
								/*
								contractStep3[c] = {
														c: c,
														job_share_level: results.job_share_level,
														contract_id: results.contract_id,
														contract_cv_shared_level: results.contract_cv_shared_level,
														contract_company_id: results.contract_company_id,
														contract_start_date_year: results.contract_start_date_year,
														contract_start_date_month: results.contract_start_date_month,
														contract_start_date_day: results.contract_start_date_day,
														contract_end_date_year: results.contract_end_date_year,
														contract_end_date_month: results.contract_end_date_month,
														contract_end_date_day: results.contract_end_date_day,
														contract_rate_type_id: results.contract_rate_type_id,
														contract_rate: results.contract_rate,
														working_days: results.working_days, 
														contractor_receivable_amount: results.contractor_receivable_amount,
														agent_commission: results.agent_commission,
													};
													
								//contractStep3[c] = results;
								*/
								 contractStep3.push(results);
								
							}
						}								
					});
	
					
				}
				//console.log('%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%');
				//console.log('contractStep3 = '+JSON.stringify(contractStep3,null,2));
				//console.log('contractStep3.length..... = '+contractStep3.length);
				//console.log('%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%');
				//return contractStep2;
				
				return callback(null, contractStep3);
				
			}
			
			
			
			//----------------------------------------------
			// CODE END :: STEP-3 :: REMOVE ENTRIES FROM CONTRACT ARRAY OTHER THAN GRAPH TIME RANGE.
			//----------------------------------------------
			
			
			//console.log('******************************************');
			//console.log('******************************************');
			
			
			
			
			//return rewardCumulativeDataFinal;		
		},
		//=================================================================
		/* 
		Function to get forecast reward data commission
		*/
		getForecastRewardDataCommission: function(rewardData, callback) {
			
			//console.log('getForecastRewardDataCommission');	
			//console.log('rewardData');	
			//console.log(rewardData);	
			//return callback(null, rewardData);
			
			var user_id 			= 	AuthenticUser.id;			
			//console.log('user_id = '+user_id);			
				
			if((typeof user_id !== 'undefined' && user_id !== null && user_id>0)) {
				
				var job_share_level 				=	rewardData['job_share_level'];
				var contract_id						=	rewardData['contract_id'];
				var contract_cv_shared_level		=	rewardData['contract_cv_shared_level'];
				var contract_company_id				=	rewardData['contract_company_id'];
				var contract_start_date_year		=	rewardData['contract_start_date_year'];
				var contract_start_date_month		=	rewardData['contract_start_date_month'];
				var contract_start_date_day			=	rewardData['contract_start_date_day'];
				var contract_end_date_year			=	rewardData['contract_end_date_year'];
				var contract_end_date_month			=	rewardData['contract_end_date_month'];
				var contract_end_date_day			=	rewardData['contract_end_date_day'];
				var contract_rate_type_id			=	rewardData['contract_rate_type_id'];
				var contract_rate					=	rewardData['contract_rate'];
				var working_days					=	rewardData['working_days'];
				var contractor_receivable_amount	=	rewardData['contractor_receivable_amount'];
				
				var agent_commission_percentage		=	0;
				var agent_commission				=	0;
								
			
				var contract_start_date				=	contract_start_date_year+'-'+contract_start_date_month+'-'+contract_start_date_day;
				var contract_end_date				=	contract_end_date_year+'-'+contract_end_date_month+'-'+contract_end_date_day;
				
				var sqlSelectArray 		= 	[];			
				var sqlJoinArray 		= 	[];
				var sqlGroupByArray 	= 	[];
				var sqlQueryWhereArray 	= 	[];
												
				var sqlSelect		 	= 	'';
				var sqlFromTable		= 	'';
				var sqlJoin		 		= 	'';			
				var sqlQueryWhere		=	'';
				var sqlOrderBy			=	'';
				var sqlLimit			=	' LIMIT 1';
				//var sqlOffset			=	' OFFSET '+offset;
				
				sqlFromTable			=	" FROM company_commission ";
				sqlOrderBy				=	" ORDER BY company_commission.id ASC ";
				
								
				sqlSelectArray.push("SELECT company_commission.*");
				
				sqlQueryWhereArray.push(" WHERE company_commission.company_id = "+(contract_company_id));
				sqlQueryWhereArray.push(" company_commission.start_date <= UNIX_TIMESTAMP(STR_TO_DATE('"+contract_start_date+"', '%Y-%m-%d'))");
				sqlQueryWhereArray.push(" (company_commission.end_date >= UNIX_TIMESTAMP(STR_TO_DATE('"+contract_end_date+"', '%Y-%m-%d'))) OR (company_commission.end_date IS NULL)");
												
				sqlQueryWhere 	= 	sqlQueryWhereArray.join(' AND ');						
				sqlSelect		=	sqlSelectArray.join(', ');			
				sqlJoin			=	sqlJoinArray.join(' ');			
				sqlQueryWhere	=	sqlQueryWhereArray.join(' AND ');
				sqlGroupBy		=	sqlGroupByArray.join(' ');

				var sqlQuery	=	sqlSelect + sqlFromTable + sqlJoin + sqlQueryWhere + sqlGroupBy + sqlOrderBy + sqlLimit;		
				
				//console.log('sqlQuery = '+sqlQuery);
				
				
				pool.getConnection(function(error, connection) {									
					// Use the database connection
					var options = {sql: sqlQuery, nestTables: false};
					connection.query(options, function (error, results, fields) {
					// And done with the database connection.
						connection.release();

						if (error) { 
							throw error; 
						} else {
							if(!results) {
								return callback(null, null);
							} else {
								//console.log(results);
								
								var slab_1_contractor_min	=	results[0]['slab_1_contractor_min'];
								var slab_1_contractor_max	=	results[0]['slab_1_contractor_max'];
								var slab_1_admin_commission	=	results[0]['slab_1_admin_commission'];
								var slab_2_contractor_min	=	results[0]['slab_2_contractor_min'];
								var slab_2_contractor_max	=	results[0]['slab_2_contractor_max'];
								var slab_2_admin_commission	=	results[0]['slab_2_admin_commission'];
								var slab_3_contractor_min	=	results[0]['slab_3_contractor_min'];
								var slab_3_contractor_max	=	results[0]['slab_3_contractor_max'];
								var slab_3_admin_commission	=	results[0]['slab_3_admin_commission'];
								var level_0_agent_0			=	results[0]['level_0_agent_0'];
								var level_1_agent_0			=	results[0]['level_1_agent_0'];
								var level_1_agent_1			=	results[0]['level_1_agent_1'];
								var level_2_agent_0			=	results[0]['level_2_agent_0'];
								var level_2_agent_1			=	results[0]['level_2_agent_1'];
								var level_2_agent_2			=	results[0]['level_2_agent_2'];
								
								
								
								//console.log('level_0_agent_0 === '+results[0]['level_0_agent_0']);
								
								if(contract_cv_shared_level == config.JOB.JOB_SHARE_LEVEL_0) {
									//console.log('CASE 0.0');
									if(job_share_level == config.JOB.JOB_SHARE_LEVEL_0) {
										agent_commission_percentage	=	level_0_agent_0;
									}
									
								} else if(contract_cv_shared_level == config.JOB.JOB_SHARE_LEVEL_1) {
									//console.log('CASE 1.0');
									if(job_share_level == config.JOB.JOB_SHARE_LEVEL_0) {
										agent_commission_percentage	=	level_1_agent_0;
									} else if(job_share_level == config.JOB.JOB_SHARE_LEVEL_1) {
										agent_commission_percentage	=	level_1_agent_1;
									}
									
								} else if(contract_cv_shared_level == config.JOB.JOB_SHARE_LEVEL_2) {
									//console.log('CASE 2.0');
									//console.log('job_share_level = '+job_share_level);
									if(job_share_level == config.JOB.JOB_SHARE_LEVEL_0) {
										agent_commission_percentage	=	level_2_agent_0;
									} else if(job_share_level == config.JOB.JOB_SHARE_LEVEL_1) {
										agent_commission_percentage	=	level_2_agent_1;
									} else if(job_share_level == config.JOB.JOB_SHARE_LEVEL_2) {
										agent_commission_percentage	=	level_2_agent_2;
									}										
								}
								//console.log('agent_commission_percentage = '+agent_commission_percentage);
								if(agent_commission_percentage > 0) {
									
									agent_commission	=	parseFloat((contractor_receivable_amount*agent_commission_percentage)/100);
								}
								//console.log('+++++++++++++++++++++++++++++++++++++++++++++');
								//console.log('agent_commission_percentage = '+agent_commission_percentage);
								//console.log('agent_commission = '+agent_commission);
								//console.log('+++++++++++++++++++++++++++++++++++++++++++++');	
								
								rewardData['agent_commission_percentage']	=	agent_commission_percentage;
								rewardData['agent_commission']				=	agent_commission;
								//console.log('rewardData===========>'+JSON.stringify(rewardData,null,2));
								return callback(null, rewardData);
							}			
							//return callback(null, null);
						}

						// Don't use the connection here, it has been returned to the pool.
					});
				});
				
			} else {
				return callback(null, null);
			}		 
		},
		
		
		
		
		//=================================================================		
		/* 
		Function to get earning history of an agent by user ID
		*/
		getEarningTotalByUserId: function(callback) {
			
			//console.log('getEarningHistoryByUserId');	
			var user_id 			= 	AuthenticUser.id;			
			//console.log('user_id = '+user_id);			
				
			if((typeof user_id !== 'undefined' && user_id !== null && user_id>0)) {
				
				var sqlSelectArray 		= 	[];			
				var sqlJoinArray 		= 	[];
				var sqlGroupByArray 	= 	[];
				var sqlQueryWhereArray 	= 	[];
				
				var sqlSelect		 	= 	'';
				var sqlFromTable		= 	'';
				var sqlJoin		 		= 	'';
				var sqlQueryWhere		=	'';
				var sqlGroupBy			=	'';
				var sqlOrderBy			=	'';
				
				

				sqlFromTable			=	" FROM payment_agent ";
				//sqlOrderBy				=	" ORDER BY payment_agent.id ASC ";
				
				//sqlSelectArray.push("SELECT ROUND(COALESCE(SUM(payment_agent.commission_amount),0),2) AS total ");
				sqlSelectArray.push("SELECT FORMAT(COALESCE(SUM(payment_agent.commission_amount),0), 2, 'en_GB') AS total ");
				
				//sqlQueryWhereArray.push(" WHERE payment_agent.agent_id = "+pool.escape(user_id));
				sqlQueryWhereArray.push(" WHERE payment_agent.agent_id = "+(user_id));
				sqlQueryWhereArray.push(" payment_agent.debit_credit_agent = '"+config.params.DEBIT_CREDIT_C+"'");
								
				sqlQueryWhere 	= 	sqlQueryWhereArray.join(' AND ');						
				sqlSelect		=	sqlSelectArray.join(', ');			
				sqlJoin			=	sqlJoinArray.join(' ');			
				sqlQueryWhere	=	sqlQueryWhereArray.join(' AND ');
				sqlGroupBy		=	sqlGroupByArray.join(' ');

				var sqlQuery	=	sqlSelect + sqlFromTable + sqlJoin + sqlQueryWhere + sqlGroupBy + sqlOrderBy;		
				
				//console.log('sqlQuery = '+sqlQuery);
				
				
				pool.getConnection(function(error, connection) {									
					// Use the database connection
					var options = {sql: sqlQuery, nestTables: false};
					connection.query(options, function (error, results, fields) {
					// And done with the database connection.
						connection.release();

						if (error) { 
							throw error; 
						} else {
							if(!results) {
								return callback(null, null);
							} else {
								return callback(null, results);
							}			
							return callback(null, null);
						}

						// Don't use the connection here, it has been returned to the pool.
					});
				});
				
			} else {
				return callback(null, null);
			}		 
		},
		
		//=================================================================
		/* 
		Function to get earning history of an agent by user ID
		*/
		getEarningTotalofPastByUserId: function(date, callback) {
			
			//console.log('getEarningHistoryByUserId');	
			var user_id 			= 	AuthenticUser.id;			
			//console.log('user_id = '+user_id);			
				
			if((typeof user_id !== 'undefined' && user_id !== null && user_id>0)) {
				
				var sqlSelectArray 		= 	[];			
				var sqlJoinArray 		= 	[];
				var sqlGroupByArray 	= 	[];
				var sqlQueryWhereArray 	= 	[];
				
				var sqlSelect		 	= 	'';
				var sqlFromTable		= 	'';
				var sqlJoin		 		= 	'';
				var sqlQueryWhere		=	'';
				var sqlGroupBy			=	'';
				var sqlOrderBy			=	'';
				
				sqlFromTable			=	" FROM payment_agent ";
				//sqlOrderBy				=	" ORDER BY payment_agent.id ASC ";
				
				sqlSelectArray.push("SELECT ROUND(COALESCE(SUM(payment_agent.commission_amount),0),2) AS commission_amount_total_history");
				
				//sqlQueryWhereArray.push(" WHERE payment_agent.agent_id = "+pool.escape(user_id));
				sqlQueryWhereArray.push(" WHERE payment_agent.agent_id = "+(user_id));
				sqlQueryWhereArray.push(" payment_agent.debit_credit_agent = '"+config.params.DEBIT_CREDIT_C+"'");
				sqlQueryWhereArray.push(" payment_agent.timesheet_period_from <  UNIX_TIMESTAMP(STR_TO_DATE('"+date+"', '%Y-%m-%d'))");
				
								
				sqlQueryWhere 	= 	sqlQueryWhereArray.join(' AND ');						
				sqlSelect		=	sqlSelectArray.join(', ');			
				sqlJoin			=	sqlJoinArray.join(' ');			
				sqlQueryWhere	=	sqlQueryWhereArray.join(' AND ');
				sqlGroupBy		=	sqlGroupByArray.join(' ');

				var sqlQuery	=	sqlSelect + sqlFromTable + sqlJoin + sqlQueryWhere + sqlGroupBy + sqlOrderBy;		
				
				//console.log('sqlQuery = '+sqlQuery);
				
				
				pool.getConnection(function(error, connection) {									
					// Use the database connection
					var options = {sql: sqlQuery, nestTables: false};
					connection.query(options, function (error, results, fields) {
					// And done with the database connection.
						connection.release();

						if (error) { 
							throw error; 
						} else {
							if(!results) {
								return callback(null, null);
							} else {
								return callback(null, results);
							}			
							return callback(null, null);
						}

						// Don't use the connection here, it has been returned to the pool.
					});
				});
				
			} else {
				return callback(null, null);
			}		 
		},
		
		//=================================================================
		/* 
		Function to get earning withdrawal amount available of an agent by user ID
		*/
		getEarningWithdrawalAmountAvailableByUserId: function(callback) {
			
			//console.log('getEarningHistoryByUserId');			
			//console.log('user_id = '+user_id);			
			var user_id 			= 	AuthenticUser.id;
			
			if((typeof user_id !== 'undefined' && user_id !== null && user_id>0)) {
				
				var sqlSelectArray 		= 	[];			
				var sqlJoinArray 		= 	[];
				var sqlGroupByArray 	= 	[];
				var sqlQueryWhereArray 	= 	[];
				
				var sqlSelect		 	= 	'';
				var sqlFromTable		= 	'';
				var sqlJoin		 		= 	'';			
				var sqlQueryWhere		=	'';
				var sqlGroupBy			=	'';
				var sqlOrderBy			=	'';
				
				sqlFromTable			=	" FROM payment_agent ";
				sqlOrderBy				=	" ORDER BY payment_agent.id ASC ";
				
				//sqlSelectArray.push("SELECT ROUND(COALESCE(SUM(payment_agent.commission_amount),0),2) AS total");
				sqlSelectArray.push("SELECT FORMAT(COALESCE(SUM(payment_agent.commission_amount),0), 2, 'en_GB') AS total");
				
				sqlQueryWhereArray.push(" WHERE payment_agent.agent_id = "+pool.escape(user_id));
				sqlQueryWhereArray.push("payment_agent.lock_out_date <= unix_timestamp(NOW())");
				sqlQueryWhereArray.push("payment_agent.status_payment_request IS "+config.PAYMENT_AGENT.STATUS_PAYMENT_REQUEST_PENDING);
				sqlQueryWhereArray.push("payment_agent.status_payment_paid IS "+config.PAYMENT_AGENT.STATUS_PAYMENT_PENDING);
				sqlQueryWhereArray.push("payment_agent.debit_credit_agent = '"+config.params.DEBIT_CREDIT_C+"'");
				
				sqlQueryWhere 	= 	sqlQueryWhereArray.join(' AND ');						
				sqlSelect		=	sqlSelectArray.join(', ');			
				sqlJoin			=	sqlJoinArray.join(' ');			
				sqlQueryWhere	=	sqlQueryWhereArray.join(' AND ');
				sqlGroupBy		=	sqlGroupByArray.join(' ');

				var sqlQuery	=	sqlSelect + sqlFromTable + sqlJoin + sqlQueryWhere + sqlGroupBy + sqlOrderBy;		
				
				//console.log('sqlQuery = '+sqlQuery);
				
				pool.getConnection(function(error, connection) {									
					// Use the database connection
					var options = {sql: sqlQuery, nestTables: false};
					connection.query(options, function (error, results, fields) {
					// And done with the database connection.
						connection.release();

						if (error) { 
							throw error; 
						} else {
							if(!results) {
								return callback(null, null);
							} else {
								//console.log(results);
								return callback(null, results);
							}			
							return callback(null, null);
						}

						// Don't use the connection here, it has been returned to the pool.
					});
				});
				
			} else {
				return callback(null, null);
			}		 
		},
		
		//=================================================================
		/* 
		Function to get transaction history of an agent by user ID
		*/
		getTransactionHistoryByUserId: function(callback) {
			
			var user_id 			= 	AuthenticUser.id;
			
			var sqlSelectArray 		= 	[];			
			var sqlJoinArray 		= 	[];
			var sqlQueryWhereArray 	= 	[];
			
			var sqlSelect		 	= 	'';
			var sqlFromTable		= 	'';
			var sqlJoin		 		= 	'';			
			var sqlQueryWhere		=	'';
			var sqlOrderBy			=	'';
			
			sqlFromTable			=	" FROM payment_agent ";
			sqlOrderBy				=	" ORDER BY payment_agent.id DESC ";
			
			sqlSelectArray.push("SELECT payment_agent.id, payment_agent.debit_credit_agent, payment_agent.created_at, payment_agent.timesheet_id, payment_agent.commission_amount, payment_agent.status_payment_request, payment_agent.status_payment_paid");
			sqlSelectArray.push("DATE_FORMAT(FROM_UNIXTIME(payment_agent.timesheet_period_from), '%Y-%m-%d') AS fulldate_timesheet_period_from");
			sqlSelectArray.push("DATE_FORMAT(FROM_UNIXTIME(payment_agent.created_at), '%Y-%m-%d') AS fulldate_created_at");
			sqlSelectArray.push("DATE_FORMAT(FROM_UNIXTIME(payment_agent.lock_out_date), '%Y-%m-%d') AS fulldate_lock_out_date");
			
			sqlSelectArray.push("tale.id, tale.sort_code, tale.account_number");
			sqlSelectArray.push("timesheet.id, timesheet.contract_id");
			sqlSelectArray.push("contract.id, contract.contractor_id, contract.job_title");
			sqlSelectArray.push("user.id, user.full_name");
					
			sqlJoinArray.push("LEFT JOIN tale ON tale.id = payment_agent.tale_id");
			sqlJoinArray.push("LEFT JOIN timesheet ON timesheet.id = payment_agent.timesheet_id");
			sqlJoinArray.push("LEFT JOIN contract ON contract.id = timesheet.contract_id");
			sqlJoinArray.push("LEFT JOIN user ON user.id = contract.contractor_id");
			
			sqlQueryWhereArray.push(" WHERE payment_agent.agent_id = "+pool.escape(user_id));
			sqlQueryWhereArray.push("DATE_FORMAT(FROM_UNIXTIME(payment_agent.created_at), '%Y-%m-%d') > DATE_SUB(now(), INTERVAL "+config.PAYMENT_AGENT.TRANSACTION_HISTORY_TIME_LIMIT+")");
			
			sqlSelect		=	sqlSelectArray.join(', ');			
			sqlJoin			=	sqlJoinArray.join(' ');			
			sqlQueryWhere	=	sqlQueryWhereArray.join(' AND ');	
			
			var sqlQuery	=	sqlSelect + sqlFromTable + sqlJoin + sqlQueryWhere + sqlOrderBy;		
			
			//console.log('sqlQuery = '+sqlQuery);
				
			pool.getConnection(function(error, connection) {									
				// Use the database connection
				var options = {sql: sqlQuery, nestTables: true};
				connection.query(options, function (error, results, fields) { 
				// And done with the database connection.
					connection.release();

					if (error) { 
						throw error; 
					} else {

						if(!results) {
							return callback(null, null);
						} else {
							//console.log(results);
							return callback(null, results);
						}			
						return callback(null, null);
					}
					// Don't use the connection here, it has been returned to the pool.
				});
			});
		},
		//=================================================================
		/* 
		Function to get transaction history of an agent by user ID
		*/
		getTransactionHistoryByUserId_nestTablesFalse: function(callback) {
			
			var user_id 			= 	AuthenticUser.id;
			
			var sqlSelectArray 		= 	[];			
			var sqlJoinArray 		= 	[];
			var sqlQueryWhereArray 	= 	[];
			
			var sqlSelect		 	= 	'';
			var sqlFromTable		= 	'';
			var sqlJoin		 		= 	'';
			var sqlQueryWhere		=	'';
			var sqlOrderBy			=	'';
			
			sqlFromTable			=	" FROM payment_agent ";
			sqlOrderBy				=	" ORDER BY payment_agent.id DESC ";
			
			sqlSelectArray.push("SELECT payment_agent.id, payment_agent.debit_credit_agent, payment_agent.created_at, payment_agent.timesheet_id, payment_agent.commission_amount, payment_agent.status_payment_request, payment_agent.status_payment_paid");
			sqlSelectArray.push("FORMAT(COALESCE(payment_agent.commission_amount,0), 2, 'en_GB') AS payment_agent_commission_amount");
			//sqlSelectArray.push("DATE_FORMAT(FROM_UNIXTIME(payment_agent.timesheet_period_from), '%Y-%m-%d') AS fulldate_timesheet_period_from");
			//sqlSelectArray.push("DATE_FORMAT(FROM_UNIXTIME(payment_agent.created_at), '%Y-%m-%d') AS fulldate_created_at");
			//sqlSelectArray.push("DATE_FORMAT(FROM_UNIXTIME(payment_agent.lock_out_date), '%Y-%m-%d') AS fulldate_lock_out_date");
			
			sqlSelectArray.push("tale.id, tale.sort_code, tale.account_number");
			sqlSelectArray.push("timesheet.id, timesheet.contract_id");
			sqlSelectArray.push("contract.id, contract.contractor_id, contract.job_title, contract.cv_shared_level");
			
			
			sqlSelectArray.push('(CASE WHEN contract.cv_shared_level = '+config.JOB.JOB_SHARE_LEVEL_1+' then concat("Level 2 referral (",contract.job_title,")") WHEN contract.cv_shared_level = '+config.JOB.JOB_SHARE_LEVEL_2+' then concat("Level 3 referral (",contract.job_title,")") ELSE concat("Direct referral (",contract.job_title,")") END) AS TITLE_CONTRACTOR_REFERRAL');
			
			sqlSelectArray.push("user.id, user.full_name");
					
			sqlJoinArray.push("LEFT JOIN tale ON tale.id = payment_agent.tale_id");
			sqlJoinArray.push("LEFT JOIN timesheet ON timesheet.id = payment_agent.timesheet_id");
			sqlJoinArray.push("LEFT JOIN contract ON contract.id = timesheet.contract_id");
			sqlJoinArray.push("LEFT JOIN user ON user.id = contract.contractor_id");
			
			sqlQueryWhereArray.push(" WHERE payment_agent.agent_id = "+pool.escape(user_id));
			sqlQueryWhereArray.push("DATE_FORMAT(FROM_UNIXTIME(payment_agent.created_at), '%Y-%m-%d') > DATE_SUB(now(), INTERVAL "+config.PAYMENT_AGENT.TRANSACTION_HISTORY_TIME_LIMIT+")");
			
			sqlSelect		=	sqlSelectArray.join(', ');			
			sqlJoin			=	sqlJoinArray.join(' ');			
			sqlQueryWhere	=	sqlQueryWhereArray.join(' AND ');	
			
			var sqlQuery	=	sqlSelect + sqlFromTable + sqlJoin + sqlQueryWhere + sqlOrderBy;		
			
			//console.log('sqlQuery = '+sqlQuery);
				
			pool.getConnection(function(error, connection) {									
				// Use the database connection
				var options = {sql: sqlQuery, nestTables: "_"};
				connection.query(options, function (error, results, fields) { 
				// And done with the database connection.
					connection.release();

					if (error) { 
						throw error; 
					} else {

						if(!results) {
							return callback(null, null);
						} else {
							//console.log(results);
							return callback(null, results);
						}			
						return callback(null, null);
					}
					// Don't use the connection here, it has been returned to the pool.
				});
			});
		},
		//=================================================================
		/* 
		Function to create payment request from an agent to Admin.
		*/
		/*
		createPaymentRequest: function(callback) {
			
			var user_id 				= 	AuthenticUser.id;
			var payment_agent_ids		=	[];
			var commission_amount_sum	=	0;
			var tale;
			
			TaleModel.getTaleDetailByUserId(function(error, results) {
				
				console.log(results);
												
				if (error) {    
					throw error;
				} else {
					if(!results) {
						return callback(null, null);
					} else {
						//console.log(results);
						//console.log('results_tale = '+JSON.stringify(results,0,2));
						//console.log(results[0]);
						//console.log(results.length);
						//console.log(results[0].tale['sort_code']);
						//return callback(null, results);
						if(results.length) {
							
							tale = results[0].tale;
							//console.log('tale = '+tale);
							//console.log('tale = '+JSON.stringify(tale,0,2));
							//console.log('sort_code = '+tale.sort_code);
							
							var sqlSelectArray 		= 	[];			
							var sqlJoinArray 		= 	[];
							var sqlQueryWhereArray 	= 	[];
							
							var sqlSelect		 	= 	'';
							var sqlFromTable		= 	'';
							var sqlJoin		 		= 	'';			
							var sqlQueryWhere		=	'';
							var sqlOrderBy			=	'';
							
							sqlFromTable			=	" FROM payment_agent ";
							sqlOrderBy				=	" ORDER BY payment_agent.id DESC ";
							
							sqlSelectArray.push("SELECT payment_agent.id, payment_agent.debit_credit_agent, payment_agent.created_at, payment_agent.timesheet_id, payment_agent.commission_amount, payment_agent.status_payment_request, payment_agent.status_payment_paid");
											
							sqlQueryWhereArray.push(" WHERE payment_agent.agent_id = "+pool.escape(user_id));
							sqlQueryWhereArray.push("payment_agent.debit_credit_agent = "+pool.escape(config.params.DEBIT_CREDIT_C));
							sqlQueryWhereArray.push("payment_agent.status_payment_request IS "+pool.escape(config.PAYMENT_AGENT.STATUS_PAYMENT_REQUEST_PENDING));
							sqlQueryWhereArray.push("payment_agent.status_payment_paid IS "+pool.escape(config.PAYMENT_AGENT.STATUS_PAYMENT_PENDING));
							sqlQueryWhereArray.push("payment_agent.lock_out_date < UNIX_TIMESTAMP()");
							
							sqlSelect		=	sqlSelectArray.join(', ');			
							sqlJoin			=	sqlJoinArray.join(' ');			
							sqlQueryWhere	=	sqlQueryWhereArray.join(' AND ');	
							
							var sqlQuery	=	sqlSelect + sqlFromTable + sqlJoin + sqlQueryWhere + sqlOrderBy;		
							
							//console.log('sqlQuery = '+sqlQuery);
								
							pool.getConnection(function(error, connection) {									
								// Use the database connection
								var options = {sql: sqlQuery, nestTables: true};
								connection.query(options, function (error, results, fields) { 
								// And done with the database connection.
									connection.release();

									if (error) { 
										throw error; 
									} else {

										if(!results) {
											return callback(null, null);
										} else {
											//console.log(results);
											//console.log(results.length);
											
											if(results.length) {
												//-------------------------------------------------------
												for (var i=0;i<results.length;i++) {
													payment_agent_ids.push(results[i]['payment_agent'].id);
													commission_amount_sum	+=	parseFloat(results[i]['payment_agent'].commission_amount);
												}
												
												//console.log("payment_agent_ids = "+payment_agent_ids);
												//console.log("commission_amount_sum = "+commission_amount_sum);
												//-------------------------------------------------------
												PaymentAgentModel.createPaymentRequestDebitEntryCollectivelyForAgent(tale, commission_amount_sum, function(error, results) {
																
													if (error) {    
														throw error;
													} else {
														if(!results) {
															return callback(null, null);
														} else {
															//console.log(results);
															
															var payment_agent_id = parseInt(results);
															if(payment_agent_id>0) {
																
																PaymentAgentModel.updateStatusPaymentRequest(payment_agent_ids, function(error, results) {
																
																	if (error) {    
																		throw error;
																	} else {
																		if(!results) {
																			return callback(null, null);
																		} else {
																			//console.log(results);
																			//return callback(null, results);
																			DebitHistoryPaymentAgentModel.createLogOfUpdateStatusPaymentRequest(payment_agent_id, payment_agent_ids, function(error, results) {
																
																				if (error) {    
																					throw error;
																				} else {
																					if(!results) {
																						return callback(null, null);
																					} else {
																						//console.log(results);
																						return callback(null, results);
																					}
																				}								
																			});
																		}
																	}								
																});
															}
															//return callback(null, results);
														}
													}								
												});
												//-------------------------------------------------------
												
											
												//-------------------------------------------------------
												//-------------------------------------------------------
												//-------------------------------------------------------
											} else {
												return callback(null, null);
											}
										}			
										
									}
									// Don't use the connection here, it has been returned to the pool.
								});
							});
						} else {
							return callback(null, null);
						}
						
					}
				}								
			});
															
			
		},
		*/
		//=================================================================
		/* 
		Function to create payment request from an agent to Admin.
		*/
		createPaymentRequest: function(tale, callback) {
			
			var user_id 				= 	AuthenticUser.id;
			var payment_agent_ids		=	[];
			var commission_amount_sum	=	0;
			//var tale;
			
			//tale = results[0].tale;
			//console.log('createPaymentRequest');
			//console.log('tale = '+tale);
			//console.log('tale = '+JSON.stringify(tale,0,2));
			//console.log('sort_code = '+tale.sort_code);
			
			var sqlSelectArray 		= 	[];			
			var sqlJoinArray 		= 	[];
			var sqlQueryWhereArray 	= 	[];
			
			var sqlSelect		 	= 	'';
			var sqlFromTable		= 	'';
			var sqlJoin		 		= 	'';			
			var sqlQueryWhere		=	'';
			var sqlOrderBy			=	'';
			
			sqlFromTable			=	" FROM payment_agent ";
			sqlOrderBy				=	" ORDER BY payment_agent.id DESC ";
			
			sqlSelectArray.push("SELECT payment_agent.id, payment_agent.debit_credit_agent, payment_agent.created_at, payment_agent.timesheet_id, payment_agent.commission_amount, payment_agent.status_payment_request, payment_agent.status_payment_paid");
							
			sqlQueryWhereArray.push(" WHERE payment_agent.agent_id = "+pool.escape(user_id));
			sqlQueryWhereArray.push("payment_agent.debit_credit_agent = "+pool.escape(config.params.DEBIT_CREDIT_C));
			sqlQueryWhereArray.push("payment_agent.status_payment_request IS "+pool.escape(config.PAYMENT_AGENT.STATUS_PAYMENT_REQUEST_PENDING));
			sqlQueryWhereArray.push("payment_agent.status_payment_paid IS "+pool.escape(config.PAYMENT_AGENT.STATUS_PAYMENT_PENDING));
			sqlQueryWhereArray.push("payment_agent.lock_out_date < UNIX_TIMESTAMP()");
			
			sqlSelect		=	sqlSelectArray.join(', ');			
			sqlJoin			=	sqlJoinArray.join(' ');			
			sqlQueryWhere	=	sqlQueryWhereArray.join(' AND ');	
			
			var sqlQuery	=	sqlSelect + sqlFromTable + sqlJoin + sqlQueryWhere + sqlOrderBy;		
			
			//console.log('sqlQuery = '+sqlQuery);
				
			pool.getConnection(function(error, connection) {									
				// Use the database connection
				var options = {sql: sqlQuery, nestTables: true};
				connection.query(options, function (error, results, fields) { 
				// And done with the database connection.
					connection.release();

					if (error) { 
						throw error; 
					} else {

						if(!results) {
							return callback(null, null);
						} else {
							//console.log(results);
							//console.log(results.length);
							
							if(results.length) {
								//-------------------------------------------------------
								for (var i=0;i<results.length;i++) {
									payment_agent_ids.push(results[i]['payment_agent'].id);
									commission_amount_sum	+=	parseFloat(results[i]['payment_agent'].commission_amount);
								}
								
								//console.log("payment_agent_ids = "+payment_agent_ids);
								//console.log("commission_amount_sum = "+commission_amount_sum);
								//-------------------------------------------------------
								PaymentAgentModel.createPaymentRequestDebitEntryCollectivelyForAgent(tale, commission_amount_sum, function(error, results) {
												
									if (error) {    
										throw error;
									} else {
										if(!results) {
											return callback(null, null);
										} else {
											//console.log(results);
											
											var payment_agent_id = parseInt(results);
											if(payment_agent_id>0) {
												
												PaymentAgentModel.updateStatusPaymentRequest(payment_agent_ids, function(error, results) {
												
													if (error) {    
														throw error;
													} else {
														if(!results) {
															return callback(null, null);
														} else {
															//console.log(results);
															//return callback(null, results);
															DebitHistoryPaymentAgentModel.createLogOfUpdateStatusPaymentRequest(payment_agent_id, payment_agent_ids, function(error, results) {
												
																if (error) {    
																	throw error;
																} else {
																	if(!results) {
																		return callback(null, null);
																	} else {
																		//console.log(results);
																		return callback(null, results);
																	}
																}								
															});
														}
													}								
												});
											}
											//return callback(null, results);
										}
									}								
								});
								//-------------------------------------------------------
								
							
								//-------------------------------------------------------
								//-------------------------------------------------------
								//-------------------------------------------------------
							} else {
								return callback(null, null);
							}
						}			
						
					}
					// Don't use the connection here, it has been returned to the pool.
				});
			});
						
															
			
		},
		//=================================================================
		/* 
		Function to create payment request debit entry collectively for and agent
		*/
		createPaymentRequestDebitEntryCollectivelyForAgent: function(tale, commission_amount, callback) {
					
			//console.log('user_id = '+user_id);			
			var user_id 			= 	AuthenticUser.id;
			
			if((typeof user_id !== 'undefined' && user_id !== null && user_id>0)) {
				
				//-------------------------------------------------------
				var sqlQueryInsertColumnArray	= 	[];	
				var sqlQueryWhereArray 			= 	[];		
				var sqlQueryUpdateTable		 	= 	'';
				var sqlQueryUpdateColumn		= 	'';
				var sqlQueryWhere				=	'';
				var sqlQuery					=	'';
				
				sqlQueryInsertTable				=	" INSERT INTO payment_agent SET ";
				
				sqlQueryInsertColumnArray.push("payment_agent.debit_credit_agent = "+pool.escape(config.params.DEBIT_CREDIT_D));
				sqlQueryInsertColumnArray.push("payment_agent.tale_id = "+pool.escape(tale.id));
				sqlQueryInsertColumnArray.push("payment_agent.created_by = "+pool.escape(user_id));
				sqlQueryInsertColumnArray.push("payment_agent.agent_id = "+pool.escape(user_id));
				sqlQueryInsertColumnArray.push("payment_agent.commission_amount = "+pool.escape(commission_amount));
				sqlQueryInsertColumnArray.push("payment_agent.created_at = UNIX_TIMESTAMP()");
											
				sqlQueryInsertColumn		=	sqlQueryInsertColumnArray.join(', ');			
				sqlQueryWhere				=	sqlQueryWhereArray.join(' AND ');		
				sqlQuery					=	sqlQueryInsertTable + sqlQueryInsertColumn;
				
				//console.log('sqlQuery = '+sqlQuery);

				pool.getConnection(function(error, connection) {									
					// Use the database connection
					connection.query(sqlQuery, function (error, results, fields) {
					// And done with the database connection.
						connection.release();

						if (error) { 
							throw error; 
						} else {
							
							if(!results) {
								return callback(null, null);
							} else {						
								
								var payment_agent_id = parseInt(results.insertId);
								
								if(payment_agent_id) {
									return callback(null, payment_agent_id);
								} 
							}
						}
						// Don't use the connection here, it has been returned to the pool.
					});
				});
				//-------------------------------------------------------
				
			} else {
				return callback(null, null);
			}		 
		},
		//=================================================================
		/* 
		Function to update the status of credit entries as PAYMENT REQUEST SENT by ids.
		*/
		updateStatusPaymentRequest: function(payment_agent_ids, callback) {
						
			var user_id 			= 	AuthenticUser.id;
			
			if((typeof user_id !== 'undefined' && user_id !== null && user_id>0)) {
				
				var sqlQueryUpdateColumnArray	= 	[];			
				var sqlQueryWhereArray 			= 	[];			
				var sqlQueryUpdateTable		 	= 	'';
				var sqlQueryUpdateColumn		= 	'';
				var sqlQueryWhere				=	'';
				var sqlQuery					=	'';											
											
				sqlQueryUpdateTable				=	" UPDATE payment_agent SET ";
							
				sqlQueryUpdateColumnArray.push("payment_agent.status_payment_request = "+pool.escape(config.PAYMENT_AGENT.STATUS_PAYMENT_REQUEST_SENT));
				sqlQueryUpdateColumnArray.push("payment_agent.updated_by = "+pool.escape(user_id));
				sqlQueryUpdateColumnArray.push("payment_agent.updated_at = UNIX_TIMESTAMP()");
								
				sqlQueryWhereArray.push(" WHERE payment_agent.id IN ("+pool.escape(payment_agent_ids)+")");
				sqlQueryWhereArray.push("payment_agent.agent_id = "+pool.escape(user_id));		
				
				sqlQueryUpdateColumn		=	sqlQueryUpdateColumnArray.join(', ');			
				sqlQueryWhere				=	sqlQueryWhereArray.join(' AND ');		
				sqlQuery					=	sqlQueryUpdateTable + sqlQueryUpdateColumn + sqlQueryWhere;
				
				//console.log('sqlQuery = '+sqlQuery);
							
				pool.getConnection(function(error, connection) {									
					// Use the database connection
					connection.query(sqlQuery, function (error, results, fields) {
					// And done with the database connection.
						connection.release();

						if (error) { 
							throw error; 
						} else {							
							if(!results) {
								return callback(null, null);
							} else {						
								return callback(null, results.affectedRows);
							}			
							//return callback(null, null);
						}

						// Don't use the connection here, it has been returned to the pool.
					});
				});
			}	
			else {
				return callback(null, null);
			}		
		},
		
		//=================================================================
		
		//=================================================================
		
		//=================================================================
		
		//=================================================================
		
		//=================================================================
		
		//=================================================================
		
		//=================================================================
	};	
	
	
	
	
	module.exports = PaymentAgentModel;  


