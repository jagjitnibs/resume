	// Include the public functions from 'helpers.js'
	var helpers 			= 	require('../common/components/helpers');
	
	
	var NotificationModel = {  
		  
		//=================================================================
		/* 
		Function to get active news list.
		*/
		getNotificationTemplate: function(callback) {
			
			
			var siteName	= config.params.SITE_NAME;
			
			var listNotificationTemplate;
			//listNotificationTemplate[1] = "Mango";
			//listNotificationTemplate[2] = "Apple";
			
			/*
			var listNotificationTemplate	=	{
													1:"John", 
													2:"Doe", 
													3:"hi", 
													
												};
			*/	
			
			/*	
			listNotificationTemplate	=	{
												'1' : 	"1-<%%NotificationFindText%%> has applied for the <%%NotificationJobTitle%%> job and sent you a CV to submit for expert review.", 
												'2' : 	"2-<%%NotificationFindText%%> has just shared a new job with you. If you're not looking to apply, you can still share and earn big cash rewards.",
												'3' : 	"3-<%%NotificationFindText%%> shared a new job opportunity.",
												'4' : 	"4-<%%NotificationFindText%%>",
												'5' : 	"5-<%%NotificationFindText%%> has also shared the <%%NotificationJobTitle%%> job with <%%NotificationJobInviteCount%%> connection(s).",
												'6' : 	"6-Job <%%NotificationJobTitle%%> has been shared within <%%NotificationUserJobShareLevel_1%%>'s network.",
												'7' : 	"7-<%%NotificationFindText%%> has submitted CV(s) for the <%%NotificationJobTitle%%> job to Expert Review.",
												'11' : "11-The exclusivity period for your <%%NotificationFindText%%> job will expire in 24 hours and may be broadcasted.",
												'12' :	"12-"+siteName+" broadcasted a previously exclusive job with all Associates. If you're not looking to apply, you can still share and earn big cash rewards.",
												'13' : "13-Hi, a new job <%%NotificationJobTitle%%> has been added by "+siteName+" and sent to all Associates.",
												'14' : "14-Hi, your CV for the <%%NotificationJobTitle%%> job has been submitted for expert review.",
												'15' : "15-Hi, sorry on this occasion you were not shortlisted for the <%%NotificationJobTitle%%> job.",
												'16' : "16-<%%NotificationJobTitle%%>",
												'17' : "17-Hi, sorry on this occasion you were not shortlisted for the <%%NotificationJobTitle%%> job.",
												'18' : "18-Hi, good news you have been shortlisted for the <%%NotificationJobTitle%%> job and your CV has been submitted to the Hiring Manager.",
												'19' : "19-<%%NotificationJobTitle%%>",
												'20' : "20-<%%NotificationJobTitle%%>",
												'21' : "21-Hi, sorry on this occasion you were not successful in landing the <%%NotificationJobTitle%%> job.",
												'22' : "22-Hi, fantastic news you have been successful in landing the <%%NotificationJobTitle%%> job, we will be in touch. Well Done!",
												'23' : "23-Hi, sorry on this occasion you were not successful in landing the <%%NotificationJobTitle%%> job.",
												'24' : "24-Hi, fantastic news you were in a successful referral chain for the <%%NotificationJobTitle%%> job, your cash rewards will be hitting your fund every month!",
												'25' :	"25-Hi, the <%%NotificationJobTitle%%> job has now been filled by another referral chain. Thanks for trying, better luck next time.",
												'26' :	"26-"+siteName+" shared a new job with all Associates. If you're not looking to apply, you can still share and earn big cash rewards.",
												'27' :	"27-<%%NotificationFindText%%> added and shared a new job with you. If you're not looking to apply, you can still share and earn big cash rewards.",
												'28' :	"28-Hi, great news! You have just earned some cash rewards in your fund!",
											};
			*/	

			listNotificationTemplate	=	{
												'1' :	"<%%NotificationFindText%%> has applied for the <%%NotificationJobTitle%%> job and sent you a CV to submit for expert review.", 
												'2' :  	"<%%NotificationFindText%%> has just shared a new job with you. If you're not looking to apply, you can still share and earn big cash rewards.",
												'3' :  	"<%%NotificationFindText%%> shared a new job opportunity.",
												'4' :  	"<%%NotificationFindText%%>",
												'5' :  	"<%%NotificationFindText%%> has also shared the <%%NotificationJobTitle%%> job with <%%NotificationJobInviteCount%%> connection(s).",
												'6' :  	"Job <%%NotificationJobTitle%%> has been shared within <%%NotificationUserJobShareLevel_1%%>'s network.",
												'7' :  	"<%%NotificationFindText%%> has submitted CV(s) for the <%%NotificationJobTitle%%> job to Expert Review.",
												'11' : 	"The exclusivity period for your <%%NotificationFindText%%> job will expire in 24 hours and may be broadcasted.",
												'12' : 	siteName+" broadcasted a previously exclusive job with all Associates. If you're not looking to apply, you can still share and earn big cash rewards.",
												'13' : 	"Hi, a new job <%%NotificationJobTitle%%> has been added by "+siteName+" and sent to all Associates.",
												'14' : 	"Hi, your CV for the <%%NotificationJobTitle%%> job has been submitted for expert review.",
												'15' : 	"Hi, sorry on this occasion you were not shortlisted for the <%%NotificationJobTitle%%> job.",
												'16' : 	"<%%NotificationJobTitle%%>",
												'17' : 	"Hi, sorry on this occasion you were not shortlisted for the <%%NotificationJobTitle%%> job.",
												'18' : 	"Hi, good news you have been shortlisted for the <%%NotificationJobTitle%%> job and your CV has been submitted to the Hiring Manager.",
												'19' : 	"<%%NotificationJobTitle%%>",
												'20' : 	"<%%NotificationJobTitle%%>",
												'21' : 	"Hi, sorry on this occasion you were not successful in landing the <%%NotificationJobTitle%%> job.",
												'22' : 	"Hi, fantastic news you have been successful in landing the <%%NotificationJobTitle%%> job, we will be in touch. Well Done!",
												'23' : 	"Hi, sorry on this occasion you were not successful in landing the <%%NotificationJobTitle%%> job.",
												'24' : 	"Hi, fantastic news you were in a successful referral chain for the <%%NotificationJobTitle%%> job, your cash rewards will be hitting your fund every month!",
												'25' : 	"Hi, the <%%NotificationJobTitle%%> job has now been filled by another referral chain. Thanks for trying, better luck next time.",
												'26' : 	siteName+" shared a new job with all Associates. If you're not looking to apply, you can still share and earn big cash rewards.",
												'27' : 	"<%%NotificationFindText%%> added and shared a new job with you. If you're not looking to apply, you can still share and earn big cash rewards.",
												'28' : 	"Hi, great news! You have just earned some cash rewards in your fund!",
											};
											
			return callback(null, listNotificationTemplate);
		},
		//=================================================================
		/* 
		Function to get active news list.
		*/
		getUnreadNotificationCountById: function(id, callback) {
			
			var user_id 			= 	AuthenticUser.id;
			
			if (typeof user_id === 'undefined' || user_id === null || parseInt(user_id)<=0) {
				user_id	=	0;
			} else {
				user_id = parseInt(user_id);
			}
			
			var sqlQueryUpdateColumnArray	= 	[];			
			var sqlQueryWhereArray 			= 	[];			
			var sqlQueryUpdateTable		 	= 	'';
			var sqlQueryUpdateColumn		= 	'';
			var sqlQueryWhere				=	'';
			var sqlQuery					=	'';
			
			var sqlSelectArray 				= 	[];			
			var sqlJoinArray 				= 	[];
			var sqlQueryWhereArray 			= 	[];
			
			var sqlSelect		 			= 	'';
			var sqlFromTable				= 	'';
			var sqlJoin		 				= 	'';			
			var sqlQueryWhere				=	'';
			var sqlOrderBy					=	'';
			
			sqlFromTable					=	" FROM notification ";
			sqlOrderBy						=	"";
			
			sqlSelectArray.push("SELECT COUNT(notification.id) AS count_notification");
			
			sqlQueryWhereArray.push(" WHERE notification.id > "+pool.escape(id));
			sqlQueryWhereArray.push("notification.recipient_user_id = "+pool.escape(user_id));
			sqlQueryWhereArray.push("notification.status = "+pool.escape(config.NOTIFICATION.STATUS.ACTIVE));
						
			sqlQueryWhere 	= 	sqlQueryWhereArray.join(' AND ');						
			sqlSelect		=	sqlSelectArray.join(', ');			
			sqlJoin			=	sqlJoinArray.join(' ');			
			sqlQueryWhere	=	sqlQueryWhereArray.join(' AND ');

			var sqlQuery	=	sqlSelect + sqlFromTable + sqlJoin + sqlQueryWhere + sqlOrderBy;	
			
			//console.log('sqlQuery = '+sqlQuery);
			
			
			pool.getConnection(function(error, connection) {									
				// Use the database connection
				var options = {sql: sqlQuery, nestTables: false};
				connection.query(options, function (error, results, fields) { 
				// And done with the database connection.
					connection.release();

					if (error) { 
						throw error; 
					} else {

						if(!results) {
							return callback(null, null);
						} else {
							//console.log(results);
							return callback(null, results);
						}			
						return callback(null, null);
					}
					// Don't use the connection here, it has been returned to the pool.
				});
			});
		},
		//=================================================================
		/* 
		Function to get list of broadcasted jobs by user ID
		*/
		/*
		getNotificationListByUserId_____________________20180531: function(notification_id, callback) {
			
			var user_id 			= 	AuthenticUser.id;
			//console.log('user_id = '+user_id);
			if (typeof user_id === 'undefined' || user_id === null || parseInt(user_id)<=0) {
				user_id	=	0;
			} else {
				user_id = parseInt(user_id);
			}
			
			if (typeof notification_id === 'undefined' || notification_id === null || parseInt(notification_id)<=0) {
				notification_id	=	0;
			} else {
				notification_id = parseInt(notification_id);
			}

			var sqlSelectArray 		= 	[];			
			var sqlJoinArray 		= 	[];
			var sqlQueryWhereArray 	= 	[];
			
			var sqlSelect		 	= 	'';
			var sqlFromTable		= 	'';
			var sqlJoin		 		= 	'';			
			var sqlQueryWhere		=	'';
			var sqlOrderBy			=	'';
			var sqlLimit			=	' LIMIT '+config.params.SQL_LIMIT_NOTIFICATION;
			//var sqlLimit			=	' LIMIT 500 ';
			//var sqlOffset			=	' OFFSET '+offset;
			//var sqlLimit			=	'  ';
			var sqlOffset			=	'  ';
			
			sqlFromTable			=	' FROM views_notification ';
			//sqlOrderBy			=	' ORDER BY job.id DESC ';
			sqlOrderBy				=	' ORDER BY views_notification.notification_id DESC ';
			
			sqlSelectArray.push("SELECT views_notification.*");
								
			sqlQueryWhereArray.push(" WHERE views_notification.notification_id > "+pool.escape(notification_id));
			sqlQueryWhereArray.push(" views_notification.notification_recipient_user_id = "+pool.escape(user_id));
			//sqlQueryWhereArray.push("job.recipient_user_id > UNIX_TIMESTAMP()");
			//sqlQueryWhereArray.push("job.status_delete IS "+pool.escape(config.JOB.STATUS_DELETE_NO));
			//sqlQueryWhereArray.push("job.status_close_by_admin IS "+pool.escape(config.JOB.STATUS_CLOSE_BY_ADMIN.NO));
			//sqlQueryWhereArray.push("job.status_close_by_admin_parent_job IS "+pool.escape(config.JOB.STATUS_CLOSE_BY_ADMIN_PARENT_JOB.NO));
			//sqlQueryWhereArray.push("job.user_role_id IN ("+pool.escape(config.USER.ROLE_SUPERADMIN)+","+pool.escape(config.USER.ROLE_ADMIN)+","+pool.escape(config.USER.ROLE_AGENT)+")");
						
			sqlQueryWhere 	= 	sqlQueryWhereArray.join(' AND ');						
			sqlSelect		=	sqlSelectArray.join(', ');			
			sqlJoin			=	sqlJoinArray.join(' ');			
			sqlQueryWhere	=	sqlQueryWhereArray.join(' AND ');

			var sqlQuery	=	sqlSelect + sqlFromTable + sqlJoin + sqlQueryWhere + sqlOrderBy + sqlLimit + sqlOffset;		
			
			console.log('sqlQuery = '+sqlQuery);	
			
			pool.getConnection(function(error, connection) {									
				// Use the database connection
				var options = {sql: sqlQuery, nestTables: '_'};
				connection.query(options, function (error, results, fields) {
				// And done with the database connection.
					connection.release();

					if (error) { 
						throw error; 
					} else {
						if(!results) {
							return callback(null, null);
						} else {
							//console.log('Broadcast Jobs = '+ JSON.stringify(results, null, 2));
							return callback(null, results);
						}			
						return callback(null, null);
					}

					// Don't use the connection here, it has been returned to the pool.
				});
			});				
		},
		*/
		//=================================================================
		/* 
		Function to get list of broadcasted jobs by user ID
		*/
		getNotificationListByUserId: function(notification_id, callback) {
			
			var user_id 			= 	AuthenticUser.id;
			var device_type 		= 	AuthenticUser.device_type;
			
			var show_on_mobile;
			var show_on_web			=	config.NOTIFICATION.SHOW_ON_WEB;
			var show_on_ios			=	config.NOTIFICATION.SHOW_ON_IOS;
			var show_on_android		=	config.NOTIFICATION.SHOW_ON_ANDROID;
			var show_job_related	=	config.NOTIFICATION.SHOW_JOB_RELATED;
			
			//console.log('user_id = '+user_id);
			//console.log('device_type = '+device_type);
			
			show_on_mobile	=	show_on_ios;
			
			if(device_type == config.USER.DEVICE_TYPE_ANDROID) {
				show_on_mobile	=	show_on_android;
			} 
			
			if (typeof user_id === 'undefined' || user_id === null || parseInt(user_id)<=0) {
				user_id	=	0;
			} else {
				user_id = parseInt(user_id);
			}
			
			if (typeof notification_id === 'undefined' || notification_id === null || parseInt(notification_id)<=0) {
				notification_id	=	0;
			} else {
				notification_id = parseInt(notification_id);
			}

			var sqlSelectArray 		= 	[];			
			var sqlJoinArray 		= 	[];
			var sqlQueryWhereArray 	= 	[];
			
			var sqlSelect		 	= 	'';
			var sqlFromTable		= 	'';
			var sqlJoin		 		= 	'';			
			var sqlQueryWhere		=	'';
			var sqlOrderBy			=	'';
			var sqlLimit			=	' LIMIT '+config.params.SQL_LIMIT_NOTIFICATION;
			//var sqlLimit			=	' LIMIT 500 ';
			//var sqlOffset			=	' OFFSET '+offset;
			//var sqlLimit			=	'  ';
			var sqlOffset			=	'  ';
			
			sqlFromTable			=	' FROM views_notification ';
			//sqlOrderBy			=	' ORDER BY job.id DESC ';
			sqlOrderBy				=	' ORDER BY views_notification.notification_id ASC ';
			
			sqlSelectArray.push("SELECT views_notification.*");
								
			sqlQueryWhereArray.push(" WHERE views_notification.notification_id > "+pool.escape(notification_id));
			sqlQueryWhereArray.push(" views_notification.notification_recipient_user_id = "+pool.escape(user_id));
			//sqlQueryWhereArray.push(" views_notification.notification_type IN ("+pool.escape(show_on_mobile)+")");
			//sqlQueryWhereArray.push(" (((views_notification.notification_type IN ("+pool.escape(show_job_related)+")) AND (views_notification.job_expiry_time> UNIX_TIMESTAMP())) OR ((views_notification.notification_type=4) AND (views_notification.job_expiry_time IS NULL)) )");
						
			sqlQueryWhere 	= 	sqlQueryWhereArray.join(' AND ');						
			sqlSelect		=	sqlSelectArray.join(', ');			
			sqlJoin			=	sqlJoinArray.join(' ');			
			sqlQueryWhere	=	sqlQueryWhereArray.join(' AND ');

			var sqlQuery	=	sqlSelect + sqlFromTable + sqlJoin + sqlQueryWhere + sqlOrderBy + sqlLimit + sqlOffset;		
			
			//console.log('sqlQuery = '+sqlQuery);	
			
			pool.getConnection(function(error, connection) {									
				// Use the database connection
				var options = {sql: sqlQuery, nestTables: '_'};
				connection.query(options, function (error, results, fields) {
				// And done with the database connection.
					connection.release();

					if (error) { 
						throw error; 
					} else {
						if(!results) {
							return callback(null, null);
						} else {
							//console.log('Broadcast Jobs = '+ JSON.stringify(results, null, 2));
							return callback(null, results);
						}			
						return callback(null, null);
					}

					// Don't use the connection here, it has been returned to the pool.
				});
			});				
		},
		//=================================================================
		//=================================================================
		//=================================================================
		//=================================================================
	
	};	
	module.exports = NotificationModel;