	var JobFilterModel	=	{
		
		//getJobFilterByUserId: function (user_id, callback) {
		getJobFilterByUserId: function (callback) {
			
			var user_id 			= 	AuthenticUser.id;
			
			var sqlSelectArray 		= 	[];			
			var sqlJoinArray 		= 	[];
			var sqlQueryWhereArray 	= 	[];
			
			var sqlSelect		 	= 	'';
			var sqlFromTable		= 	'';
			var sqlJoin		 		= 	'';			
			var sqlQueryWhere		=	'';
			var sqlOrderBy			=	'';			
			
			sqlFromTable			=	" FROM job_filter ";
			
			sqlSelectArray.push("SELECT job_filter.id, job_filter.user_id, job_filter.industry_sector_id, job_filter.job_type, job_filter.keyword, job_filter.rate_min, job_filter.rate_max, job_filter.location, job_filter.latitude, job_filter.longitude, job_filter.distance, job_filter.filter_invite_jobs, job_filter.created_at, job_filter.updated_at");
			//sqlSelectArray.push("industry_sector.title AS  industry_sector_title");			
			sqlSelectArray.push("industry_sector.id, industry_sector.title");			
			
			sqlJoinArray.push("LEFT JOIN industry_sector ON job_filter.industry_sector_id = industry_sector.id");
				
			sqlQueryWhereArray.push(" WHERE job_filter.user_id="+pool.escape(user_id));
			
			sqlSelect		=	sqlSelectArray.join(', ');			
			sqlJoin			=	sqlJoinArray.join(' ');			
			sqlQueryWhere	=	sqlQueryWhereArray.join(' AND ');		
			
			var sqlQuery	=	sqlSelect + sqlFromTable + sqlJoin + sqlQueryWhere + sqlOrderBy;		
			
			//console.log('sqlQuery = '+sqlQuery);
			/*
			dbConnection.query(sqlQuery, function (error, results, fields) {
				if (error) { 
					throw error; 
				} else {

					if(!results) {
						return callback(null, null);
					} else {
						return callback(null, results);
					}			
					return callback(null, null);
				}
			});
			*/
			
			pool.getConnection(function(error, connection) {									
				// Use the database connection

				var options = {sql: sqlQuery, nestTables: true};
				connection.query(options, function (error, results, fields) {
					
				//connection.query(sqlQuery, function (error, results, fields) {
					
				// And done with the database connection.
					connection.release();

					if (error) { 
						throw error; 
					} else {

						if(!results) {
							return callback(null, null);
						} else {
							return callback(null, results);
						}			
						return callback(null, null);
					}

					// Don't use the connection here, it has been returned to the pool.
				});
			});
		},
  
		/*	
		bar: function (req, res, next) {
			return self.foo();
		}
		*/
	};
	
	module.exports = JobFilterModel;
	