	// Include the public functions from 'helpers.js'
	var helpers 			= 	require('../common/components/helpers');
	
	
	var UserModel = {  
		  
		/* 
		Function to get user by token.
		*/
		findByToken: function(token, callback) {
			
			var sqlQuery	=	"SELECT user.*  FROM user WHERE user.auth_key="+pool.escape(token)+" limit 1";
			
			//console.log('sqlQuery = '+sqlQuery);
			/*--------
			dbConnection.query(sqlQuery, function (error, results, fields) {
				if (error) { 
					throw error; 
				} else {
					//console.log(results);
					//console.log(results.length);
					if(!results.length) {
						console.log('Invalid Token');
						return callback(null, null);
					} else {
						return callback(null, results);
						//return cb(null, results[0]);
					}
					
					return callback(null, null);
				}
			}); 
			*/
			
			pool.getConnection(function(error, connection) {									
				// Use the database connection
				var options = {sql: sqlQuery, nestTables: true};
				connection.query(options, function (error, results, fields) {
				// And done with the database connection.
					connection.release();

					if (error) { 
						throw error; 
					} else {
						//console.log(results);
						//console.log(results.length);
						if(!results.length) {
							console.log('Invalid Token');
							return callback(null, null);
						} else {
							global.AuthenticUser	=	results[0].user;  // Set as a global variable.
							return callback(null, results);
							//return cb(null, results[0]);
						}					
						return callback(null, null);
					}

					// Don't use the connection here, it has been returned to the pool.
				});
			});
								
		},
		
		
		/* 
		Function to get user profile.
		*/
		getUserProfileByUserId: function(user_id, callback) {
			
			//console.log('getUserProfileByUserId');
				
			var sqlQueryUpdateColumnArray	= 	[];			
			var sqlQueryWhereArray 			= 	[];			
			var sqlQueryUpdateTable		 	= 	'';
			var sqlQueryUpdateColumn		= 	'';
			var sqlQueryWhere				=	'';
			var sqlQuery					=	'';
			
			var sqlSelectArray 		= 	[];			
			var sqlJoinArray 		= 	[];
			var sqlQueryWhereArray 	= 	[];
			
			var sqlSelect		 	= 	'';
			var sqlFromTable		= 	'';
			var sqlJoin		 		= 	'';			
			var sqlQueryWhere		=	'';
			var sqlOrderBy			=	'';
			
			sqlFromTable			=	" FROM user ";
			
			sqlSelectArray.push("SELECT user.id, user.role, user.company_id, user.industry_sector_id, user.sub_industry_sector_id, user.sector_role_id, user.username, user.status_contact_list, user.first_name, user.last_name, user.full_name, user.mobile, user.image, user.payment_expire_time, user.location, user.latitude, user.longitude, user.organization, user.job_type, user.date_availability");
			sqlSelectArray.push("industry_sector.id, industry_sector.title");
			sqlSelectArray.push("sub_industry_sector.id, sub_industry_sector.title");
			sqlSelectArray.push("sector_role.id, sector_role.title");
			
			sqlJoinArray.push("LEFT JOIN industry_sector ON industry_sector.id = user.industry_sector_id");
			sqlJoinArray.push("LEFT JOIN sub_industry_sector ON sub_industry_sector.id = user.sub_industry_sector_id");
			sqlJoinArray.push("LEFT JOIN sector_role ON sector_role.id = user.sector_role_id");
			
			sqlQueryWhereArray.push(" WHERE user.id = "+pool.escape(user_id));
				
			sqlQueryWhere 	= 	sqlQueryWhereArray.join(' AND ');						
			sqlSelect		=	sqlSelectArray.join(', ');			
			sqlJoin			=	sqlJoinArray.join(' ');			
			sqlQueryWhere	=	sqlQueryWhereArray.join(' AND ');

			var sqlQuery	=	sqlSelect + sqlFromTable + sqlJoin + sqlQueryWhere + sqlOrderBy;		

			//console.log('sqlQuery = '+sqlQuery);				
			/*
			dbConnection.query(sqlQuery, function (error, results, fields) {
				
				if (error) { 
					throw error; 
				} else {
					
					//console.log('aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa');
					//console.log(JSON.stringify(results));
					//console.log('aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa');
					
					if(!results.length) {
						return callback(null, null);
					} else {
						return callback(null, results);
					}			
					return callback(null, null);
				}
			});
			*/
			
			pool.getConnection(function(error, connection) {									
				var options = {sql: sqlQuery, nestTables: true};
				connection.query(options, function (error, results, fields) {
				// And done with the database connection.
					connection.release();

					if (error) { 
						throw error; 
					} else {
						if(!results) {
							return callback(null, null);
						} else {
							return callback(null, results);
						}			
						return callback(null, null);
					}

					// Don't use the connection here, it has been returned to the pool.
				});
			});
		},
		
		
		/* 
		Function to update user profile.
		*/
		profileUpdateByUserId: function(user_id, postData, callback) {
			
			//console.log('profileUpdateByUserId');
				
			//var first_name					=	postData.first_name;	
			//var last_name					=	postData.last_name;	
			var location					=	postData.location;	
			var latitude					=	postData.latitude;	
			var longitude					=	postData.longitude;	
			var organization				=	postData.organization;	
			var sub_industry_sector_id		=	postData.sub_industry_sector_id;	
			var sector_role_id				=	postData.sector_role_id;	
			var job_type					=	postData.job_type;	
			var date_availability			=	postData.date_availability;
			var filedata					=	postData.image;			
			
			//console.log('1111111');
			//console.log('filedata = '+filedata);
			
			
			if (typeof filedata !== 'undefined' && filedata !== null) {				
				var filesize_kb				 	=	helpers.sizeOfBase64EncodedString(filedata);
				//console.log('filesize_kb = '+filesize_kb);
				var filename				 	=	helpers.getRandomStringAlphaNumeric();
				var filetype				 	=	helpers.decodeBase64ImageType(filedata);				
				var image						=	filename+'.'+filetype;
				helpers.uploadImage(filename, filedata);			
			}		
			
				
			
			//var newDate 					= 	new Date(date_availability);	// Convert date to timestamp
			//var date_availability 			= 	newDate.getTime()/1000;			// Convert date to timestamp

			var sqlQueryUpdateColumnArray	= 	[];			
			var sqlQueryWhereArray 			= 	[];			
			var sqlQueryUpdateTable		 	= 	'';
			var sqlQueryUpdateColumn		= 	'';
			var sqlQueryWhere				=	'';
			var sqlQuery					=	'';
			
			sqlQueryUpdateTable				=	" UPDATE user SET ";
						
			//sqlQueryUpdateColumnArray.push("user.first_name = "+dbConnection.escape(first_name));
			//sqlQueryUpdateColumnArray.push("user.last_name = "+dbConnection.escape(last_name));
			//sqlQueryUpdateColumnArray.push("user.full_name = "+dbConnection.escape(first_name)+" "+dbConnection.escape(last_name));
			sqlQueryUpdateColumnArray.push("user.location = "+pool.escape(location));
			sqlQueryUpdateColumnArray.push("user.latitude = "+pool.escape(latitude));
			sqlQueryUpdateColumnArray.push("user.longitude = "+pool.escape(longitude));
			sqlQueryUpdateColumnArray.push("user.organization = "+pool.escape(organization));
			sqlQueryUpdateColumnArray.push("user.sub_industry_sector_id = "+pool.escape(sub_industry_sector_id));
			sqlQueryUpdateColumnArray.push("user.sector_role_id = "+pool.escape(sector_role_id));
			sqlQueryUpdateColumnArray.push("user.job_type = "+pool.escape(job_type));				
			//sqlQueryUpdateColumnArray.push("user.date_availability = "+dbConnection.escape(date_availability));
			
			if(job_type >= config.USER.SIGNUP_JOB_TYPE_PERMANENT) {
				sqlQueryUpdateColumnArray.push("user.date_availability = null");
			} else {
				sqlQueryUpdateColumnArray.push("user.date_availability = UNIX_TIMESTAMP("+pool.escape(date_availability)+")");
			}	
			
			sqlQueryUpdateColumnArray.push("user.updated_at = UNIX_TIMESTAMP()");
			
			
			if (typeof filedata !== 'undefined' && filedata !== null) {
				sqlQueryUpdateColumnArray.push("user.image = "+pool.escape(image));
			}
			
			sqlQueryWhereArray.push(" WHERE user.id = "+pool.escape(user_id));		
			
			sqlQueryUpdateColumn		=	sqlQueryUpdateColumnArray.join(', ');			
			sqlQueryWhere				=	sqlQueryWhereArray.join(' AND ');		
			sqlQuery					=	sqlQueryUpdateTable + sqlQueryUpdateColumn + sqlQueryWhere;
			
			//console.log('sqlQuery = '+sqlQuery);
			
			pool.getConnection(function(error, connection) {									
				// Use the database connection
				connection.query(sqlQuery, function (error, results, fields) {
				// And done with the database connection.
					connection.release();

					if (error) { 
						throw error; 
					} else {
						
						if(!results) {
							return callback(null, null);
						} else {						
							return callback(null, results);
						}			
						return callback(null, null);
					}

					// Don't use the connection here, it has been returned to the pool.
				});
			});
		},
		
	
	};	
	module.exports = UserModel;