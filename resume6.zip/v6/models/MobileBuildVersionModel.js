	// Include the public functions from 'helpers.js'
	var helpers 			= 	require('../common/components/helpers');
	
	
	var MobileBuildVersionModel = {  
		  
		/* 
		Function to get bank account details by id (primary key).
		*/
		
		getLatestBuildVersionDetails: function(postData, callback) {
			
			//console.log('getLatestBuildVersionDetails');
				
			var user_id 			= 	AuthenticUser.id;
			var build_version		=	postData.build_version;	
			var device_type			=	postData.device_type;	

			if(device_type == config.USER.DEVICE_TYPE_IOS) {
				var dbTable	=	config.params.DB_TABLE_MOBILE_BUILD_VERSION_IOS;
			} else if(device_type == config.USER.DEVICE_TYPE_ANDROID) {
				var dbTable	=	config.params.DB_TABLE_MOBILE_BUILD_VERSION_ANDROID;
			} else {
				return callback(null, null);
			}	
			
			var sqlSelectArray 		= 	[];			
			var sqlJoinArray 		= 	[];
			var sqlQueryWhereArray 	= 	[];
			
			var sqlSelect		 	= 	'';
			var sqlFromTable		= 	'';
			var sqlJoin		 		= 	'';			
			var sqlQueryWhere		=	'';
			var sqlOrderBy			=	'';
			var sqlLimit			=	'LIMIT 1';
			var sqlOffset			=	'';
			
			sqlFromTable			=	" FROM "+dbTable;
			sqlOrderBy				=	" ORDER BY "+dbTable+".id DESC ";
			//var sqlLimit			=	' LIMIT '+config.params.SQL_LIMIT_JOB;
			
			//sqlSelectArray.push("SELECT  job.* ");	
			sqlSelectArray.push("SELECT  "+dbTable+".*");
			
			
			sqlQueryWhereArray.push(" WHERE "+dbTable+".status_live = "+pool.escape(config.params.MOBILE_BUILD_VERSION_STATUS_LIVE_YES));
			
			sqlSelect		=	sqlSelectArray.join(', ');			
			sqlJoin			=	sqlJoinArray.join(' ');			
			sqlQueryWhere	=	sqlQueryWhereArray.join(' AND ');	
			
			var sqlQuery	=	sqlSelect + sqlFromTable + sqlJoin + sqlQueryWhere + sqlOrderBy + sqlLimit + sqlOffset;					
			
			//console.log('sqlQuery = '+sqlQuery);
				
			pool.getConnection(function(error, connection) {									
				// Use the database connection
				var options = {sql: sqlQuery, nestTables: true};
				connection.query(options, function (error, results, fields) { 
				// And done with the database connection.
					connection.release();

					if (error) { 
						throw error; 
					} else {

						if(!results) {
							return callback(null, null);
						} else {
							//console.log('latestBuildDetails inner = '+ JSON.stringify(results[0][dbTable], null, 2));
							if(results.length) {
								return callback(null, results[0][dbTable]);
							} else {
								return callback(null, results);
							}
						}			
						return callback(null, null);
					}
					// Don't use the connection here, it has been returned to the pool.
				});
			});
		},
		
		
		/* 
		Function to get bank account details by id (primary key).
		*/
		
		getForcefulUpdateBuildId: function(postData, callback) {
			
			//console.log('getForcefulUpdateBuildId');
				
			var user_id 			= 	AuthenticUser.id;
			var build_version		=	postData.build_version;	
			var device_type			=	postData.device_type;	

			if(device_type == config.USER.DEVICE_TYPE_IOS) {
				var dbTable	=	config.params.DB_TABLE_MOBILE_BUILD_VERSION_IOS;
			} else if(device_type == config.USER.DEVICE_TYPE_ANDROID) {
				var dbTable	=	config.params.DB_TABLE_MOBILE_BUILD_VERSION_ANDROID;
			} else {
				return callback(null, null);
			}	
			
			var sqlSelectArray 		= 	[];			
			var sqlJoinArray 		= 	[];
			var sqlQueryWhereArray 	= 	[];
			
			var sqlSelect		 	= 	'';
			var sqlFromTable		= 	'';
			var sqlJoin		 		= 	'';			
			var sqlQueryWhere		=	'';
			var sqlOrderBy			=	'';
			var sqlLimit			=	'LIMIT 1';
			var sqlOffset			=	'';
			
			sqlFromTable			=	" FROM "+dbTable;
			sqlOrderBy				=	" ORDER BY "+dbTable+".id DESC ";
			//var sqlLimit			=	' LIMIT '+config.params.SQL_LIMIT_JOB;
			
			//sqlSelectArray.push("SELECT  job.* ");	
			sqlSelectArray.push("SELECT  "+dbTable+".*");
			
			
			sqlQueryWhereArray.push(" WHERE "+dbTable+".status_forceful_update = "+pool.escape(config.params.MOBILE_BUILD_VERSION_STATUS_FORCEFUL_UPDATE_YES));
			sqlQueryWhereArray.push(dbTable+".status_live = "+pool.escape(config.params.MOBILE_BUILD_VERSION_STATUS_LIVE_YES));
			//sqlQueryWhereArray.push(" job.status = "+config.PROJECT.STATUS.ACTIVE);
			
			sqlSelect		=	sqlSelectArray.join(', ');			
			sqlJoin			=	sqlJoinArray.join(' ');			
			sqlQueryWhere	=	sqlQueryWhereArray.join(' AND ');	
			
			var sqlQuery	=	sqlSelect + sqlFromTable + sqlJoin + sqlQueryWhere + sqlOrderBy + sqlLimit + sqlOffset;					
			
			//console.log('sqlQuery = '+sqlQuery);
				
			pool.getConnection(function(error, connection) {									
				// Use the database connection
				var options = {sql: sqlQuery, nestTables: true};
				connection.query(options, function (error, results, fields) { 
				// And done with the database connection.
					connection.release();

					if (error) { 
						throw error; 
					} else {

						if(!results) {
							return callback(null, null);
						} else {
							//console.log('forcefulBuildDetails inner = '+ JSON.stringify(results[0][dbTable], null, 2));
							if(results.length) {
								return callback(null, results[0][dbTable]);
							} else {
								return callback(null, results);
							}
						}			
						return callback(null, null);
					}
					// Don't use the connection here, it has been returned to the pool.
				});
			});
		},
		
		
		/* 
		Function to get bank account details by id (primary key).
		*/
		
		getCurrentBuildVersionDetails: function(postData, callback) {
			
			//console.log('getCurrentBuildVersionDetails');
				
			var user_id 				= 	AuthenticUser.id;
			var current_build_version	=	postData.current_build_version;	
			//var current_build_id		=	postData.current_build_id;
			var device_type				=	postData.device_type;	

			if(device_type == config.USER.DEVICE_TYPE_IOS) {
				var dbTable	=	config.params.DB_TABLE_MOBILE_BUILD_VERSION_IOS;
			} else if(device_type == config.USER.DEVICE_TYPE_ANDROID) {
				var dbTable	=	config.params.DB_TABLE_MOBILE_BUILD_VERSION_ANDROID;
			} else {
				return callback(null, null);
			}
			
			var sqlSelectArray 		= 	[];			
			var sqlJoinArray 		= 	[];
			var sqlQueryWhereArray 	= 	[];
			
			var sqlSelect		 	= 	'';
			var sqlFromTable		= 	'';
			var sqlJoin		 		= 	'';			
			var sqlQueryWhere		=	'';
			var sqlOrderBy			=	'';
			
			sqlFromTable			=	" FROM "+dbTable;
			sqlOrderBy				=	" ORDER BY "+dbTable+".id DESC ";
			
			//sqlSelectArray.push("SELECT  job.* ");	
			sqlSelectArray.push("SELECT  "+dbTable+".*");
			
			
			sqlQueryWhereArray.push(" WHERE "+dbTable+".build_version = "+pool.escape(current_build_version));
			//sqlQueryWhereArray.push(" WHERE "+dbTable+".id = "+pool.escape(current_build_id));
			//sqlQueryWhereArray.push(" job.status = "+config.PROJECT.STATUS.ACTIVE);
			
			sqlSelect		=	sqlSelectArray.join(', ');			
			sqlJoin			=	sqlJoinArray.join(' ');			
			sqlQueryWhere	=	sqlQueryWhereArray.join(' AND ');	
			
			var sqlQuery	=	sqlSelect + sqlFromTable + sqlJoin + sqlQueryWhere + sqlOrderBy;		
			
			//console.log('sqlQuery = '+sqlQuery);
				
			pool.getConnection(function(error, connection) {									
				// Use the database connection
				var options = {sql: sqlQuery, nestTables: true};
				connection.query(options, function (error, results, fields) { 
				// And done with the database connection.
					connection.release();

					if (error) { 
						throw error; 
					} else {

						if(!results) {
							return callback(null, null);
						} else {
							//console.log('currentBuildDetails inner = '+ JSON.stringify(results[0][dbTable], null, 2));
							if(results.length) {
								return callback(null, results[0][dbTable]);
							} else {
								return callback(null, results);
							}
						}			
						return callback(null, null);
					}
					// Don't use the connection here, it has been returned to the pool.
				});
			});
		},
		
		/* 
		Function to get bank account details by id (primary key).
		*/
		
		getSkipBuildVersionDetails: function(postData, callback) {
			
			//console.log('getSkipBuildVersionDetails');
				
			var user_id 				= 	AuthenticUser.id;
			//var current_build_version	=	postData.current_build_version;	
			var skip_build_id			=	postData.skip_build_id;
			var device_type				=	postData.device_type;	

			if(device_type == config.USER.DEVICE_TYPE_IOS) {
				var dbTable	=	config.params.DB_TABLE_MOBILE_BUILD_VERSION_IOS;
			} else if(device_type == config.USER.DEVICE_TYPE_ANDROID) {
				var dbTable	=	config.params.DB_TABLE_MOBILE_BUILD_VERSION_ANDROID;
			} else {
				return callback(null, null);
			}
			
			var sqlSelectArray 		= 	[];			
			var sqlJoinArray 		= 	[];
			var sqlQueryWhereArray 	= 	[];
			
			var sqlSelect		 	= 	'';
			var sqlFromTable		= 	'';
			var sqlJoin		 		= 	'';			
			var sqlQueryWhere		=	'';
			var sqlOrderBy			=	'';
			
			sqlFromTable			=	" FROM "+dbTable;
			sqlOrderBy				=	" ORDER BY "+dbTable+".id DESC ";
			
			//sqlSelectArray.push("SELECT  job.* ");	
			sqlSelectArray.push("SELECT  "+dbTable+".*");
			
			
			//sqlQueryWhereArray.push(" WHERE "+dbTable+".build_version = "+pool.escape(current_build_version));
			sqlQueryWhereArray.push(" WHERE "+dbTable+".id = "+pool.escape(skip_build_id));
			//sqlQueryWhereArray.push(" job.status = "+config.PROJECT.STATUS.ACTIVE);
			
			sqlSelect		=	sqlSelectArray.join(', ');			
			sqlJoin			=	sqlJoinArray.join(' ');			
			sqlQueryWhere	=	sqlQueryWhereArray.join(' AND ');	
			
			var sqlQuery	=	sqlSelect + sqlFromTable + sqlJoin + sqlQueryWhere + sqlOrderBy;		
			
			//console.log('sqlQuery = '+sqlQuery);
				
			pool.getConnection(function(error, connection) {									
				// Use the database connection
				var options = {sql: sqlQuery, nestTables: true};
				connection.query(options, function (error, results, fields) { 
				// And done with the database connection.
					connection.release();

					if (error) { 
						throw error; 
					} else {

						if(!results) {
							return callback(null, null);
						} else {
							//console.log('currentBuildDetails inner = '+ JSON.stringify(results[0][dbTable], null, 2));
							if(results.length) {
								return callback(null, results[0][dbTable]);
							} else {
								return callback(null, results);
							}
						}			
						return callback(null, null);
					}
					// Don't use the connection here, it has been returned to the pool.
				});
			});
		},
		
		
		
	
	};	
	module.exports = MobileBuildVersionModel;