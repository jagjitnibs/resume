	var InviteModel	=	{
		
		
		
		
		//=================================================================
		/* 
		Function to update the status of credit entries as PAYMENT REQUEST SENT by ids.
		*/
		setStatusJobViewByInvitedUser: function(inviteData, callback) {
						
			var user_id 			= 	AuthenticUser.id;
			//var id 					=	parseInt(inviteData.id);
			var job_id 				=	parseInt(inviteData.job_id);
			
			if((typeof user_id !== 'undefined' && user_id !== null && user_id>0)) {
				
				var sqlQueryUpdateColumnArray	= 	[];			
				var sqlQueryWhereArray 			= 	[];			
				var sqlQueryUpdateTable		 	= 	'';
				var sqlQueryUpdateColumn		= 	'';
				var sqlQueryWhere				=	'';
				var sqlQuery					=	'';											
											
				sqlQueryUpdateTable				=	" UPDATE invite SET ";
							
				sqlQueryUpdateColumnArray.push("invite.status_job_view_by_invited_user = "+pool.escape(config.INVITE.STATUS_JOB_VIEW_BY_INVITED_USER_DONE));
												
				sqlQueryWhereArray.push(" WHERE invite.job_id = "+pool.escape(job_id));		
				sqlQueryWhereArray.push("invite.invite_to = "+pool.escape(user_id));		
				//sqlQueryWhereArray.push("invite.job_id = "+pool.escape(job_id));		
				//sqlQueryWhereArray.push("invite.status_job_view_by_invited_user IS "+pool.escape(config.INVITE.STATUS_JOB_VIEW_BY_INVITED_USER_PENDING));
								
				sqlQueryUpdateColumn		=	sqlQueryUpdateColumnArray.join(', ');			
				sqlQueryWhere				=	sqlQueryWhereArray.join(' AND ');		
				sqlQuery					=	sqlQueryUpdateTable + sqlQueryUpdateColumn + sqlQueryWhere;
				
				console.log('sqlQuery = '+sqlQuery);
							
				pool.getConnection(function(error, connection) {									
					// Use the database connection
					connection.query(sqlQuery, function (error, results, fields) {
					// And done with the database connection.
						connection.release();

						if (error) { 
							throw error; 
						} else {							
							if(!results) {
								return callback(null, null);
							} else {
								//console.log(results);								
								//return callback(null, results.affectedRows);
								//return callback(null, results.changedRows);
								return callback(null, results);
							}			
							//return callback(null, null);
						}

						// Don't use the connection here, it has been returned to the pool.
					});
				});
			}	
			else {
				return callback(null, null);
			}		
		},
		
		
		
		//=================================================================
		//=================================================================
		//=================================================================
  
		/*	
		newFunction: function (req, res, next) {
			return self.foo();
		}
		*/
	};
	
	module.exports = InviteModel;
	