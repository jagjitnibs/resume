	// Include the public functions from 'helpers.js'
	var helpers 			= 	require('../common/components/helpers');
	
	
	var NewsModel = {  
		  
		
		/* 
		Function to get active news list.
		*/
		getAll: function(callback) {
			
			var sqlQueryUpdateColumnArray	= 	[];			
			var sqlQueryWhereArray 			= 	[];			
			var sqlQueryUpdateTable		 	= 	'';
			var sqlQueryUpdateColumn		= 	'';
			var sqlQueryWhere				=	'';
			var sqlQuery					=	'';
			
			var sqlSelectArray 				= 	[];			
			var sqlJoinArray 				= 	[];
			var sqlQueryWhereArray 			= 	[];
			
			var sqlSelect		 			= 	'';
			var sqlFromTable				= 	'';
			var sqlJoin		 				= 	'';			
			var sqlQueryWhere				=	'';
			var sqlOrderBy					=	'';
			
			sqlFromTable					=	" FROM news ";
			sqlOrderBy						=	" ORDER BY news.created_at DESC ";
			
			sqlSelectArray.push("SELECT news.id, news.start_date, news.end_date, news.title, news.description");
			//sqlSelectArray.push("FROM_UNIXTIME(news.start_date, '%Y-%m-%d') AS news_start_date_full");
			
			//sqlQueryWhereArray.push(" WHERE news.status_delete IS "+ config.NEWS.STATUS_DELETE_NO);
			sqlQueryWhereArray.push(" WHERE news.status_delete = "+ config.NEWS.STATUS_DELETE_NO);
			sqlQueryWhereArray.push(" news.start_date < UNIX_TIMESTAMP()");
			sqlQueryWhereArray.push(" news.end_date > UNIX_TIMESTAMP()");
						
			sqlQueryWhere 	= 	sqlQueryWhereArray.join(' AND ');						
			sqlSelect		=	sqlSelectArray.join(', ');			
			sqlJoin			=	sqlJoinArray.join(' ');			
			sqlQueryWhere	=	sqlQueryWhereArray.join(' AND ');

			var sqlQuery	=	sqlSelect + sqlFromTable + sqlJoin + sqlQueryWhere + sqlOrderBy;	
			
			//console.log('sqlQuery = '+sqlQuery);
			
			
			pool.getConnection(function(error, connection) {									
				// Use the database connection
				var options = {sql: sqlQuery, nestTables: false};
				connection.query(options, function (error, results, fields) { 
				// And done with the database connection.
					connection.release();

					if (error) { 
						throw error; 
					} else {

						if(!results) {
							return callback(null, null);
						} else {
							//console.log(results);
							return callback(null, results);
						}			
						return callback(null, null);
					}
					// Don't use the connection here, it has been returned to the pool.
				});
			});
		},
		
	
	};	
	module.exports = NewsModel;