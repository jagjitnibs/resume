	var SectorRoleModel	=	{
		
		getAll: function (callback) {
			
			var sqlSelectArray 		= 	[];			
			var sqlJoinArray 		= 	[];
			var sqlQueryWhereArray 	= 	[];
			
			var sqlSelect		 	= 	'';
			var sqlFromTable		= 	'';
			var sqlJoin		 		= 	'';			
			var sqlQueryWhere		=	'';
			var sqlOrderBy			=	'';			
			
			sqlFromTable			=	" FROM sector_role ";
			
			sqlSelectArray.push("SELECT sector_role.id,  sector_role.title");
				
			sqlQueryWhereArray.push(" WHERE sector_role.status=2" );
			
			sqlSelect		=	sqlSelectArray.join(', ');			
			sqlJoin			=	sqlJoinArray.join(' ');			
			sqlQueryWhere	=	sqlQueryWhereArray.join(' AND ');		
			
			var sqlQuery	=	sqlSelect + sqlFromTable + sqlJoin + sqlQueryWhere + sqlOrderBy;		
			
			//console.log('sqlQuery = '+sqlQuery);
			
			pool.getConnection(function(error, connection) {									
				// Use the database connection

				var options = {sql: sqlQuery, nestTables: false};
				connection.query(options, function (error, results, fields) {
						
					// And done with the database connection.
					connection.release();

					if (error) { 
						throw error; 
					} else {

						if(!results) {
							return callback(null, null);
						} else {
							return callback(null, results);
						}			
						return callback(null, null);
					}
					// Don't use the connection here, it has been returned to the pool.
				});
			});
		},
		
		
		getSectorRoleTitleInShortById: function (id, callback) {
			
			var sqlSelectArray 		= 	[];			
			var sqlJoinArray 		= 	[];
			var sqlQueryWhereArray 	= 	[];
			
			var sqlSelect		 	= 	'';
			var sqlFromTable		= 	'';
			var sqlJoin		 		= 	'';			
			var sqlQueryWhere		=	'';
			var sqlOrderBy			=	'';			
			
			sqlFromTable			=	" FROM sector_role ";
			
			sqlSelectArray.push("SELECT sector_role.id,  sector_role.title");
				
			sqlQueryWhereArray.push("WHERE sector_role.id = "+pool.escape(id));
			sqlQueryWhereArray.push("sector_role.status = "+pool.escape(config.params.STATUS_ACTIVE));
			
			sqlSelect		=	sqlSelectArray.join(', ');			
			sqlJoin			=	sqlJoinArray.join(' ');			
			sqlQueryWhere	=	sqlQueryWhereArray.join(' AND ');		
			
			var sqlQuery	=	sqlSelect + sqlFromTable + sqlJoin + sqlQueryWhere + sqlOrderBy;		
			
			//console.log('sqlQuery = '+sqlQuery);
			
			pool.getConnection(function(error, connection) {									
				// Use the database connection

				var options = {sql: sqlQuery, nestTables: false};
				connection.query(options, function (error, results, fields) {
						
					// And done with the database connection.
					connection.release();

					if (error) { 
						throw error; 
					} else {

						if(!results) {
							return callback(null, null);
						} else {
							if(results.length) {
								var sector_role_title	=	results[0]['title'];
								sector_role_title 		=	sector_role_title.replace(/[^a-z0-9]+/gi, " ");
								var matches 			=	sector_role_title.match(/\b(\w)/g);              // ['J','S','O','N']
								var results 			= 	matches.join('');   
								
								return callback(null, results);
							}			
							return callback(null, null);
						}			
						return callback(null, null);
					}
					// Don't use the connection here, it has been returned to the pool.
				});
			});
		},
	};
	
	module.exports = SectorRoleModel;
	