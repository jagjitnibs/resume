	var unixTime	=	require('unix-time');
	
	/*
	var helpers 				= 	require('../common/components/helpers');
	var ProjectModel 			=	require('../models/ProjectModel');
	var JobInviteModel 			=	require('../models/JobInviteModel');
	var JobFilterModel 			=	require('../models/JobFilterModel');
	*/
	var DebitHistoryPaymentAgentModel	=	{
		
		/* 
		Function to save job skills while creating new job.
		*/
		createLogOfUpdateStatusPaymentRequest: function(payment_agent_id_debit, payment_agent_ids_credit, callback) {
			
			console.log('createLogOfUpdateStatusPaymentRequest');
			var user_id 				= 	AuthenticUser.id;
			var payment_agent_id_debit 	=	parseInt(payment_agent_id_debit);
			var created_at				=	unixTime(new Date()); // 1374016861 
			
			//console.log('job_skill = '+job_skill);
			//console.log('other_skill = '+other_skill);
			
			/*
			var sql = "INSERT INTO Test (name, email, n) VALUES ?";
			var values = [
				['demian', 'demian@gmail.com', 1],
				['john', 'john@gmail.com', 2],
				['mark', 'mark@gmail.com', 3],
				['pete', 'pete@gmail.com', 4]
			];
			conn.query(sql, [values], function(err) {
				if (err) throw err;
				conn.end();
			});
			*/
			var values 		= 	[];		
			
			if(payment_agent_id_debit>0) {
				//var job_skill_ids = job_skill.split(",");
				for (var i=0;i<payment_agent_ids_credit.length;i++) {
					var payment_agent_id_credit = parseInt(payment_agent_ids_credit[i]);
					if(payment_agent_id_credit>0) {
						values.push([user_id, payment_agent_id_debit, payment_agent_id_credit, created_at]);	
					}
				}
			}	
			
			
			//console.log('values length = '+values.length);	
			if(values.length) {
				
				var sqlQuery	=	"INSERT INTO debit_history_payment_agent (agent_id, payment_agent_id_debit, payment_agent_id_credit, created_at) VALUES ?";
				
				console.log('sqlQuery = '+sqlQuery);
				
				pool.getConnection(function(error, connection) {									
					// Use the database connection
					//var options = {sql: sqlQuery, nestTables: true};
					connection.query(sqlQuery, [values], function (error, results, fields) {
					// And done with the database connection.
						connection.release();

						if (error) { 
							throw error; 
						} else {
							if(!results) {
								return callback(null, null);
							} else {						
								return callback(null, results);
							}			
							return callback(null, null);
						}

						// Don't use the connection here, it has been returned to the pool.
					});
				});
			}					
		},		
		
	};
	
	module.exports = DebitHistoryPaymentAgentModel;
	