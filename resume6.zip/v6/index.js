	var os = require('os');
	
	const os_hostname 			=	os.hostname();
	global.os_hostname 			= 	os_hostname;  // Set as a global variable.
	console.log("-------------------------------------"); // Do not delete this code without any confirmation.
	//console.log('Hostname: '+os_hostname); // Do not delete this code without any confirmation.
	
	//-------------------------------------------------------------------------
	var serverDevelopment		=	["DESK5WIN7", "DESK7WIN10", "ip-10-0-0-14"];
	var serverProduction 		=	["ip-172-30-31-11"];
	global.serverDevelopment	= 	serverDevelopment;  // Set as a global variable.
	global.serverProduction 	= 	serverProduction;  	// Set as a global variable.
	//-------------------------------------------------------------------------
	
	if(serverDevelopment.indexOf(os_hostname) >= 0) {
		var env 			=	process.env.NODE_ENV || 'development';
	} else if(serverProduction.indexOf(os_hostname) >= 0) {
		var env 			=	process.env.NODE_ENV || 'production';
	} else {
		var env 			=	process.env.NODE_ENV || 'development';
	} 
	
	console.log("Environment: "+env); // Do not delete this code without any confirmation.
	
	var application_root	=	__dirname;
	
	var express 			= 	require('express');
	var async      			= 	require('async');
	var mysql      			=	require('mysql');
	var passport 			=	require('passport');
	var Strategy 			= 	require('passport-http-bearer').Strategy;
	var bodyParser			=	require('body-parser');
	var cookieParser		=	require('cookie-parser');
	var expressValidator 	= 	require('express-validator');
	var util 				= 	require('util');
	var path 				= 	require('path'); 
	var fs 					= 	require("fs");	
	//var favicon 			= 	require('serve-favicon');  
	var logger 				=	require('morgan'); 
	var cors 				=	require('cors');
		
	var config				=	require(application_root+'/common/config/config')[env];
	global.config 			= 	config;  // Set as a global variable.
				
				
	var pool				=	require(application_root+'/common/config/config.db')(config);
	global.pool 			= 	pool;  // Set as a global variable.
				
	// Create a new Express application.
	var app 				= 	express();
	var port 				= 	config.port;
	app.set('port', port);
	//var http 				= 	require("http");
	var http 				= 	require('http').Server(app);
		
	var controllers 		= 	require('./controllers');
	var UserModel			=	require('./models/UserModel');
	//var JobModel			=	require('./models/JobModel');
	//var JobFilterModel	=	require('./models/JobFilterModel');
	
	// Include the public functions from 'helpers.js'
	var helpers 			= 	require('./common/components/helpers');

	// Configure the Bearer strategy for use by Passport.
	//
	// The Bearer strategy requires a `verify` function which receives the
	// credentials (`token`) contained in the request.  The function must invoke
	// `cb` with a user object, which will be set at `req.user` in route handlers
	// after authentication.
	
	passport.use(new Strategy(
		function(token, cb) {
			UserModel.findByToken(token, function(err, user) {
				if (err) { return cb(err); }
				if (!user) { return cb(null, false); }
				return cb(null, user);
			});
	}));

	// Configure Express application.
	//app.use(require('morgan')('combined'));

	
	// view engine setup  
	app.set('views', path.join(__dirname, 'views'));  
	app.set('view engine', 'jade');  
	// uncomment after placing your favicon in /public  
	//app.use(favicon(path.join(__dirname, 'public', 'favicon.ico')));  
	
	
	app.use(cors()); 
	var corsOptions = {
	  origin: 'http://example.com',
	  optionsSuccessStatus: 200 // some legacy browsers (IE11, various SmartTVs) choke on 204 
	}
	
	app.use(logger('dev'));	
	
	//app.use(bodyParser({limit: '50mb'}));
	app.use(bodyParser.urlencoded({limit: "50mb", extended: true}));	
	app.use(bodyParser.json({ limit: "50mb"}));	
	//api.use(bodyParser.json({ 'type': '*/*',limit: '20mb' }));
	
	app.use(cookieParser());  
	app.use(express.static(path.join(__dirname, 'public')));  
	
	//app.use(bodyParser.json({ type: 'application/json' }));
	// We add the middleware after we load the body parser
	app.use(expressValidator());


	/*
	app.use('/', routes);  
	//app.use('/users', users);  
	app.use('/Tasks', Tasks);  
	*/
	
	app.use(function(req, res, next) {
		//-------------------------------------------------------------------------
		res.header('Access-Control-Allow-Origin', '*');
		res.header('Access-Control-Allow-Credentials', 'true');
		res.header('Access-Control-Max-Age', '1000');
		res.header('Access-Control-Allow-Headers', 'Api-Version, X-Requested-With, Content-Type, Origin, Authorization, Accept, Client-Security-Token, Accept-Encoding');
		res.header('Access-Control-Allow-Methods', 'POST, GET, OPTIONS, DELETE, PUT');		
		//-------------------------------------------------------------------------
		res.setHeader('Api-Version', config.API.VERSION);
		console.log("-------------------------------------"); 	//	Do not delete this code without any confirmation.
		console.log('Request Time: '+  new Date());
		console.log('Request Method: '+'%s', req.method);
		console.log('Request URL: '+'%s', req.url);
		//console.log("-------------------------------------");	//	Do not delete this code without any confirmation.
		next();
		
		//var err = new Error('Not Found');  
		//err.status = 404;  
		//next(err); 
	});
	
	//var birds = require('./controllers/birds');
	//app.use('/birds', birds);
	
	//var animals = require('./controllers/animals');
	//app.use('/animals', animals);
	
	var FeedbackController = require('./controllers/FeedbackController');
	app.use('/feedback', FeedbackController);
	
	var InviteController = require('./controllers/InviteController');
	app.use('/invite', InviteController);
	
	var JobController = require('./controllers/JobController');
	app.use('/job', JobController);
	
	var JobApplyController = require('./controllers/JobApplyController');
	app.use('/job-apply', JobApplyController);
	
	var JobFilterController = require('./controllers/JobFilterController');
	app.use('/job-filter', JobFilterController);
	
	var NewsController = require('./controllers/NewsController');
	app.use('/news', NewsController);
	
	var NotificationController = require('./controllers/NotificationController');
	app.use('/notification', NotificationController);
	
	var PaymentAgentController = require('./controllers/PaymentAgentController');
	app.use('/payment-agent', PaymentAgentController);
	
	var ProjectController = require('./controllers/ProjectController');
	app.use('/project', ProjectController);	
		
	var SettingController = require('./controllers/SettingController');
	app.use('/setting', SettingController);
	
	var SmsJobInviteController = require('./controllers/SmsJobInviteController');
	app.use('/sms-job-invite', SmsJobInviteController);
	
	var UserController = require('./controllers/UserController');
	app.use('/user', UserController);
	
	
	// catch 404 and forward to error handler  
	/*
	app.use(function(req, res, next) {  
		var err = new Error('Not Found');  
		err.status = 404;  
		next(err);  
	}); 
*/
	/*
	app.use(function(req, res, next) {

		res.header('Access-Control-Allow-Origin', '*');
		res.header('Access-Control-Allow-Credentials', 'true');

		res.header('Access-Control-Max-Age', '1000');
		res.header('Access-Control-Allow-Headers', 'X-Requested-With, Content-Type, Origin, Authorization, Accept, Client-Security-Token, Accept-Encoding');
		res.header('Access-Control-Allow-Methods', 'POST, GET, OPTIONS, DELETE, PUT');

		console.log('Request date/time: '+  new Date()  );
		console.log('Request URL:', req.originalUrl)
		//console.log(req.body) // populated!


		var err = new Error('Not Found');  
		err.status = 404;  
		next(err); 

	});	
	*/
	
	
	// error handlers  
	// development error handler  
	// will print stacktrace  
	/*
	if (app.get('env') === 'development') {  
		app.use(function(err, req, res, next) {  
			res.status(err.status || 500);  
			res.render('error', {  
				message: err.message,  
				error: err  
			});  
		});  
	}  
	// production error handler  
	// no stacktraces leaked to user  
	app.use(function(err, req, res, next) {  
		res.status(err.status || 500);  
		res.render('error', {  
			message: err.message,  
			error: {}  
		});  
	}); 
	*/

	//app.listen(3000);


app.listen(app.get('port'), function(){ 
  //console.log('Success: Server started on localhost:' + app.get('port') + '; Press Ctrl-C to terminate.'); // Do not delete this code without any confirmation.
  console.log('Success: App listening on '+config.url+':'+app.get('port')); // Do not delete this code without any confirmation.
  //forever -w ./index.js
});

